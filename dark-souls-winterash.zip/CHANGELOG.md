# Journal des versions

## 0.7.0 — Combat fluide
- Combat refondu, plus rapide et plus agressif, inspiré de Phantom Blade Zero
- Combo de 4 coups (taille, revers, coup montant, tournoiement) ; maintenir le clic arme un coup lourd ; frapper en sortie d'esquive ou de course donne un estoc
- Tampon d'entrées : une touche pressée pendant un coup part au premier moment possible. Les coups s'annulent en esquive ou en parade dès l'impact passé
- Aimantation : chaque coup s'oriente vers l'ennemi visé et avale la distance
- Pas fantôme (Espace) : esquive rapide et courte avec images rémanentes ; sans direction, pas en arrière
- Esquive parfaite (au dernier moment) : ralenti, Élan, prochain coup renforcé ; face à un coup mortel, on passe dans le dos de l'ennemi
- Signaux d'attaque ennemis : bleu = coup brutal, à parer ; rouge = coup mortel, impossible à parer ou à bloquer, à esquiver
- Parade : déviation avec étincelles, petit ralenti, et une seconde parade reste possible dans la foulée
- Équilibre des ennemis visible sous leur barre de vie ; plein, l'ennemi est brisé et s'exécute (zoom, ralenti)
- Les ennemis sursautent sous les coups, sauf en pleine attaque lourde (armure)
- Élan (3 losanges) : se gagne en parant, en esquivant au dernier moment, en finissant les combos et en exécutant ; F lance la Lame fantôme, qui traverse les ennemis en ligne
- Carcasses gelées plus agressives : combos de 2 à 3 coups, coup brutal, estoc mortel à distance ; au plus deux attaquent à la fois, les autres tournent autour
- Ylva : sa morsure devient un coup brutal (parable, fait monter son équilibre), son saut écrasant un coup mortel ; elle peut être exécutée une fois brisée
- Traînée lumineuse derrière la lame, arrêt sur impact, gerbes d'étincelles, compteur de coups, nouveaux sons
- Endurance : coups moins coûteux et récupération plus rapide ; déplacement avec accélération et freinage lissés

## 0.6.0 — Lothmar et les phares
- La carte est quatre fois plus grande : une vallée centrale, des routes vers quatre régions et des terres gelées entre elles
- Lothmar, cité des Veilleurs : une grande ville fortifiée avec ses remparts, ses 14 tours, sa porte fortifiée, une avenue, une grand-place avec fontaine et étals, des maisons à colombages et des demeures nobles, un quartier incendié, une cathédrale avec son clocher et ses vitraux, et un château avec son donjon
- Trois villages : le Hameau de Givrefosse (palissade, tours de guet, chapelle, grange, puits, champs), Rivebrume (moulin à vent qui tourne, maisons au bord de l'eau) et la Tour du Guet (avant-poste en ruine et campement)
- Les fenêtres s'allument à la tombée de la nuit ; lanternes, bornes, charrettes et panneaux le long des routes
- Une brume légère recouvre le monde et gêne la vue au loin. Cinq phares à allumer ([E] au pied de la tour) la dissipent dans leur région et dévoilent la carte autour d'eux
- Carte (touche M) : un parchemin qui se dévoile à mesure que tu explores, avec les feux allumés, les phares, l'arène et ta tache de sang. L'exploration est sauvegardée
- Le nom de la région s'affiche quand tu y entres (« Nouvelle région » la première fois)
- Cinq nouveaux feux de camp : Porte de Lothmar, Lothmar, Givrefosse, Rivebrume, Tour du Guet
- 48 nouveaux ennemis (dont des chevaliers dans la cour du château) et 18 nouveaux objets et écrits
- Coupe des bâtiments : les murs et toits entre la caméra et le joueur s'effacent, et la caméra recule un peu en ville
- Forêt agrandie (plus de 1 100 pins), dessinée par dalles pour rester fluide
- Le son se coupe maintenant avec K (M ouvre la carte)
- Panneau de triche : téléportations vers les nouvelles régions, allumer les phares, révéler la carte

## 0.5.0 — Le Protecteur de la Flamme
- Le jeu devient Dark Souls : Winterash, un souls-like entre Dark Souls II et III, avec une introduction et deux fins
- Combat : attaque lourde (clic maintenu), garde, parade suivie d'une riposte critique, verrouillage de cible (Tab), équilibre et vacillement des ennemis
- Les braises deviennent des âmes ; à la mort, elles restent sur une tache de sang à récupérer
- Statistiques Vigueur, Endurance, Force et Foi, montée de niveau au feu de camp
- Trois feux de camp à allumer, avec repos, voyage rapide et renforcement de l'épée (titanite)
- Fiole d'Estus et éclats d'Estus, bombes incendiaires, pyromancie « Flamme du Protecteur » et jauge de PC
- Nouveaux ennemis : les Carcasses gelées (épée, hache, chevaliers), placées dans toute la vallée et replacées à chaque repos
- Boss : Ylva, Mère des Tisseuses, en deux phases, derrière un mur de brume
- Ysolde, Gardienne du Feu, et ses dialogues ; 18 objets et écrits à trouver
- Interface : bannières, barres de vie des ennemis, barre du boss, compteur d'âmes, menu pause
- Sauvegarde automatique, Continuer et Nouvelle partie sur l'écran titre
- La caméra se place entre le joueur et le boss ou la cible verrouillée
- Écume du lac corrigée (plus de grandes taches blanches)

## 0.4.0 — Nouveaux modèles 3D
- Le veilleur est entièrement remodelé : capuche et yeux pâles, col de fourrure, épaulières, plastron, ceinture et sacoches, tabards, cape en lambeaux avec doublure rouge, écharpe, lanterne à la hanche
- Genoux et coudes articulés : démarche plus naturelle, bras qui se plie pour boire et tenir la torche
- Épée longue détaillée (gorge, quillons, pommeau), torche, canne, fiole et poisson redessinés
- Tisseuses remodelées : abdomen bosselé et poilu, chevrons rouges, 8 yeux, crochets, pédipalpes, pattes à 3 segments
- Pins en 5 étages irréguliers avec neige par plaques, en 3 variantes
- Nouveaux arbres morts autour de la chapelle, buissons secs, rochers enneigés plus naturels
- Stalactites de glace sur la cabane
- Captures et visuels Streaz mis à jour

## 0.3.0 — Arrivée sur Streaz
- Le jeu se lance depuis Streaz : manifeste streaz.json, page boutique, captures et icône
- Le build produit un seul fichier jeu/index.html, qui marche hors ligne
- Polices intégrées au jeu (plus besoin d'internet)
- Bouton « Quitter le jeu » sur l'écran titre quand le jeu tourne dans Streaz
- Numéro de version affiché sur l'écran titre

## 0.2.0 — Découpage en modules
- Le code est découpé en 26 modules ES, lancés avec Vite
- Three.js installé avec npm au lieu d'un CDN
- README : architecture et guide « où ajouter quoi »

## 0.1.0 — Premier prototype
- Rendu 3D pixelisé avec palette réduite et tramage
- Combat contre les tisseuses : épée, torche, roulade, endurance
- Pêche avec mini-jeu de tension
- Cycle jour/nuit et météo dynamique
- Feu de camp, cabane, chapelle en ruine, cimetière et lac
- Panneau de triche (code nox)
