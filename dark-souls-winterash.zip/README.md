# Dark Souls : Winterash

Souls-like en 3D pixelisée, vue de dessus. Entre Dark Souls II et Dark Souls III : après la chute de Drangleic,
la Première Flamme vacille et un hiver sans fin recouvre la vallée de Cendrehiver.
Tu incarnes un **Protecteur de la Flamme** : ravive-la… ou laisse-la s'éteindre.

Three.js 0.128 + Vite, JavaScript en modules ES. Se lance dans le launcher **Streaz**.

## Le jeu

- **Combat** (inspiré de Phantom Blade Zero) : combo de 4 coups, coup lourd (clic maintenu), estoc en sortie d'esquive, tampon d'entrées et annulations, aimantation vers la cible. **Pas fantôme** (esquive rapide ; parfaite = ralenti, et dans le dos face à un coup mortel). **Parade** des coups normaux et brutaux (signal bleu) ; les coups mortels (signal rouge) s'esquivent. L'**équilibre** des ennemis se vide sous les coups : brisé, l'ennemi s'**exécute**. L'**Élan** se gagne en combattant bien et lance la **Lame fantôme** (F).
- **Âmes** : les ennemis en donnent. À ta mort, elles restent sur une **tache de sang** ; meurs avant de la toucher et elles sont perdues.
- **Monde** : la vallée de Cendrehiver au centre, et par les routes Lothmar, cité des Veilleurs (grande ville fortifiée, cathédrale, château), le Hameau de Givrefosse, Rivebrume et la Tour du Guet.
- **Brume et phares** : une brume légère limite la vue. Allumer un **phare** la dissipe dans sa région et dévoile la carte autour.
- **Carte** (M) : parchemin qui se dévoile en explorant ; noms des régions affichés à l'entrée.
- **Feux de camp** (8) : se reposer (vie, PC et Estus restaurés, ennemis replacés, sauvegarde), **gagner des niveaux** (Vigueur, Endurance, Force, Foi), **renforcer l'épée** (titanite + âmes), **voyager**.
- **Ennemis** : Carcasses gelées (épée, hache, chevaliers ; leurs coups se parent), tisseuses (ne se parent pas, craignent le feu), tisseuses errantes la nuit.
- **Boss** : Ylva, Mère des Tisseuses, derrière un mur de brume au nord de la chapelle. Deux phases.
- **Deux fins** à la Première Flamme : « Raviver » (printemps) ou « Laisser s'éteindre » (Âge du Givre). La vallée change ensuite.
- **Objets** : Fiole d'Estus et éclats d'Estus, bombes incendiaires, pyromancie (PC), poissons, titanite, écrits.
- **Sauvegarde automatique** (localStorage) : Continuer / Nouvelle partie sur l'écran titre.

## Lancer le jeu

```bash
npm install      # une seule fois
npm run dev      # serveur local avec rechargement à chaud, ouvre le navigateur
npm run build    # compile le jeu dans UN fichier : jeu/index.html (JS, CSS et polices intégrés)
npm run preview  # tester la version compilée
```

> Le `index.html` à la racine est la source pour Vite : il ne s'ouvre pas en double-cliquant.
> `jeu/index.html`, lui, s'ouvre directement et fonctionne hors ligne.

## Streaz

Le jeu est prêt pour le launcher **Streaz** (lancement de type `file`, fenêtre Streaz).

| Fichier | Rôle |
|---|---|
| `streaz.json` | Manifeste : fiche boutique, visuels, version (lue dans `package.json`), notes (lues dans `CHANGELOG.md`), lancement `jeu/index.html` |
| `streaz/` | Icône, logo, bannière 1600×600, vignette 1280×720, captures 1600×900 |
| `.streazignore` | Exclut le code source et `streaz/` de l'installation chez les joueurs |
| `CHANGELOG.md` | Une section `## X.Y.Z — Titre` par version, une note par ligne `- …` |
| `jeu/index.html` | Le jeu compilé, **versionné dans Git** : Streaz installe le dépôt sans étape de build |
| `src/streaz.js` | Détecte Streaz (user-agent `Streaz/x.y.z`) et affiche « Quitter le jeu » |

**Ajouter le jeu dans Streaz :** donner accès à ce dépôt au jeton GitHub de Streaz (Contents : Read-only), puis Atelier → jeux GitHub. Ou coller l'adresse du dépôt dans l'atelier.

**Publier une nouvelle version :**
1. monter `version` dans `package.json` ;
2. ajouter la section en tête de `CHANGELOG.md` ;
3. `npm run build` puis committer `jeu/index.html` avec le reste.

## Commandes

| Touche | Action |
|---|---|
| ZQSD / WASD | Se déplacer · Maj : courir |
| Souris | Viser |
| Clic gauche | Combo de 4 coups · **maintenu : coup lourd** · après une esquive : estoc · utiliser l'objet en main |
| Clic droit | Garde · **au tout début : parade** (puis clic gauche = exécution) |
| F | Lame fantôme (1 Élan) |
| Tab / clic molette | Verrouiller une cible |
| Espace | Pas fantôme (esquive) · sans direction : pas en arrière |
| R | Boire l'Estus |
| E | Interagir · feu de camp · parler · ramasser |
| 1 – 8 | Choisir un objet (6 : bombe, 7 : pyromancie) |
| Échap | Pause |
| Molette | Zoom |
| M | Carte |
| K | Couper le son |

**Triche :** tape `nox` en jeu pour ouvrir le panneau de triche.

## Architecture

```
index.html            balisage du HUD, de l'écran titre et du panneau de triche
src/
├─ main.js            point d'entrée : construit le monde, écran titre, boucle frame()
├─ streaz.js          détection de Streaz, bouton Quitter, numéro de version
├─ state.js           état partagé : joueur P, objets ITEMS, monde WORLD, triche CHEAT, globaux G, entrées INPUT
├─ story.js           introduction, choix et cinématiques des deux fins
├─ npc.js             Ysolde, Gardienne du Feu, et ses dialogues
├─ utils.js           maths, aléatoire à graine, bruit (vnoise, fbm)
├─ sky.js             heure, couleurs du ciel, soleil/lune, brouillard, météo (SKY)
├─ audio.js           sons générés en WebAudio (AU)
├─ input.js           clavier, souris, molette, code de triche
├─ fishing.js         machine à états de la pêche + mini-jeu de tension
├─ interactions.js    registre des points « [E] » (addInteractable)
├─ game/
│  ├─ stats.js        statistiques, valeurs dérivées, coût des niveaux, forge
│  └─ save.js         sauvegarde / chargement (localStorage)
├─ combat/
│  ├─ lockon.js       verrouillage de cible et marqueur
│  └─ feel.js         sensations : ralenti, arrêt sur impact, images rémanentes, traînée de lame, signaux bleu/rouge, éclair
├─ style.css          styles du HUD
├─ core/
│  ├─ renderer.js     rendu basse résolution + shader de pixelisation (postMat, GFX), brume centrée sur le joueur (FOG_CENTER), CUT
│  ├─ cameraRig.js    caméra qui suit le joueur (ou se place entre lui et le boss), tremblement, voile rouge
│  ├─ screen.js       projection 3D → écran (barres de vie, marqueurs)
│  ├─ collision.js    obstacles (cercles + boîtes) rangés dans une grille de 8 m, tryMove(), insideBox()
│  ├─ helpers.js      M(), MB(), mk() pour créer des meshes, objets temporaires
│  └─ geo.js          modélisation : part(), merge(), jitter(), paintBy() (pièces colorées fusionnées)
├─ world/
│  ├─ terrain.js      données du monde : heightAt(), lac, routes, régions, ville, villages, feux, phares
│  ├─ terrainMesh.js  maillage du sol et shader de l'eau
│  ├─ forest.js       pins, arbres morts, rochers, buissons (variantes instanciées par dalles de 64 m)
│  ├─ architecture.js générateurs médiévaux (Kit, house, wall, tower, gatehouse, palisade…) + coupe des bâtiments
│  ├─ city.js         Lothmar : remparts, quartiers, cathédrale, château, grand-place
│  ├─ villages.js     Givrefosse, Rivebrume (moulin), Tour du Guet, décor des routes
│  ├─ beacons.js      phares : allumage, colonne de lumière, beaconClear() (brume dissipée)
│  ├─ places.js       cabane, chapelle, cimetière, ponton + leurs animations
│  ├─ bonfires.js     feux de camp : allumer, se reposer, voyager
│  ├─ arena.js        arène d'Ylva : pierres levées, mur de brume, Première Flamme
│  ├─ pickups.js      objets à ramasser et écrits
│  └─ bloodstain.js   tache de sang (âmes perdues)
├─ fx/
│  ├─ particles.js    Pool de particules (parts éclairées, glow lumineuses)
│  ├─ footprints.js   traces de pas qui s'effacent
│  ├─ snow.js         neige qui tombe
│  └─ projectiles.js  bombes, boules de feu, toiles
├─ player/
│  ├─ model.js        modèle 3D du veilleur et objets en main (pl)
│  ├─ actions.js      coups (MOVES), tampon d'entrées (press), annulations, pas fantôme, parade, Lame fantôme, dégâts reçus, mort
│  └─ player.js       mise à jour par image : déplacement, visée, animation
├─ enemies/
│  ├─ enemy.js        base commune : vie, équilibre, parade, barre de vie, âmes, laisse
│  ├─ index.js        population : emplacements fixes, respawn, tisseuses de nuit
│  ├─ spiderModel.js  modèle 3D des tisseuses (géométries partagées)
│  ├─ spiders.js      tisseuses
│  ├─ hollowModel.js  modèle 3D des Carcasses gelées
│  ├─ hollow.js       Carcasses gelées
│  └─ boss.js         Ylva, Mère des Tisseuses
└─ ui/
   ├─ hud.js          barres, âmes, horloge, barre d'objets, bannières, notifications, barre du boss
   ├─ menus.js        menus du feu (niveaux, forge, voyage), pause, dialogues, choix
   ├─ icons.js        icônes pixel art des objets
   ├─ map.js          carte (M) : parchemin, exploration sauvegardée, noms des régions
   ├─ fonts.js        polices embarquées (@fontsource, licence OFL)
   └─ cheat.js        panneau de triche
```

### Ordre d'une image (`frame()` dans `main.js`)

`updateSky` → `updatePlayer` → `updateFishing` → `updateEnemies` → `updateProjectiles` → `updateLock` → particules → traces → `updatePlaces` → `updateBonfires` → `updatePickups` → `updateBloodstain` → `updateArena` → `updateBeacons` → `updateVillages` → `setNightGlow` → `updateMap` → `updateSnow` → `updateCamera` → `updateInteractions` → `updateHUD` → `renderFrame`

Quand `G.paused` est vrai (menu, dialogue, cinématique), le monde est figé : seuls la pose assise, les feux, la caméra et l'interface continuent.

### Où ajouter…

| Je veux ajouter… | Fichier |
|---|---|
| un objet dans la barre | `state.js` (`ITEMS`), `ui/icons.js` (icône), `input.js` (clic), `player/model.js` (modèle en main) |
| un ennemi | une classe qui étend `Enemy` (`enemies/enemy.js`) avec `think()`, `animate()`, `deathFx()`, puis un type dans `SPAWNS` (`enemies/index.js`) |
| un emplacement d'ennemi | `SPAWNS` dans `enemies/index.js` |
| un coup du joueur | `MOVES` dans `player/actions.js` (durée, impact, annulation, dégâts, aimantation) + sa pose dans `rightArmPose()` et la torsion dans `animate()` (`player/player.js`) |
| une attaque ennemie signalée | `telegraph(ennemi, 'brutal' \| 'mortel')` (`combat/feel.js`) au début de la préparation, puis `hurtPlayer(…, { kind, parryable, src: this })` |
| un feu de camp | `BONFIRE_POS` dans `world/terrain.js` |
| un objet au sol | `PICKUPS` dans `world/pickups.js` |
| un point « [E] » | `addInteractable({ x, z, r, label, act, enabled })` depuis n'importe quel module |
| un dialogue | `npc.js` |
| une statistique | `game/stats.js` (`derive()`) + `game/save.js` |
| un lieu | `world/terrain.js` (position + zone aplanie), `world/places.js` (géométrie) |
| un bâtiment | `world/architecture.js` : `house(kit, x, z, q, { w, d, floors, style })`, `tower()`, `wall()`… dans un `Kit`, puis `kit.build()` |
| un village | une fonction dans `world/villages.js` + sa zone (`GIVREFOSSE`…) et sa région (`REGIONS`) dans `world/terrain.js` |
| un phare | `BEACON_POS` dans `world/terrain.js` |
| une région nommée | `REGIONS` dans `world/terrain.js` (cercle + nom) |
| une option de triche | `index.html` (contrôle) + `ui/cheat.js` |
| un son | `audio.js` |
| une ambiance de ciel | `sky.js` (`KEYS`, `WEATHER`) |

### Combat fluide (combat/feel.js, player/actions.js)

- **Tampon** : `press(action)` essaie l'action tout de suite, sinon la garde 0,32 s et la relance à chaque image (`updateBuffer`).
- **Annulations** : un coup peut enchaîner le suivant à partir de `cancel`, et s'annuler en esquive ou en parade dès l'impact (`hit`) passé.
- **Temps** : `timeScale(dt)` (appelé dans `frame()`) applique l'arrêt sur impact (`G.hitStop`) et le ralenti (`slowmo(durée, vitesse)`).
- **Ennemis** : `Enemy.hurt` vide l'équilibre et fait sursauter (`hitstun`) sauf `armored()` ; équilibre plein → `stagger` + `broken` → `canRiposte()`.
  `attackers()` compte les ennemis qui attaquent déjà (au plus 2 à la fois).

### Brume, phares et coupe des bâtiments

- **Brume centrée sur le joueur** : `core/renderer.js` remplace les morceaux de shader `fog_pars_vertex` / `fog_vertex` de Three.js
  pour mesurer la distance depuis le joueur (`FOG_CENTER`, mis à jour par `cameraRig.js`) et non depuis la caméra.
- **Densité** (`sky.js`) : heure + météo + `MIST × (1 − beaconClear(x, z))`. `beaconClear` vaut 1 près d'un phare allumé
  (rayon `BEACON_RADIUS`) et redescend à 0 en s'éloignant.
- **Coupe** (`withCutaway()` dans `world/architecture.js`) : les fragments plus hauts que le joueur et situés dans un cône
  joueur → caméra sont retirés, avec un bord tramé.

### Modéliser (core/geo.js)

Les modèles sont construits en code à partir de formes simples. Chaque pièce reçoit une couleur par sommet,
puis les pièces fixes d'un même objet sont fusionnées en **un seul mesh** :

```js
const geo = merge([
  part(new THREE.BoxGeometry(0.1, 0.5, 0.1), 0x3b2a1e, { y: 0.25 }),          // pièce + couleur + placement
  paint(jitter(new THREE.SphereGeometry(0.3, 8, 6), 0.05, 1), 0x4a4036),      // forme déformée (aspect organique)
  paintBy(new THREE.ConeGeometry(1, 1, 9), (x, y, z, nx, ny) => ny > 0.5 ? NEIGE : VERT) // couleur selon la face
]);
meshOf(geo, vcMat(), parent);
```

Les parties qui bougent (bras, jambes, pattes) sont des groupes séparés, chacun avec son mesh fusionné.

### Débogage

En mode développement (`npm run dev`), `window.__ws` donne accès à l'état depuis la console du navigateur
(`__ws.P`, `__ws.WORLD`, `__ws.enemies`…). Il n'existe pas dans le build lancé par Streaz.

### Règle des modules

Les valeurs qui changent pendant la partie sont des **propriétés d'objets** (`P.hp`, `SKY.hour`, `G.shake`…), jamais des `let` exportés : un module ne peut pas réassigner une variable importée, mais il peut modifier un objet partagé.
