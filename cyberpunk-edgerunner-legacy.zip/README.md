# Cyberpunk Edgerunner Legacy

Fan game **non officiel** dans l'univers de Cyberpunk 2077, dans l'esprit d'Edgerunners. Action en vue de dessus façon Hotline Miami, en pixel art 320×180 ou 480×270. Projet privé.

**Version actuelle : 0.21.0 — Planque vivante et sauvegarde**

## Lancer le jeu

- **Dans Streaz** : coller l'adresse du dépôt dans l'atelier. Le manifeste `streaz.json` lance `index.html` dans une fenêtre Streaz.
- **Sans Streaz** : ouvrir `index.html` dans un navigateur (double-clic). Aucun serveur, aucune dépendance, aucune requête externe.

## Contrôles

| Action | Touche |
| --- | --- |
| Avancer vers la souris | Z (AZERTY) ou W (QWERTY), ou flèche haut |
| Reculer / pas de côté | S / Q et D (A et D en QWERTY), ou les autres flèches |
| Tirer (partout sauf à la planque ; dans la rue, gare au NCPD) | Clic gauche (maintenu) |
| Lame | Clic droit |
| Dash (invulnérable) | Espace |
| Sandevistan | Maj |
| Injecteur | F |
| Recharger | R |
| Achever / épargner un ennemi à terre | E / C |
| Fouiller, recruter, relever le compagnon, parler au ripperdoc ou au fixer, passer une porte | E |
| Ramasser une arme (échange avec celle en main) | E |
| Bar de Luna (planque) : choisir / commander / sortir | Haut-Bas ou souris / E ou clic / Échap |
| Armurier (planque) : choisir / acheter / sortir | Haut-Bas ou souris / E ou clic / Échap |
| Scan / quickhacks (partout sauf à la planque) | TAB maintenu, viser à la souris, 1 à 5 ou clic |
| Contrats : voler le colis, libérer l'otage, poser la bombe (maintenu) | E |
| Pirater un terminal (breach protocol) | E, puis flèches ou souris, E ou clic pour choisir, Échap pour se déconnecter |
| Monter / descendre de voiture, voler une voiture, parler au concessionnaire | E |
| Prendre le métro (bouche NCART) : choisir la station / monter / sortir | Haut-Bas ou souris / E ou clic / Échap |
| Passer le trajet en métro | E ou Espace |
| Conduire (accélérer, freiner/reculer, tourner) | ZQSD / WASD ou flèches |
| Concessionnaire : choisir / acheter / sortir | Haut-Bas ou souris / E ou clic / Échap |
| Boutique du ripperdoc : choisir / poser / retirer / sortir | Haut-Bas ou souris / E ou clic / X / Échap |
| Contrats du fixer : choisir / accepter / plus tard | Haut-Bas ou souris / E ou clic / Échap |
| Ordre au compagnon (suivre / tenir) | G |
| Arbre des compétences : ouvrir / choisir / prendre / fermer | K / flèches ou souris / E ou clic / K ou Échap |
| Gig suivant | Rentrer à la planque une fois le contrat rempli ou raté |
| Nouveau leader (écran de fin) | Entrée |
| Continuer la partie sauvegardée (écran titre) | Clic, Entrée ou Espace |
| Nouveau leader alors qu'une partie est sauvegardée (écran titre, deux fois) | N |
| Choisir un leader | Clic ou 1, 2, 3 |
| Effacer la ville (écran titre, deux fois) | Suppr |
| Changer de résolution (écran titre) | V |
| Couper / remettre la musique | M |
| Radio suivante (au volant) | R |
| Deck de triche : ouvrir / choisir / colonne / exécuter / fermer | ² (` en QWERTY) ou F2 / Haut-Bas ou souris / Gauche-Droite / E ou clic / Échap |

## Organisation du code

Scripts classiques chargés dans l'ordre par `index.html` (pas de modules ES : ils sont bloqués en `file://`). Tout passe par l'objet global `CEL`.

| Fichier | Rôle |
| --- | --- |
| `src/core.js` | Constantes, maths, canvas 320×180 ou 480×270 (`setResolution`) agrandi à l'échelle entière, entrées, police pixel 3×5, sons synthétisés |
| `src/defs.js` | Toutes les valeurs de réglage (PV, vitesses, armes, ennemis, compagnon, implants et cyberdecks, quickhacks, caméras, tourelles, eddies, factions, contrats, grand contrat, Sandevistan, humanité) |
| `src/map.js` | Moteur de carte : chargement (`load`), portes, collisions (tuiles et décor), ligne de vue, carte de distances pour la poursuite |
| `src/maps.js` | Les cartes : planque, rue, entrepôt, club, labo (tuiles, portes, lumières, ennemis, terminal, cadre, PNJ) |
| `src/decor.js` | Décor des quartiers : cases occupées, dessin fixe (arbres, étals, toris, épaves...) et animé (flammes, hologrammes, fontaine, lanternes) |
| `src/districts.js` | Les quartiers et la ligne NCART : Japantown, City Center, Pacifica, leurs bâtiments (pachinko, tour, hôtel), le métro de Watson |
| `src/legacy.js` | Héritage : sauvegarde de la ville (`cel-ville`), noms, origines, profils, recrues, anciens compagnons, fixer, fin d'un leader |
| `src/game.js` | Règles : leader et gigs, cartes et portes (`enterMap`), bâtiments (`spawnSite`), rue (`streetLegacy`, passants), contrats et fins, joueur, implants (`refreshMods`), eddies, ripperdoc, compagnon (IA, loyauté), ennemis, alliés, rivaux, cyberpsycho, balles, Sandevistan, humanité |
| `src/sprites.js` | Sprites des personnages : formes vues de dessus pixellisées par direction (16), poses (dont la chute), coiffures, tenues au hasard, marche, contour, ombrage, cache |
| `src/cars.js` | Véhicules : modèles, sprites pixellisés en 32 directions, collisions (3 cercles), conduite, voitures garées |
| `src/netrun.js` | Netrunning : RAM, scan, quickhacks, caméras, tourelles, breach protocol, et leur affichage |
| `src/ncpd.js` | NCPD : crimes et témoins, étoiles de recherche, panique et blessures des passants, patrouilles et voitures de police, semer la police |
| `src/ambiance.js` | Ambiance des rues : météo du gig, pluie, flaques, bouches d'égout, enseignes néon animées, AV |
| `src/gore.js` | Gore : giclées, éclaboussures sur les murs, morceaux, corps qui éclatent, gouttes des blessés, traces de pas |
| `src/cheats.js` | Deck de triche : mods (interrupteurs lus par le jeu via `G.cheats`), scripts, menu façon cyberdeck piraté |
| `src/arsenal.js` | Armes : au sol, ramassage, armurier, balles guidées, parade au katana, icônes |
| `src/gangs.js` | Gangs : bandes par quartier, réputation, gangers neutres ou hostiles, piratages des Voodoo Boys |
| `src/traffic.js` | Trafic : réseau routier, voitures qui roulent, dépassements, vol de voitures, poursuites du NCPD |
| `src/contracts.js` | Nouveaux contrats : braquage discret, extraction, sabotage, vol de voiture (objectifs, règles, marqueurs) |
| `src/skills.js` | Compétences : expérience, niveaux, arbre à 4 branches, effets (mods), écran |
| `src/music.js` | Musique synthétisée : morceaux par endroit, couche combat, séquenceur, radio et animateurs |
| `src/planque.js` | Planque vivante et sauvegarde : journal du gig, répliques des PNJ, N54 NEWS, bar de Luna, sauvegarde de la partie (`cel-partie`) |
| `src/render.js` | Rendu : image de chaque carte (sol, murs, rue, toits, voitures, portes), sprites, flèche vers l'objectif, éclairage néon, effets, HUD, boutique du ripperdoc, tableau des contrats, écrans titre, de création et de fin, mur des légendes |
| `src/main.js` | Boucle à pas fixe (60 Hz) et accès de test `window.__CEL` |

## Versions

| Version | Titre |
| --- | --- |
| 0.21.0 | Planque vivante et sauvegarde |
| 0.20.0 | Musique et radio |
| 0.19.0 | Compétences |
| 0.18.0 | Nouveaux contrats |
| 0.17.0 | Trafic et poursuites |
| 0.16.0 | Gangs et arsenal |
| 0.15.0 | Deck de triche |
| 0.14.0 | Gore et déplacement à la souris |
| 0.13.0 | Finitions visuelles |
| 0.12.0 | NCPD |
| 0.11.0 | Netrunner |
| 0.10.0 | Métro et quartiers |
| 0.9.0 | Véhicules |
| 0.8.0 | Nouveaux sprites |
| 0.7.0 | Le quartier |
| 0.6.0 | Fixer et contrats |
| 0.5.0 | Ripperdoc et chrome |
| 0.4.0 | Premier compagnon |
| 0.3.0 | Mort et héritage |
| 0.2.0 | Option 480×270 |
| 0.1.0 | Prototype de combat |
