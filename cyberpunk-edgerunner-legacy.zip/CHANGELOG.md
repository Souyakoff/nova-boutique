# Journal des versions

## 0.21.0 — Planque vivante et sauvegarde
- Sauvegarde de la partie : le leader en cours (eddies, chrome, armes, compétences, compagnon, voiture, PV, humanité) est enregistré au début de chaque gig et en sortant de la planque
- Écran titre : CONTINUER reprend le leader sauvegardé, au début de son gig, à la planque (un contrat accepté mais pas rempli est perdu). N deux fois : nouveau leader, l'ancien est inscrit au mur des légendes comme DISPARU et son compagnon reste dans la ville
- Mourir efface la sauvegarde : pas de retour en arrière. Effacer la ville efface aussi la partie
- Journal du gig : ennemis à terre, corps éclatés, exécutions, épargnés, civils, flics, étoiles, voitures volées, piratages, guerres et victimes de gangs, contrat réussi ou raté, PV et humanité à la fin
- Les PNJ de la planque commentent ton dernier gig quand tu passes près d'eux (bulles) : le doc tes blessures et ton humanité, le fixer ton contrat et le NCPD, Rusty tes armes et tes victimes, la recrue ta façon de faire ; au premier gig, ils parlent du leader précédent
- Écran N54 NEWS au mur : tes exploits en gros titres (carnage, cambriolage fantôme, tuerie, MaxTac, vols de voitures, guerre de gangs, cyberpsycho en liberté), entre pubs et météo ; bandeau en bas de l'écran quand tu t'en approches
- Luna et son bar : synthé-saké (+30 PV, 20 €$), larme d'ange (+10 humanité, une par gig, 80 €$), tuyau (ennemis révélés dans le prochain bâtiment, 50 €$), tournée pour l'équipe (+15 loyauté du compagnon, 60 €$) ; elle a toujours un ragot sur ce que tu as fait

## 0.20.0 — Musique et radio
- Musique synthétisée en direct, comme les bruitages (aucun fichier audio) : un séquenceur joue basse, arpèges, nappes et batterie sur l'horloge audio
- Un morceau par endroit, avec fondu enchaîné : écran titre (nappes lentes), planque (lo-fi), Watson (synthwave), Japantown (gamme japonaise, pluck en écho, demi-tempo), City Center (techno propre), Pacifica (sombre, basse saturée, phrygien), bâtiments (pulsation tendue), métro (ambient)
- Couche combat : grosse caisse, caisse claire et basse saturée montent quand des ennemis sont en alerte ou que le NCPD te voit, et redescendent après
- Radio au volant : Radio Kabuki 88.1, Neo-Shaman FM 95.3, Pacific Dreams 102.7, Corpo Beats 107.7 (R pour changer). Les animateurs parlent en sous-titres : présentations, infos de Night City, et ce que tu fais (contrats réussis ou ratés, étoiles du NCPD, MaxTac, guerres de gangs, corps éclatés, voitures volées, niveaux gagnés)
- M coupe ou remet la musique (gardé d'une partie à l'autre), rappel sur l'écran titre

## 0.19.0 — Compétences
- Expérience : 10 XP par ennemi mis à terre (15 s'il éclate), 5 par exécution, 3 par quickhack, 10 par daemon de breach, 100 par contrat (400 pour le grand). Niveau et barre d'XP dans le HUD, un point de compétence par niveau
- K ouvre l'arbre des compétences (jeu en pause) : 4 branches de 4 compétences, chacune demande celle du dessus
  - Flingue : main sûre (dispersion -30 %), recharge éclair, balles lourdes (+25 %), tir rapide (+30 % de cadence)
  - Lame : tranchant (+30 %), allonge, danse des lames (coups plus rapprochés), lame vampire (chaque coup rend 4 PV)
  - Netrunner : mémoire vive (+2 RAM), compilateur (envoi plus rapide), refroidissement (RAM plus rapide), contagion (court-circuit et surchauffe sautent sur un 2e ennemi)
  - Survie : peau dure (+20 PV max), réflexes (dash plus souvent), adrénaline (chaque mise à terre rend 6 PV), second souffle (une fois par gig, un coup mortel te laisse à 1 PV)
- Le niveau atteint s'affiche sur l'écran de fin ; nouveau script de triche +1 niveau

## 0.18.0 — Nouveaux contrats
- Braquage discret : voler le colis dans le coffre du bâtiment et ressortir. Un ennemi qui te voit et reste debout 2,5 s donne l'alerte (raté), une caméra aussi ; ceux qu'on met à terre d'un seul coup ne crient pas. Le HUD dit combien de temps il te reste avant qu'ils ne donnent l'alerte
- Extraction : libérer l'otage (assis, mains liées), puis le ramener dehors vivant. Il te suit, les ennemis lui tirent dessus, ses PV sont dans le HUD ; s'il meurt, c'est raté
- Sabotage : poser la bombe sur le générateur (E maintenu 2 s), puis dégager. 20 s plus tard, tout saute : flash, souffle, les ennemis autour éclatent, et toi aussi si tu es trop près
- Vol de voiture : une Quadra Turbo-R dorée attend dans les rues d'un quartier ; la voler et la livrer au point de dépôt indiqué
- Objectif sur place signalé par un losange jaune et une flèche, comme les portes ; le tableau du fixer indique les contrats de rue (« RUES DE WATSON »)

## 0.17.0 — Trafic et poursuites
- Circulation dans les quatre quartiers (12 voitures à City Center, 8 à Watson, 6 à Japantown, 3 à Pacifica) : chacune roule sur sa voie, tourne aux carrefours, ralentit avant de tourner, double les voitures garées quand la voie d'en face est libre, et sort du quartier au bord de la carte
- Les voitures freinent devant les passants, les gangers et toi ; reste planté devant et elles klaxonnent (TUUUT !)
- Les voitures garées montent à moitié sur le trottoir pour laisser les deux voies libres
- Voler une voiture : une voiture du trafic arrêtée (le conducteur est jeté dehors et s'enfuit) ou une voiture garée ; un témoin et c'est une étoile (vol de voiture signalé)
- Les voitures arrêtent les balles ; au volant, tu ne prends que la moitié des dégâts. Tirer dans une carrosserie fait paniquer le conducteur, qui file
- Poursuites : à partir de 2 étoiles, la plupart des patrouilles du NCPD arrivent en roulant ; à chaque carrefour elles prennent la route qui les rapproche de toi, foncent droit sur toi quand elles te voient, te percutent si tu conduis, et leurs agents débarquent quand elles sont assez près
- Phares des voitures qui roulent ; nouveau son de klaxon

## 0.16.0 — Gangs et arsenal
### Gangs
- Un gang par quartier, en bandes dans la rue : Maelstrom à Watson (chromés, lents, costauds, fusil à pompe, ils foncent au contact), Tyger Claws à Japantown (SMG, ou katana avec des dashs), Valentinos à City Center (pistolets et SMG, ils tournent autour de toi), Voodoo Boys à Pacifica (netrunners au pistolet smart)
- Tenues propres à chaque gang (crânes rasés et optiques rouges des Maelstrom, crêtes cyan des Tyger Claws, vestes dorées des Valentinos, yeux verts des Voodoo Boys)
- Réputation par gang, gardée par la ville d'un leader à l'autre : tirer près d'eux, les blesser ou les tuer la fait baisser ; abattre un rival fait plaisir aux autres ; elle remonte un peu à chaque gig. Neutres, ils te laissent passer ; hostiles, ils attaquent à vue
- Bandeau du territoire en haut de l'écran (neutres, amicaux ou hostiles), alerte quand un gang te met sur sa liste
- Les Voodoo Boys te piratent : flux de données vert, barre de piratage au-dessus de toi, puis brouillage (tu tires n'importe où, l'image grésille), surchauffe (tu brûles) ou court-circuit (dégâts, ralenti). Les mettre à terre, les aveugler ou les sonner coupe le piratage ; un meilleur cyberdeck résiste plus longtemps
### Arsenal
- Nouvelles armes : SMG, fusil à pompe (7 plombs, le corps éclate à bout portant), fusil de précision (traverse jusqu'à 3 corps), pistolet smart (balles guidées), katana (plus de dégâts, plus d'allonge, renvoie les balles pendant le coup)
- Façon Hotline Miami : chaque ennemi lâche son arme en tombant (chargeur entamé) ; E pour ramasser, ton arme précédente tombe à sa place. Les armes au sol restent sur la carte pendant le gig
- Rusty, l'armurier de la planque, vend toutes les armes et remplit gratuitement le chargeur de celle que tu as en main
- Les ennemis ont leurs propres armes (plombs, rafales, balles guidées) ; les canons des sprites ont la longueur de l'arme
- Nom des armes en main dans le HUD
### Triche
- Nouveaux scripts : arsenal (toutes les armes par terre), gangs : paix, gangs : guerre ; la liste des scripts défile

## 0.15.0 — Deck de triche
- ² (` en QWERTY) ou F2 ouvre un cyberdeck piraté, jeu en pause : séquence de démarrage (firmware, ICE contourné, accès root), puis deux colonnes
- 14 mods à activer : godmode, munitions infinies, one shot, gore max, Sandevistan infini, RAM infinie, humanité blindée, camo optique (ennemis, caméras et tourelles ne te voient plus), super vitesse, bullet time, fantôme du NCPD, voiture turbo, vision nocturne, grosses têtes
- 18 scripts : +10 000 €$, soin complet, chrome de luxe (les meilleurs implants sans perte d'humanité), Quadra Turbo-R à tes pieds, recrue instantanée, purge (tous les ennemis explosent), cyberpsycho à côté, contrat rempli, grand contrat débloqué, NCPD +1 étoile, NCPD oublie-moi, pluie ou beau temps, téléportation dans chaque quartier, à la planque ou devant le bâtiment du contrat
- Les mods restent actifs d'un gig à l'autre ; un tag ROOT clignote dans le HUD tant qu'une triche est active

## 0.14.0 — Gore et déplacement à la souris
- Déplacement relatif à la souris : Z (W en QWERTY) avance vers le curseur et on s'arrête dessus ; S recule, Q / D font un pas de côté (A / D en QWERTY). Les flèches font pareil. La conduite ne change pas
- Chaque balle fait gicler un jet de sang dans le sens du tir ; les gouttes s'écrasent contre les murs et y coulent
- Mise à terre : grosse giclée et une tache qui part dans le sens du coup ; flaques plus grandes
- Coup énorme (Synapse brûlée, lame des bras Gorilla sur un blessé, voiture lancée sur un passant) : le corps éclate en morceaux de chair, d'os et de chrome qui rebondissent, laissent une traînée et restent au sol
- Exécution : gerbe de sang, flash rouge, micro-gel plus long
- Les blessés (ennemis, passants, toi) laissent une piste de gouttes ; marcher dans le sang laisse des traces de pas pendant quelques secondes
- Nouveau son d'éclatement

## 0.13.0 — Finitions visuelles
- Animation de mort : le personnage plie, bascule puis reste au sol ; la flaque de sang ne s'étale qu'une fois le corps tombé (ennemis, flics et passants)
- Tenues variées : six teintes de peau, coiffures (courte, rasée, crête, longue, casquette, casque), cheveux colorés, pantalons ; les passants et les gangers ne se ressemblent plus. Uniformes pour le NCPD (casquette), le SWAT et MaxTac (casques)
- Météo : il pleut sur un peu moins d'un gig sur deux. Rideau de pluie, éclaboussures, ronds dans les flaques, néons qui se reflètent sur le sol mouillé, son de pluie (étouffé à l'intérieur)
- Flaques et bouches d'égout fumantes dans toutes les rues
- Enseignes néon animées sur les façades, avec des mots propres à chaque quartier (RAMEN à Japantown, KIROSHI à City Center, MOTEL à Pacifica...) : fixes, clignotantes, à couleurs alternées ou à lumières qui courent ; la moitié de celles de Pacifica sont mortes et sursautent parfois
- Enseignes verticales en idéogrammes inventés sur les façades est et ouest
- Des AV traversent le ciel (ombre au sol, feux clignotants, réacteurs) ; recherché à 2 étoiles ou plus, un AV du NCPD vient se poster au-dessus de toi, projecteur braqué

## 0.12.0 — NCPD
- Les armes ne sont plus rangées dans la rue (seulement à la planque) : on peut tirer, frapper à la lame, hacker et écraser les passants. Sandevistan et scan marchent aussi dehors
- Les passants ont des PV, saignent, meurent, et paniquent : coups de feu, blessés ou cadavres à proximité les font fuir en criant
- Étoiles de recherche façon GTA, de 1 à 5, seulement si un passant ou un flic a vu le crime : coups de feu ou civil blessé (1), civil tué (2, puis +1 tous les deux meurtres), agent blessé (2), agents à terre (+1 tous les trois), agent achevé (+1)
- Le NCPD arrive en voitures de patrouille garées hors de l'écran, gyrophares allumés, deux agents par voiture ; SWAT à partir de 3 étoiles, MaxTac à 5. Sirène synthétisée tant qu'ils sont là
- Pour les semer : rester hors de leur vue 8 s + 3 s par étoile (jauge « RECHERCHE » sous les étoiles). Se cacher dans un bâtiment ou à la planque marche ; à 3 étoiles, le métro est bouclé
- Bandeau radio du NCPD en haut de l'écran, bords de l'écran rouge et bleu quand ils te voient
- Les quickhacks marchent sur les civils (et sur les flics)
- Rouler trop vite sur un passant le tue ; en dessous, il s'écarte
- Mort sous les balles du NCPD : la fin le dit ; les étoiles retombent à zéro au gig suivant

## 0.11.0 — Netrunner
- Cyberdeck posé d'office (Militech Paraline, 6 RAM). La RAM se recharge toute seule et repart pleine à chaque gig
- Scan : maintenir TAB dans un bâtiment ralentit le monde ; les cibles à portée et en vue sont encadrées, la souris en choisit une, et les touches 1 à 5 (ou un clic sur le panneau) envoient un quickhack. L'envoi prend un instant, une barre le montre au-dessus de la cible
- Quickhacks sur les ennemis : Distraction (il va voir ailleurs), Optique brouillée (aveugle 6 s, il titube), Court-circuit (dégâts et sonné), Surchauffe (brûlure, deck Mk.2), Synapse brûlée (120 dégâts, deck Mk.3). Les deux premiers sont discrets, les autres alertent la cible
- Caméras dans tous les bâtiments : elles balaient un cône visible ; si elles te gardent dans le champ, alarme : les ennemis autour et les tourelles se réveillent. On peut les éteindre, s'en servir pour marquer les ennemis, ou les abattre
- Tourelles : elles se réveillent en te voyant ou à l'alarme. On peut les éteindre, les détruire, ou les retourner : elles tirent alors sur les ennemis
- Breach protocol sur le terminal de chaque bâtiment : grille de codes, on alterne ligne et colonne, le tampon se remplit, chaque daemon dont la séquence apparaît s'installe. Daemons : télécharger les données (contrat de vol de données), couper la sécurité, détourner des eddies, recharger la RAM. Chrono de 20 s au premier choix ; un breach raté déclenche l'alarme
- Le vol de données se fait maintenant au breach protocol (fini le « maintenir E »)
- Deux cyberdecks chez Doc Zhao : Tetratronic Rippler (9 RAM, tampon 6) et Netwatch Netdriver (12 RAM, tampon 7, envoi éclair)
- Le chiffre 8 de la police pixel est redessiné (il ressemblait à une flèche)

## 0.10.0 — Métro et quartiers
- Le métro NCART relie quatre quartiers : Watson (Kabuki), Japantown (Westbrook), City Center (Corpo Plaza) et Pacifica (Coastview)
- Chaque quartier a sa bouche de métro. Le plan de la ligne montre où tu es, où est ton contrat, ta planque et ta voiture ; le trajet se fait dans une rame qui passe du tunnel à la ligne aérienne au-dessus de la ville (E pour passer)
- Japantown : rue commerçante piétonne avec étals, lanternes qui se balancent, toris, sanctuaire, parc aux cerisiers et son étang, toits de tuiles
- City Center : grande place dallée au pied de la tour Kiroshi, fontaine animée, hologrammes publicitaires, jardin, tours de verre, chaussées propres aux marquages blancs
- Pacifica : quartier abandonné, routes défoncées et ensablées, épaves rouillées, bus calciné, bidons en feu, tentes, palmiers, plage et océan
- Watson reçoit distributeurs, sacs poubelle, un bidon en feu et des hologrammes ; passages piétons dans tous les quartiers
- Trois nouveaux bâtiments où se jouent les contrats : le Salon Pachinko (Japantown), la Tour Kiroshi (City Center) et le Grand Imperial en ruine (Pacifica), chacun avec son mobilier et ses couleurs
- Les contrats peuvent tomber dans n'importe quel quartier ; la flèche de la rue mène au métro quand l'objectif est ailleurs
- Passants habillés selon le quartier ; le décor bloque les personnages et les voitures
- Le corps du dernier leader attend devant le bâtiment où il est tombé, dans le bon quartier

## 0.9.0 — Véhicules
- Les voitures sont à l'échelle des personnages (26 à 34 px de long contre ~11 px de large pour un perso) et dessinées en vrais sprites vus de dessus, pixellisés dans 32 directions (carrosserie, pare-brise, toit, phares, feux, roues)
- Les voitures garées ne sont plus des tuiles : ce sont des entités placées au bord des chaussées, qui bloquent les personnages et les autres voitures
- Concessionnaire dans la rue : Vic Trois-Doigts vend trois modèles (Makigai MaiMai, Thorton Galena, Quadra Turbo-R). La voiture achetée attend sur le parking et remplace l'ancienne
- Conduite : monter et descendre avec E (à l'arrêt ou presque), accélérer, freiner, marche arrière, direction qui dépend de la vitesse ; rebond et secousse en cas de choc
- Le compagnon monte avec toi ; les passants s'écartent en criant
- Compteur de vitesse, phares qui éclairent la route, caméra qui regarde devant la voiture, bruit de moteur synthétisé qui suit la vitesse
- Ta voiture reste où tu l'as garée pendant le gig

## 0.8.0 — Nouveaux sprites
- Les personnages ne sont plus des disques : vrais sprites vus de dessus (tête, visage, épaules, bras, mains, jambes, arme), pixellisés net dans 16 directions
- Poses : arme tenue à deux mains, recul au tir, mains nues, poings levés (brutes), coup de lame, à terre, assis mains levées (épargnés)
- Animation de marche (jambes et bras qui se balancent), contour sombre, ombrage venant du haut à gauche, ombre portée au sol
- Le chrome se voit sur le sprite : bras et poings métalliques, lame magenta des Mantis, œil rouge de la Kiroshi ; brutes au crâne rasé, halo du cyberpsycho
- Corps allongés dans le sens du coup reçu, avec une flaque de sang qui s'étale
- Les personnages sont dessinés sur leur propre calque, assombri moitié moins que le décor : lisibles même dans le noir
- Décors : murs avec une face avant (épaisseur), ombre des murs sur le sol, fissures et taches, caisses détaillées, bar et banquettes au club, paillasses et baies de serveurs au labo, fauteuil du ripperdoc, terminal redessiné
- Effets : traçantes en deux tons avec une tête blanche, éclairs de tir au bout du canon
- Couleurs Arasaka et Militech éclaircies pour rester visibles

## 0.7.0 — Le quartier
- Le jeu se joue maintenant sur plusieurs cartes reliées par des portes : la planque, la rue et trois bâtiments
- La planque est un lieu à part : fixer, ripperdoc et recrue y attendent ; chaque gig commence là
- La rue (96×56 tuiles) : chaussées, trottoirs, toits d'immeubles, voitures garées, lampadaires, enseignes, passants ; armes rangées et pas de Sandevistan
- Trois bâtiments où se jouent les contrats : l'entrepôt, le Club Néon (piste, VIP, arrière-salle) et le labo (couloir, labos, salle des serveurs)
- Chaque contrat désigne un bâtiment ; les autres sont fermés. Une flèche dans la rue indique la porte à rejoindre, avec la distance
- Un bâtiment garde son état pendant le gig : on peut en sortir et y revenir
- Rentrer à la planque après un contrat rempli ou raté lance le gig suivant (plus de touche Entrée)
- Héritage placé dans le quartier : les épargnés reconnaissants attendent devant la planque, les rivaux reviennent dans le bâtiment où ils ont été épargnés, le corps du leader est jeté devant le bâtiment où il est tombé, et un cyberpsycho rôde dans le bâtiment du prochain contrat
- La révélation des positions offerte par un allié s'applique au prochain bâtiment
- Kang Tao passe en couleur jade (le jaune reste celui du leader)

## 0.6.0 — Fixer et contrats
- Mama Reyes, fixer de la planque : trois contrats par gig, à accepter avant que ça tire (jeu en pause pendant le choix)
- Trois factions : Arasaka et Militech (avec un arc), Kang Tao (contrats ponctuels mieux payés)
- Trois types de contrat : élimination (cible marquée, plus résistante), vol de données (maintenir E sur le terminal, l'alarme sonne), nettoyage
- Les ennemis portent les couleurs de la faction visée ; le contrat rempli paie et permet de passer au gig suivant
- Trois contrats remplis contre Arasaka ou Militech débloquent le grand contrat : abattre le cadre avant qu'il ne file (90 s après l'alerte)
- Fins : mort pendant le grand contrat = légende ; réussite = le leader devient fixer (réputation de 1 à 3 étoiles selon le compagnon) ; échec = le leader survit, grillé (paie divisée par deux)
- Le dernier leader devenu fixer remplace Mama Reyes et paie +10 % par étoile
- Mur des légendes : fins « légende » et « fixer »
- Les menus ne prennent la souris en compte que quand elle bouge ; les textes flottants ne se chevauchent plus

## 0.5.0 — Ripperdoc et chrome
- Eddies : 200 au départ, +60 par racaille, +120 par brute, +80 pour un rival, +500 pour un cyberpsycho, +250 par salle nettoyée
- Doc Zhao, ripperdoc de la planque : poser, remplacer ou retirer des implants (jeu en pause pendant la visite)
- Sept implants : Sandevistan Mk.2, bras Gorilla, lames Mantis, optique Kiroshi, peau sous-dermique, jambes renforcées, biomoniteur
- Chaque implant coûte de l'humanité ; en retirer un en rend 75 % ; le doc refuse ce qui te ferait passer sous 10
- Immunosuppresseurs : 400 €$ pour 10 points d'humanité
- Le chrome se voit : épaules métalliques, lame magenta avec les Mantis, œil rouge avec la Kiroshi
- La Kiroshi affiche les PV des ennemis et le regard de ceux qui ne t'ont pas vu
- Héritage : le corps garde la moitié des eddies du leader ; un cyberpsycho a +40 PV par implant

## 0.4.0 — Premier compagnon
- Une recrue attend dans la planque : un mercenaire, ou un ancien compagnon de la ville
- Un allié revenu de l'héritage peut aussi rejoindre l'équipe (E après son cadeau)
- Le compagnon suit le leader (par la carte de distances quand il ne le voit pas) et couvre : il ne tire que sur les ennemis déjà en alerte
- Ordres avec G : suivre ou tenir la position
- Les ennemis visent le plus proche entre le leader et le compagnon
- À 0 PV, le compagnon tombe à terre : E pour le relever pendant le gig
- Loyauté : monte avec les gigs réussis, les épargnés et les relèves, baisse avec les exécutions sous ses yeux et le Sandevistan quand tu deviens instable ; à 0, il part
- Le compagnon debout survit à la mort du leader : il peut reprendre la tête à l'écran de création, ou attendre dans la planque du leader suivant

## 0.3.0 — Mort et héritage
- Écran de création : trois profils au choix (gosse des rues, nomade, corpo déchu), parfois liés au leader précédent
- Gigs successifs avec le même leader : PV, injecteurs, munitions et humanité sont gardés
- La ville est sauvegardée dans le navigateur : leaders passés, épargnés, corps, cyberpsycho
- Un ennemi épargné revient chez le leader suivant : en allié (injecteur et positions révélées) ou en rival plus résistant
- Le corps du leader mort reste dans la ville : on peut le fouiller pour récupérer ses injecteurs
- Un leader passé en cyberpsychose revient en boss, avec des dashs façon Sandevistan
- Mur des légendes sur l'écran titre, effacement de la ville avec Suppr (deux fois)
- Les ennemis ne traversent plus le joueur

## 0.2.0 — Option 480×270
- Nouvelle résolution interne 480×270 (agrandie ×4 en 1080p) : on voit plus loin autour de soi
- Touche V sur l'écran titre pour passer de 320×180 à 480×270, choix gardé d'une partie à l'autre
- L'écran titre, l'écran de fin, l'éclairage et la vignette s'adaptent à la résolution
- La caméra centre la carte quand elle est plus petite que l'écran

## 0.1.0 — Prototype de combat
- Rendu pixel art en 320×180, agrandi à l'échelle entière sans flou
- Déplacement ZQSD/WASD, visée à la souris, caméra qui regarde vers le curseur
- Pistolet (chargeur de 12, rechargement), lame au clic droit, dash invulnérable
- Trois injecteurs de soin, pas de régénération
- Racailles armées et brutes au corps à corps : vision en cône, alerte au bruit, poursuite autour des murs
- Ennemis à terre à 0 PV : les achever ou les épargner
- Sandevistan : ralentit le monde, coûte 5 points d'humanité par activation
- Humanité : hallucinations sous 50, image qui se déchire sous 30, cyberpsychose à 0
- Écran de fin avec le registre de la partie, dernier leader rappelé sur l'écran titre
- Page Streaz : manifeste, images, bouton « Quitter le jeu » dans Streaz
