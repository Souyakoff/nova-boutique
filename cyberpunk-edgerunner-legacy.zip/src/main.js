'use strict';
// Démarrage et boucle principale : simulation à pas fixe (60 fois par seconde), rendu à chaque image.
(function () {
  const C = CEL;
  const NOVA = window.CEL_NOVA;   // intégration NOVA (voir nova.js), absente hors de NOVA
  if (NOVA && NOVA.syncing) return;   // NOVA recopie la sauvegarde du profil : la page va se recharger
  C.initCanvas();
  let acc = 0, last = performance.now(), running = true;

  function frame(t) {
    if (!running) return;
    const dt = Math.min(0.1, (t - last) / 1000);   // au-delà de 0,1 s (onglet en pause), on n'essaie pas de rattraper
    last = t;
    if (NOVA && NOVA.paused) { requestAnimationFrame(frame); return; }   // menu rapide de NOVA ouvert : le monde est figé
    acc += dt;
    while (acc >= C.STEP) { C.game.update(C.STEP); acc -= C.STEP; }
    C.render.draw(t / 1000);
    C.present();
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // Accès pour les tests automatiques : avancer la simulation pas à pas sans dépendre de l'horloge.
  window.__CEL = {
    stop() { running = false; },
    step(n = 1) { for (let i = 0; i < n; i++) C.game.update(C.STEP); C.render.draw(performance.now() / 1000); C.present(); },
  };
})();
