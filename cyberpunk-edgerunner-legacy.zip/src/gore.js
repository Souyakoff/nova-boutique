'use strict';
// Gore : giclées de sang, éclaboussures sur les murs, morceaux qui volent, corps qui explosent, traces de pas.
// Purement visuel : utilise Math.random (et pas le hasard du jeu), pour ne rien changer aux combats.
//
// Les gouttes (particules 'blood') s'écrasent au sol ou contre un mur et deviennent des taches permanentes
// (calque des décalques de la carte). Les morceaux ('gib') rebondissent, laissent une traînée, puis restent au sol.
// Chaque tache compte dans G.bloodMap (par tuile) : marcher dans une mare rouge laisse des traces de pas.
(function () {
  const C = CEL, M = C.map;
  const GO = (C.gore = {});
  const G = () => C.game;
  const R = (a, b) => a + Math.random() * (b - a);
  const REDS = ['#8c0f22', '#b5172e', '#6e0a18', '#c41e38'];
  const red = () => REDS[(Math.random() * REDS.length) | 0];

  function drop(x, y, vx, vy, life, size) {
    G().parts.push({ x, y, vx, vy, life, max: life, color: red(), kind: 'blood', size: size || 1 });
  }
  // Impact de balle : jet de sortie dans le sens du tir, plus quelques gouttes en arrière.
  GO.hit = function (x, y, ang, big) {
    const n = big ? 16 : 9;
    for (let i = 0; i < n; i++) { const a = ang + R(-0.28, 0.28), s = R(120, 240); drop(x, y, Math.cos(a) * s, Math.sin(a) * s, R(0.12, 0.3), Math.random() < 0.3 ? 2 : 1); }
    for (let i = 0; i < 3; i++) { const a = ang + Math.PI + R(-0.6, 0.6), s = R(30, 70); drop(x, y, Math.cos(a) * s, Math.sin(a) * s, R(0.1, 0.2), 1); }
  };
  // Mise à terre : grosse giclée et une flaque qui part dans le sens du coup.
  GO.down = function (x, y, ang) {
    for (let i = 0; i < 26; i++) { const a = ang + R(-0.9, 0.9), s = R(40, 200); drop(x, y, Math.cos(a) * s, Math.sin(a) * s, R(0.15, 0.5), Math.random() < 0.4 ? 2 : 1); }
    if (C.render) C.render.splat(x + Math.cos(ang) * 6, y + Math.sin(ang) * 6, 5);
  };
  // Le corps éclate : morceaux de chair, d'os et de chrome, gerbe de sang, grosse tache.
  GO.burst = function (x, y, ang, chrome) {
    const g = G();
    for (let i = 0; i < 40; i++) { const a = R(0, Math.PI * 2), s = R(40, 260); drop(x, y, Math.cos(a) * s, Math.sin(a) * s, R(0.15, 0.6), Math.random() < 0.5 ? 2 : 1); }
    const n = 9 + ((Math.random() * 5) | 0);
    for (let i = 0; i < n; i++) {
      const a = ang + R(-1.6, 1.6), s = R(60, 200), k = Math.random();
      const color = chrome && k < 0.2 ? '#b8c4d6' : k < 0.35 ? '#e8d8c0' : k < 0.7 ? '#7a1020' : '#a83040';
      g.parts.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: R(0.5, 0.9), max: 1, color, kind: 'gib', w: 2 + ((Math.random() * 2) | 0), h: 2, trail: 0 });
    }
    if (C.render) { C.render.splat(x, y, 9); C.render.splat(x + Math.cos(ang) * 10, y + Math.sin(ang) * 10, 6); }
    g.shake = Math.max(g.shake, 5);
    g.redFlash = Math.max(g.redFlash, 0.18);
    C.sfx('gib');
    C.music.event('gib');
    C.home.note('gibs');
  };
  // Exécution : giclée vers le haut de l'écran et éclaboussure sur le joueur.
  GO.execute = function (x, y, ang) {
    for (let i = 0; i < 30; i++) { const a = ang + R(-0.5, 0.5), s = R(80, 230); drop(x, y, Math.cos(a) * s, Math.sin(a) * s, R(0.15, 0.45), Math.random() < 0.5 ? 2 : 1); }
    if (C.render) C.render.splat(x + Math.cos(ang) * 8, y + Math.sin(ang) * 8, 7);
    const g = G();
    g.redFlash = Math.max(g.redFlash, 0.12);
    g.player.bloodyT = 6;   // il marche dans le sang qu'il vient de verser
  };

  // Particules de gore : appelé par updateParts pour 'blood' et 'gib'. Renvoie true si traité.
  GO.updatePart = function (q, dt) {
    if (q.kind === 'gib') {
      const f = Math.pow(0.02, dt);
      q.vx *= f; q.vy *= f;
      let nx = q.x + q.vx * dt, ny = q.y + q.vy * dt;
      // rebond contre les murs (et une tache là où il s'écrase)
      if (M.solidAt(nx, q.y)) { if (Math.abs(q.vx) > 50 && C.render) C.render.splat(q.x, q.y, 2); q.vx *= -0.4; nx = q.x; }
      if (M.solidAt(nx, ny)) { if (Math.abs(q.vy) > 50 && C.render) C.render.splat(q.x, q.y, 2); q.vy *= -0.4; ny = q.y; }
      // traînée de sang derrière le morceau
      q.trail += Math.hypot(nx - q.x, ny - q.y);
      if (q.trail > 2 && C.render) { q.trail = 0; C.render.decal(q.x, q.y, red()); }
      q.x = nx; q.y = ny;
      if (q.life <= 0 && C.render) C.render.gib(q.x, q.y, q.color, q.w, q.h);
      return true;
    }
    if (q.kind === 'blood') {
      const f = Math.pow(0.0005, dt);
      const nx = q.x + q.vx * dt, ny = q.y + q.vy * dt;
      if (M.solidAt(nx, ny)) {
        // la goutte s'écrase contre le mur : éclaboussure qui coule
        if (Math.hypot(q.vx, q.vy) > 40 && C.render) C.render.wallSplat(q.x, q.y, q.vx, q.vy);
        q.vx = 0; q.vy = 0;
      } else { q.x = nx; q.y = ny; }
      q.vx *= f; q.vy *= f;
      if (q.life <= 0 && C.render) C.render.decal(q.x, q.y, q.color, q.size || 1);
      return true;
    }
    return false;
  };

  // Chaque image : les blessés saignent, et le joueur laisse des traces de pas s'il a marché dans le sang.
  let dripT = 0;
  GO.update = function (dt) {
    const g = G(), p = g.player;
    dripT -= dt;
    if (dripT <= 0) {
      dripT = 0.12;
      const hurt = o => o.maxHp && o.hp > 0 && o.hp < o.maxHp * 0.6;
      for (const e of g.enemies) if (g.ALIVE(e) && hurt(e) && Math.random() < 0.5) drop(e.x + R(-2, 2), e.y + R(-1, 2), 0, 0, 0.01, 1);
      for (const q of g.peds || []) if (!q.dead && q.hp < 20 && Math.random() < 0.5) drop(q.x + R(-2, 2), q.y + R(-1, 2), 0, 0, 0.01, 1);
      if (p.hp < p.maxHp * 0.4 && Math.random() < 0.6) drop(p.x + R(-2, 2), p.y + R(-1, 2), 0, 0, 0.01, 1);
    }
    // traces de pas
    if (!g.drive && C.render && C.render.bloodAt(p.x, p.y) > 6) p.bloodyT = 5;
    if (p.bloodyT > 0) {
      p.bloodyT -= dt;
      const d = p.stepX == null ? 0 : Math.hypot(p.x - p.stepX, p.y - p.stepY);
      if (p.stepX == null || d > 5) {
        if (p.stepX != null && C.render) {
          const a = Math.atan2(p.y - p.stepY, p.x - p.stepX), side = (p.stepSide = -(p.stepSide || 1));
          const fx = p.x - Math.sin(a) * 1.5 * side, fy = p.y + 3 + Math.cos(a) * 1.5 * side;
          const col = p.bloodyT > 2.5 ? '#6e0a18' : '#4a0812';
          C.render.decal(fx, fy, col, 1, false); C.render.decal(fx + Math.cos(a), fy + Math.sin(a), col, 1, false);
        }
        p.stepX = p.x; p.stepY = p.y;
      }
    } else p.stepX = null;
  };
})();
