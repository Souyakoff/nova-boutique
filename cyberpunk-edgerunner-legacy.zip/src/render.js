'use strict';
// Rendu pixel art : sol et murs pré-dessinés, sprites, éclairage néon, effets, HUD et écrans.
(function () {
  const C = CEL, D = C.DEF, M = C.map;
  const R = (C.render = {});
  const IS_STREAZ = /Streaz\//.test(navigator.userAgent) || !!window.NOVA;   // bouton « Quitter » : Streaz ou NOVA

  const PAL = {
    player: { jacket: '#f2d43a', hair: '#3b1f63', skin: '#e8b48f' },
    gun: '#14141b',
    outline: '#06060b',
  };

  let world = null;   // sol + murs (statique)
  let decals = null;  // sang et douilles (s'accumulent)
  let bloodMap = null; // quantité de sang par tuile (traces de pas)
  let dctx = null;
  let lightMask = null, glow = null, lm = null, ac = null, vignette = null, skyline = null;
  const sprites = {};

  // ---------- outils de dessin ----------
  function canvas(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }

  // Ligne pixel par pixel (Bresenham) : reste nette en basse résolution.
  function pline(g, x0, y0, x1, y1, color) {
    x0 = Math.round(x0); y0 = Math.round(y0); x1 = Math.round(x1); y1 = Math.round(y1);
    const dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1;
    let err = dx + dy;
    g.fillStyle = color;
    for (let n = 0; n < 64; n++) {
      g.fillRect(x0, y0, 1, 1);
      if (x0 === x1 && y0 === y1) break;
      const e2 = 2 * err;
      if (e2 >= dy) { err += dy; x0 += sx; }
      if (e2 <= dx) { err += dx; y0 += sy; }
    }
  }

  function shade(hex, k) {
    const n = parseInt(hex.slice(1), 16);
    const f = v => Math.max(0, Math.min(255, Math.round(v * k)));
    return '#' + ((1 << 24) | (f(n >> 16) << 16) | (f((n >> 8) & 255) << 8) | f(n & 255)).toString(16).slice(1);
  }

  // Personnage : délégué au système de sprites (sprites.js). o.size === 9 = grand gabarit (brute, cadre).
  function drawChar(g, x, y, aim, o) {
    C.sprites.draw(g, x, y, aim, {
      jacket: o.jacket, hair: o.hair, skin: o.skin, pants: o.pants, chrome: o.chrome, eye: o.eye, blade: o.blade, style: o.style, cap: o.cap,
      gunLen: o.gunLen, bladeLen: o.bladeLen, gunColor: o.gunColor,
      scale: (o.scale || (o.size === 9 ? 1.25 : 1)) * (C.game.cheats && C.game.cheats.bighead ? 1.4 : 1), pose: o.pose || (o.gun ? 'gun' : 'bare'),
      frame: o.frame == null ? 1 : o.frame, flash: o.flash, alpha: o.alpha, solid: o.solid, shadow: o.shadow,
    });
  }
  const frameOf = e => C.sprites.walkFrame(e.walk || 0, e.moving);

  // Flaque de sang sous un corps, qui s'étale avec le temps (ellipse pleine, pixels nets).
  function bloodPool(g, x, y, r) {
    r = Math.round(r);
    for (let dy = -r; dy <= r; dy++) {
      const w = Math.round(Math.sqrt(Math.max(0, r * r - dy * dy)) * 1.4);
      g.fillStyle = Math.abs(dy) === r ? '#3a0610' : '#5a0a16';
      g.fillRect(Math.round(x) - w, Math.round(y) + dy, w * 2 + 1, 1);
    }
    g.fillStyle = '#7a1020'; g.fillRect(Math.round(x) - 1, Math.round(y) - Math.max(0, r - 2), 2, 1);   // reflet
  }

  // ---------- monde statique ----------
  // Chaque carte a son image de fond (sol, murs, toits), ses taches de sang et son éclairage, gardés en cache
  // pendant un gig : le sang reste dans l'entrepôt si on en ressort puis qu'on y retourne.
  let worlds = {};
  R.clearWorlds = () => { worlds = {}; };
  R.useWorld = function (id) {
    if (!worlds[id]) worlds[id] = buildWorld();
    ({ world, decals, lightMask, glow, blood: bloodMap } = worlds[id]);
    C.amb.cur = worlds[id].amb;
    dctx = decals.getContext('2d');
  };
  R.resetWorld = () => { R.clearWorlds(); R.useWorld(M.id); };

  // Bruit déterministe par tuile : le décor ne consomme pas le hasard du jeu.
  const hash = (x, y, i = 0) => { let h = (x * 374761393 + y * 668265263 + i * 2147483647) | 0; h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; };
  const NEON = ['#ff3ec8', '#3ef0ff', '#ffd23e', '#7a5cff', '#5dff9a'];

  // Mobilier : caisses dans l'entrepôt et la planque, bar et banquettes au club, paillasses et baies au labo.
  function drawProp(g, x, y, tx, ty) {
    const id = M.id, T0 = (a, b) => M.tile(a, b);
    const vert = T0(tx, ty - 1) === 'c' || T0(tx, ty + 1) === 'c';
    const horiz = T0(tx - 1, ty) === 'c' || T0(tx + 1, ty) === 'c';
    g.fillStyle = 'rgba(0,0,0,0.4)'; g.fillRect(x + 1, y + 1, 8, 8);   // ombre
    const fu = M.def.furniture;
    if (fu === 'pachinko' && horiz && ty < 18) {
      // machine de pachinko : caisson chromé, écran qui clignote, billes argentées
      g.fillStyle = '#2a2430'; g.fillRect(x, y, 8, 8);
      g.fillStyle = '#c8c8d8'; g.fillRect(x, y, 8, 1);
      const sc = ['#ff3e7a', '#f2d43a', '#3ef0ff', '#5dff9a'][(hash(tx, ty) * 4) | 0];
      g.fillStyle = shade(sc, 0.5); g.fillRect(x + 1, y + 2, 6, 4);
      g.fillStyle = sc; g.fillRect(x + 2, y + 3, 4, 2);
      g.fillStyle = '#e8e8f0'; g.fillRect(x + 1 + ((hash(tx, ty, 1) * 6) | 0), y + 2, 1, 1); g.fillRect(x + 1 + ((hash(tx, ty, 2) * 6) | 0), y + 5, 1, 1);
      g.fillStyle = '#120e16'; g.fillRect(x, y + 7, 8, 1);
      return;
    }
    if (fu === 'office' && vert && !horiz) {
      // baie de serveurs (comme au labo)
      g.fillStyle = '#1b1f28'; g.fillRect(x, y, 8, 8);
      g.fillStyle = '#2c3340'; g.fillRect(x, y, 8, 1); g.fillRect(x, y, 1, 8);
      for (let i = 0; i < 3; i++) { g.fillStyle = hash(tx, ty, i) < 0.6 ? '#5dff9a' : '#3ef0ff'; g.fillRect(x + 2 + i * 2, y + 2 + ((hash(tx, ty, i + 4) * 4) | 0), 1, 1); }
      return;
    }
    if (fu === 'office') {
      // bureau blanc, écran allumé, tasse
      g.fillStyle = '#b8c0cc'; g.fillRect(x, y, 8, 8);
      g.fillStyle = '#dde3ea'; g.fillRect(x, y, 8, 2);
      g.fillStyle = '#7a8492'; g.fillRect(x, y + 7, 8, 1);
      if (hash(tx, ty) < 0.6) { g.fillStyle = '#1a1d2e'; g.fillRect(x + 2, y + 2, 4, 3); g.fillStyle = '#3ef0ff'; g.fillRect(x + 3, y + 3, 2, 1); }
      else { g.fillStyle = '#f2f2f2'; g.fillRect(x + 5, y + 4, 2, 2); }
      return;
    }
    if (fu === 'ruin') {
      // gravats, matelas éventrés, comptoirs renversés
      const r = hash(tx, ty, 5);
      if (r < 0.4) {
        g.fillStyle = '#4a443c'; g.fillRect(x, y + 2, 7, 6); g.fillStyle = '#5e564c'; g.fillRect(x + 1, y + 1, 4, 3); g.fillStyle = '#2e2a24'; g.fillRect(x + 4, y + 5, 4, 3);
        g.fillStyle = '#6a5a48'; g.fillRect(x + 2, y + 6, 1, 1);
      } else if (r < 0.7) {
        g.fillStyle = '#6a5a4a'; g.fillRect(x, y, 8, 8); g.fillStyle = '#8a7a64'; g.fillRect(x + 1, y + 1, 6, 2); g.fillStyle = '#3a2a20'; g.fillRect(x + 2, y + 4, 3, 2);
      } else {
        g.fillStyle = '#3a3a40'; g.fillRect(x, y, 8, 8); g.fillStyle = '#54545c'; g.fillRect(x, y, 8, 2); g.fillStyle = '#5a3a22'; g.fillRect(x + 5, y + 4, 2, 2);
      }
      return;
    }
    if (id === 'labo' && vert && !horiz) {
      // baie de serveurs : métal sombre, diodes
      g.fillStyle = '#1b1f28'; g.fillRect(x, y, 8, 8);
      g.fillStyle = '#2c3340'; g.fillRect(x, y, 8, 1); g.fillRect(x, y, 1, 8);
      g.fillStyle = '#0d0f14'; g.fillRect(x + 7, y, 1, 8);
      for (let i = 0; i < 3; i++) { g.fillStyle = hash(tx, ty, i) < 0.6 ? '#3ef0ff' : '#5dff9a'; g.fillRect(x + 2 + i * 2, y + 2 + ((hash(tx, ty, i + 4) * 4) | 0), 1, 1); }
    } else if (id === 'labo') {
      // paillasse : plateau blanc, éprouvettes
      g.fillStyle = '#c8d2dc'; g.fillRect(x, y, 8, 8);
      g.fillStyle = '#e8eef4'; g.fillRect(x, y, 8, 2);
      g.fillStyle = '#8a96a2'; g.fillRect(x, y + 7, 8, 1);
      if (hash(tx, ty) < 0.5) { g.fillStyle = '#5dff9a'; g.fillRect(x + 2, y + 3, 1, 2); g.fillStyle = '#3ef0ff'; g.fillRect(x + 4, y + 3, 1, 2); }
    } else if (id === 'club' && vert) {
      // bar : comptoir sombre et bouteilles
      g.fillStyle = '#2a1420'; g.fillRect(x, y, 8, 8);
      g.fillStyle = '#4a2438'; g.fillRect(x, y, 2, 8);
      g.fillStyle = '#120a10'; g.fillRect(x + 7, y, 1, 8);
      const cols = ['#5dff9a', '#ff3ec8', '#ffd23e', '#3ef0ff'];
      for (let i = 0; i < 2; i++) { g.fillStyle = cols[(hash(tx, ty, i) * 4) | 0]; g.fillRect(x + 3 + i * 2, y + 2 + i * 3, 1, 2); }
    } else if (id === 'club') {
      // banquette de velours
      g.fillStyle = '#5a1a52'; g.fillRect(x, y, 8, 8);
      g.fillStyle = '#7a2a6a'; g.fillRect(x + 1, y + 1, 6, 3);
      g.fillStyle = '#3a0f36'; g.fillRect(x, y + 6, 8, 2);
    } else {
      // caisse : planches, bandes de renfort et coins métalliques
      g.fillStyle = '#4a3a28'; g.fillRect(x, y, 8, 8);
      g.fillStyle = '#5e4a34'; g.fillRect(x, y + 1, 8, 2); g.fillRect(x, y + 5, 8, 2);
      g.fillStyle = '#6e5840'; g.fillRect(x, y, 8, 1);
      g.fillStyle = '#2a2016'; g.fillRect(x, y + 7, 8, 1); g.fillRect(x + 7, y, 1, 8); g.fillRect(x, y + 4, 8, 1);
      g.fillStyle = '#8a8f9a'; g.fillRect(x, y, 1, 1); g.fillRect(x + 7, y, 1, 1); g.fillRect(x, y + 7, 1, 1); g.fillRect(x + 7, y + 7, 1, 1);
    }
  }

  // Toits selon le quartier. open(a, b) : la tuile voisine est-elle au niveau de la rue ?
  function roofTile(g, style, x, y, tx, ty, open) {
    const r = hash(tx, ty), facade = (c, n) => {
      if (open(tx, ty + 1)) { g.fillStyle = c; g.fillRect(x, y + 6, 8, 2); if (n && hash(tx, ty, 5) < 0.5) { g.fillStyle = n; g.fillRect(x + 1, y + 7, 6, 1); } }
      if (open(tx, ty - 1)) { g.fillStyle = c; g.fillRect(x, y, 8, 2); }
      if (open(tx + 1, ty)) { g.fillStyle = c; g.fillRect(x + 6, y, 2, 8); if (n && hash(tx, ty, 6) < 0.4) { g.fillStyle = n; g.fillRect(x + 7, y + 1, 1, 6); } }
      if (open(tx - 1, ty)) { g.fillStyle = c; g.fillRect(x, y, 2, 8); }
    };
    if (style === 'jp') {
      // tuiles sombres en rangées, faîtages, lanternes et enseignes rouges sur les façades
      g.fillStyle = (ty % 6) < 3 ? '#1e1418' : '#1a1016'; g.fillRect(x, y, 8, 8);
      g.fillStyle = '#140c10'; g.fillRect(x, y + 3, 8, 1); g.fillRect(x, y + 7, 8, 1);
      for (let i = 0; i < 8; i += 2) { g.fillStyle = '#24181e'; g.fillRect(x + i + (ty % 2), y + 1, 1, 1); g.fillRect(x + i + (ty % 2), y + 5, 1, 1); }
      if (ty % 6 === 0) { g.fillStyle = '#3a2228'; g.fillRect(x, y, 8, 1); }
      if (r < 0.03) { g.fillStyle = '#2a3a3a'; g.fillRect(x + 1, y + 1, 5, 5); g.fillStyle = '#3a5a5a'; g.fillRect(x + 2, y + 2, 1, 1); }
      facade('#2a1a20', ['#ff2040', '#ff3e7a', '#f2d43a'][(hash((tx / 5) | 0, (ty / 5) | 0, 3) * 3) | 0]);
    } else if (style === 'glass') {
      // tours de verre : reflet en diagonale, trame de fenêtres, bord éclairé
      const band = ((tx + ty) % 14) < 3;
      g.fillStyle = band ? '#1e2a40' : '#141c2c'; g.fillRect(x, y, 8, 8);
      g.fillStyle = band ? '#283852' : '#1a2438'; g.fillRect(x + 1, y + 1, 3, 3); g.fillRect(x + 5, y + 1, 2, 3); g.fillRect(x + 1, y + 5, 3, 2); g.fillRect(x + 5, y + 5, 2, 2);
      if (r < 0.05) { g.fillStyle = '#ff2040'; g.fillRect(x + 3, y + 3, 1, 1); }   // balise d'antenne
      else if (r < 0.08) { g.fillStyle = '#2a3040'; g.fillRect(x + 1, y + 1, 6, 6); g.fillStyle = '#3ef0ff'; g.fillRect(x + 2, y + 2, 4, 1); }   // héliport
      facade('#2a3448', '#bfe9ff');
    } else if (style === 'ruin') {
      // béton fissuré, trous, ferraille ; les enseignes sont mortes
      g.fillStyle = (hash((tx / 4) | 0, (ty / 4) | 0) < 0.5) ? '#24221e' : '#1e1c1a'; g.fillRect(x, y, 8, 8);
      if (r < 0.08) { g.fillStyle = '#060505'; g.fillRect(x + 1, y + 2, 5, 4); g.fillStyle = '#5a3a22'; g.fillRect(x + 1, y + 2, 1, 4); }   // trou, fers à béton
      else if (r < 0.16) { g.fillStyle = '#34302a'; g.fillRect(x + 2, y + 3, 3, 2); g.fillRect(x + 4, y + 5, 2, 1); }   // gravats
      else if (r < 0.22) { g.fillStyle = '#141210'; let cx = x + 1, cy = y + ((hash(tx, ty, 2) * 4) | 0); for (let i = 0; i < 7; i++) { g.fillRect(cx++, cy, 1, 1); cy += hash(tx, ty, 3 + i) < 0.5 ? 1 : 0; } }
      if (hash(tx, ty, 9) < 0.04) { g.fillStyle = '#2a4a1e'; g.fillRect(x + 4, y + 1, 3, 2); }   // végétation
      facade('#2e2a24', hash((tx / 6) | 0, (ty / 6) | 0, 4) < 0.25 ? '#7a5cff' : null);
    }
  }

  function buildWorld() {
    const w = M.MW * 8, h = M.MH * 8, P = M.def.palette, DEF = M.def;
    const WALL = P.wall || '#2a2d46', WALL_HI = P.wallHi || '#5a6096', WALL_FACE = P.wallFace || '#1a1c2c';
    // bandes de route du quartier (passages piétons au bord des carrefours)
    const HB = DEF.H || [], VB = DEF.V || [];
    const inBand = (v, B) => B.some(([a, b]) => v >= a && v <= b);
    const crossV = (tx, ty) => inBand(ty, HB) && VB.some(([a, b]) => tx === a - 2 || tx === b + 2);   // bandes verticales
    const crossH = (tx, ty) => inBand(tx, VB) && HB.some(([a, b]) => ty === a - 2 || ty === b + 2);
    const ao = (x, y, tx, ty) => {
      const tall = t => t === '#' || t === 'B';
      if (tall(T0(tx, ty - 1))) { g.fillStyle = 'rgba(0,0,0,0.35)'; g.fillRect(x, y, 8, 2); g.fillStyle = 'rgba(0,0,0,0.18)'; g.fillRect(x, y + 2, 8, 1); }
      if (tall(T0(tx - 1, ty))) { g.fillStyle = 'rgba(0,0,0,0.25)'; g.fillRect(x, y, 2, 8); }
    };
    const world = canvas(w, h), decals = canvas(w, h);
    const g = world.getContext('2d');
    g.fillStyle = '#07070c';
    g.fillRect(0, 0, w, h);
    const T0 = (x, y) => M.tile(x, y);
    const wallAt = (x, y) => T0(x, y) === '#';
    const inside = (x, y) => x >= 0 && y >= 0 && x < M.MW && y < M.MH;
    const floorTile = (x, y, tx, ty) => {
      g.fillStyle = P.floor; g.fillRect(x, y, 8, 8);
      g.fillStyle = P.seam; g.fillRect(x, y, 8, 1); g.fillRect(x, y, 1, 8);
      for (let i = 0; i < 3; i++) { g.fillStyle = P.speck[hash(tx, ty, i) < 0.5 ? 0 : 1]; g.fillRect(x + ((hash(tx, ty, i + 3) * 7) | 0) + 1, y + ((hash(tx, ty, i + 6) * 7) | 0) + 1, 1, 1); }
      const r = hash(tx, ty, 20);
      if (r < 0.05) {
        // fissure : quelques pixels en zigzag
        g.fillStyle = shade(P.floor, 0.6);
        let cx = x + 1 + ((hash(tx, ty, 21) * 4) | 0), cy = y + 1;
        for (let i = 0; i < 6; i++) { g.fillRect(cx, cy, 1, 1); cy++; cx += hash(tx, ty, 22 + i) < 0.5 ? 1 : 0; }
      } else if (r < 0.09) {
        // tache
        g.fillStyle = shade(P.floor, 0.8);
        g.fillRect(x + 2, y + 3, 4, 2); g.fillRect(x + 3, y + 2, 2, 4);
      }
      // ombre portée par les murs au nord et à l'ouest (occlusion ambiante)
      const tall = t => t === '#' || t === 'B';
      if (tall(T0(tx, ty - 1))) { g.fillStyle = 'rgba(0,0,0,0.35)'; g.fillRect(x, y, 8, 2); g.fillStyle = 'rgba(0,0,0,0.18)'; g.fillRect(x, y + 2, 8, 1); }
      if (tall(T0(tx - 1, ty))) { g.fillStyle = 'rgba(0,0,0,0.25)'; g.fillRect(x, y, 2, 8); }
    };
    for (let ty = 0; ty < M.MH; ty++) {
      for (let tx = 0; tx < M.MW; tx++) {
        const t = T0(tx, ty), x = tx * 8, y = ty * 8;
        if (t === '.' || t === 'c') floorTile(x, y, tx, ty);
        else if (t === 'k') {
          // pavés : briques décalées, pétales roses à Japantown
          g.fillStyle = '#2a2230'; g.fillRect(x, y, 8, 8);
          g.fillStyle = '#211a27';
          g.fillRect(x, y + 3, 8, 1); g.fillRect(x, y + 7, 8, 1);
          g.fillRect(x + (ty % 2 ? 1 : 5), y, 1, 3); g.fillRect(x + (ty % 2 ? 5 : 1), y + 4, 1, 3);
          if (hash(tx, ty, 4) < 0.3) { g.fillStyle = '#332a3a'; g.fillRect(x + 2, y + 1, 2, 1); }
          if (DEF.roof === 'jp' && hash(tx, ty, 5) < 0.25) { g.fillStyle = '#d66aa8'; g.fillRect(x + ((hash(tx, ty, 6) * 7) | 0), y + ((hash(tx, ty, 7) * 7) | 0), 1, 1); }
          ao(x, y, tx, ty);
        } else if (t === 'q') {
          // dalles de la place : grands carreaux clairs, liserés cyan
          g.fillStyle = '#353846'; g.fillRect(x, y, 8, 8);
          g.fillStyle = '#3d4152'; g.fillRect(x + 1, y + 1, 6, 6);
          g.fillStyle = '#2a2c38'; if (tx % 2 === 0) g.fillRect(x, y, 1, 8); if (ty % 2 === 0) g.fillRect(x, y, 8, 1);
          if (tx % 8 === 0 || ty % 8 === 0) { g.fillStyle = '#1f5a66'; g.fillRect(x + (tx % 8 === 0 ? 3 : 0), y + (ty % 8 === 0 ? 3 : 0), tx % 8 === 0 ? 1 : 8, ty % 8 === 0 ? 1 : 8); }
          ao(x, y, tx, ty);
        } else if (t === 'g') {
          // herbe : brins clairs et sombres
          g.fillStyle = '#18301e'; g.fillRect(x, y, 8, 8);
          for (let i = 0; i < 6; i++) { g.fillStyle = hash(tx, ty, i) < 0.5 ? '#224a2a' : '#122418'; g.fillRect(x + ((hash(tx, ty, i + 7) * 8) | 0), y + ((hash(tx, ty, i + 14) * 7) | 0), 1, 2); }
          if (hash(tx, ty, 30) < 0.05) { g.fillStyle = '#f2d43a'; g.fillRect(x + 3, y + 3, 1, 1); }
          ao(x, y, tx, ty);
        } else if (t === 'z') {
          // sable, avec des débris çà et là
          g.fillStyle = '#5a4a34'; g.fillRect(x, y, 8, 8);
          for (let i = 0; i < 5; i++) { g.fillStyle = hash(tx, ty, i) < 0.5 ? '#6a583e' : '#4a3c2a'; g.fillRect(x + ((hash(tx, ty, i + 7) * 8) | 0), y + ((hash(tx, ty, i + 14) * 8) | 0), 1, 1); }
          if (hash(tx, ty, 31) < 0.04) { g.fillStyle = '#8a8f9a'; g.fillRect(x + 2, y + 4, 2, 1); }
          if (T0(tx, ty + 1) === 'w') { g.fillStyle = '#7a6a4e'; g.fillRect(x, y + 6, 8, 2); }   // sable mouillé
          ao(x, y, tx, ty);
        } else if (t === 'w') {
          // eau sombre ; les reflets bougent dans R.draw
          const deep = T0(tx, ty - 2) === 'w' && T0(tx, ty - 3) === 'w';
          g.fillStyle = deep ? '#061822' : '#0a2a3a'; g.fillRect(x, y, 8, 8);
          if (hash(tx, ty, 2) < 0.4) { g.fillStyle = deep ? '#0a2230' : '#103848'; g.fillRect(x + ((hash(tx, ty, 3) * 5) | 0), y + ((hash(tx, ty, 4) * 7) | 0), 3, 1); }
          if (T0(tx, ty - 1) !== 'w') { g.fillStyle = '#7fb8c8'; g.fillRect(x, y, 8, 1); g.fillStyle = '#2a5a6a'; g.fillRect(x, y + 1, 8, 1); }   // écume
        }
        else if (t === ',') {
          g.fillStyle = P.carpet; g.fillRect(x, y, 8, 8);
          g.fillStyle = P.carpetDot;
          for (let yy = 0; yy < 8; yy += 2) for (let xx = (yy / 2) % 2; xx < 8; xx += 2) g.fillRect(x + xx, y + yy, 1, 1);
        } else if (t === 's') {
          // trottoir : dalles, bordure plus claire côté chaussée
          floorTile(x, y, tx, ty);
          g.fillStyle = DEF.road === 'clean' ? '#4a4e62' : '#3a3a4e';
          const road = (a, b) => ['r', '='].includes(T0(a, b));
          if (road(tx, ty + 1)) g.fillRect(x, y + 7, 8, 1);
          if (road(tx, ty - 1)) g.fillRect(x, y, 8, 1);
          if (road(tx + 1, ty)) g.fillRect(x + 7, y, 1, 8);
          if (road(tx - 1, ty)) g.fillRect(x, y, 1, 8);
        } else if (t === 'r' || t === '=') {
          // chaussée : asphalte bruité, marquage jaune au centre
          const RS = DEF.road;
          g.fillStyle = RS === 'clean' ? '#15161c' : RS === 'ruin' ? '#1c1a1a' : '#17171e'; g.fillRect(x, y, 8, 8);
          for (let i = 0; i < 4; i++) { g.fillStyle = hash(tx, ty, i) < 0.5 ? '#1c1c24' : '#131319'; g.fillRect(x + ((hash(tx, ty, i + 9) * 8) | 0), y + ((hash(tx, ty, i + 13) * 8) | 0), 1, 1); }
          if (RS === 'ruin') {
            const r = hash(tx, ty, 40);
            if (r < 0.06) { g.fillStyle = '#0c0b0b'; g.fillRect(x + 2, y + 2, 4, 3); g.fillStyle = '#060505'; g.fillRect(x + 3, y + 3, 2, 1); }   // nid-de-poule
            else if (r < 0.16) { g.fillStyle = '#100f0f'; let cx = x + ((hash(tx, ty, 41) * 6) | 0), cy = y; for (let i = 0; i < 8; i++) { g.fillRect(cx, cy++, 1, 1); cx += hash(tx, ty, 42 + i) < 0.5 ? 1 : -1; } }
            else if (r < 0.24) { g.fillStyle = '#4a3c2a'; g.fillRect(x + ((hash(tx, ty, 43) * 5) | 0), y + ((hash(tx, ty, 44) * 6) | 0), 3, 2); }   // sable
          }
          if (t === '=' && !(RS === 'ruin' && hash(tx, ty, 45) < 0.4)) {
            g.fillStyle = RS === 'clean' ? '#c8ccd8' : '#b8932a';
            const horiz = T0(tx, ty - 1) === 'r' && T0(tx, ty + 1) === 'r';
            if (horiz) g.fillRect(x, y + 3, 8, 1); else g.fillRect(x + 3, y, 1, 8);
          }
          // passages piétons au bord des carrefours
          if (crossV(tx, ty) || crossH(tx, ty)) {
            g.fillStyle = RS === 'ruin' ? '#4a4a4e' : '#a8acb8';
            if (crossV(tx, ty)) { g.fillRect(x + 1, y + 1, 6, 2); g.fillRect(x + 1, y + 5, 6, 2); }
            else { g.fillRect(x + 1, y + 1, 2, 6); g.fillRect(x + 5, y + 1, 2, 6); }
          }
        }
        if (t === 'p') {
          // parking : asphalte, places tracées en blanc
          g.fillStyle = '#1b1b24'; g.fillRect(x, y, 8, 8);
          if (hash(tx, ty, 2) < 0.3) { g.fillStyle = '#20202a'; g.fillRect(x + 2, y + 3, 2, 1); }
          if (tx % 4 === 0) { g.fillStyle = '#9a9aa8'; g.fillRect(x, y, 1, 8); }
          if (T0(tx, ty - 1) !== 'p') { g.fillStyle = '#c9a227'; g.fillRect(x, y, 8, 1); }
        }
        if (t === 'B') {
          // toit d'immeuble vu de dessus : bord sombre, néon sur la façade, aérations et climatiseurs
          const open = (a, b) => inside(a, b) && T0(a, b) !== 'B' && T0(a, b) !== 'D';
          if (DEF.roof && DEF.roof !== 'watson') { roofTile(g, DEF.roof, x, y, tx, ty, open); continue; }
          g.fillStyle = '#121220'; g.fillRect(x, y, 8, 8);
          const r = hash(tx, ty);
          if (r < 0.06) { g.fillStyle = '#1e1e30'; g.fillRect(x + 2, y + 2, 4, 4); g.fillStyle = '#0a0a14'; g.fillRect(x + 3, y + 3, 2, 2); }
          else if (r < 0.1) { g.fillStyle = '#26263a'; g.fillRect(x + 1, y + 2, 6, 3); g.fillStyle = '#3a3a52'; g.fillRect(x + 2, y + 3, 1, 1); }
          else if (r < 0.14) { g.fillStyle = '#18182a'; g.fillRect(x + 3, y + 1, 1, 6); }
          const neon = NEON[(hash((tx / 6) | 0, (ty / 6) | 0, 7) * NEON.length) | 0];
          if (open(tx, ty + 1)) { g.fillStyle = '#2a2a40'; g.fillRect(x, y + 6, 8, 2); if (hash(tx, ty, 5) < 0.5) { g.fillStyle = neon; g.fillRect(x + 1, y + 7, 6, 1); } }
          if (open(tx, ty - 1)) { g.fillStyle = '#2a2a40'; g.fillRect(x, y, 8, 2); }
          if (open(tx + 1, ty)) { g.fillStyle = '#2a2a40'; g.fillRect(x + 6, y, 2, 8); if (hash(tx, ty, 6) < 0.4) { g.fillStyle = neon; g.fillRect(x + 7, y + 1, 1, 6); } }
          if (open(tx - 1, ty)) { g.fillStyle = '#2a2a40'; g.fillRect(x, y, 2, 8); }
        }
        if (t === 'D') {
          // porte : cadre sombre, battant à la couleur de l'enseigne, seuil lumineux
          const d = M.def.doors.find(o => o.x === tx && o.y === ty), col = d ? d.color : '#c7d5e0';
          if (d && d.metro) {
            // bouche de métro : bandes jaunes et noires, marches qui descendent
            g.fillStyle = '#05050a'; g.fillRect(x - 4, y, 16, 8);
            for (let i = 0; i < 16; i += 2) { g.fillStyle = (i / 2) % 2 ? '#1a1a1a' : col; g.fillRect(x - 4 + i, y, 2, 1); }
            for (let i = 0; i < 3; i++) { g.fillStyle = shade('#3a3a4e', 1 - i * 0.25); g.fillRect(x - 3, y + 2 + i * 2, 14, 1); }
            g.fillStyle = col; g.fillRect(x - 4, y + 1, 1, 7); g.fillRect(x + 11, y + 1, 1, 7);
            continue;
          }
          g.fillStyle = M.def.outdoor ? '#2a2a40' : '#262940'; g.fillRect(x, y, 8, 8);
          g.fillStyle = '#05050a'; g.fillRect(x + 1, y + 1, 6, 6);
          g.fillStyle = shade(col, 0.45); g.fillRect(x + 2, y + 2, 4, 4);
          g.fillStyle = col; g.fillRect(x + 1, y + (inside(tx, ty + 1) && !M.solid(tx, ty + 1) ? 7 : 0), 6, 1);
        }
        if (t === '#') {
          let edge = false;
          for (let oy = -1; oy <= 1; oy++) for (let ox = -1; ox <= 1; ox++) if (inside(tx + ox, ty + oy) && !wallAt(tx + ox, ty + oy)) edge = true;
          if (!edge) continue;   // intérieur des murs : vide noir
          // dessus du mur, avec un peu de grain
          g.fillStyle = WALL; g.fillRect(x, y, 8, 8);
          if (hash(tx, ty, 30) < 0.5) { g.fillStyle = shade(WALL, 1.15); g.fillRect(x + ((hash(tx, ty, 31) * 6) | 0) + 1, y + ((hash(tx, ty, 32) * 6) | 0) + 1, 2, 1); }
          // liseré clair du côté de la pièce
          g.fillStyle = WALL_HI;
          if (!wallAt(tx, ty - 1) && ty > 0) g.fillRect(x, y, 8, 1);
          if (!wallAt(tx + 1, ty) && tx + 1 < M.MW) g.fillRect(x + 7, y, 1, 8);
          if (!wallAt(tx - 1, ty) && tx > 0) g.fillRect(x, y, 1, 8);
          // face avant (vers le sud) : donne de l'épaisseur au mur, comme vu légèrement de biais
          if (inside(tx, ty + 1) && !wallAt(tx, ty + 1)) {
            g.fillStyle = WALL_FACE; g.fillRect(x, y + 5, 8, 3);
            g.fillStyle = shade(WALL_HI, 1.12); g.fillRect(x, y + 4, 8, 1);
            g.fillStyle = '#121320'; g.fillRect(x, y + 7, 8, 1);
            if (hash(tx, ty, 33) < 0.25) { g.fillStyle = '#23263a'; g.fillRect(x + 2, y + 5, 1, 2); }
          }
        }
      }
    }
    // Le mobilier en second passage, pour que son ombre tombe sur le sol déjà dessiné.
    for (let ty = 0; ty < M.MH; ty++) for (let tx = 0; tx < M.MW; tx++) if (T0(tx, ty) === 'c') drawProp(g, tx * 8, ty * 8, tx, ty);
    // décor des quartiers : du nord au sud, pour que les feuillages du bas recouvrent ceux du haut
    for (const p of (DEF.props || []).slice().sort((a, b) => a.y - b.y)) C.decor.drawStatic(g, p);
    const amb = C.amb.scan(g);   // enseignes, flaques, bouches d'égout (ambiance.js)
    // Éclairage : un voile sombre percé par les lampes et les néons, plus une couche de lueur colorée ajoutée.
    const lightMask = canvas(w, h), glow = canvas(w, h);
    const lmx = lightMask.getContext('2d'), gx = glow.getContext('2d');
    lmx.fillStyle = 'rgba(4,4,14,' + (DEF.dark || (DEF.outdoor ? 0.72 : 0.8)) + ')';
    lmx.fillRect(0, 0, w, h);
    lmx.globalCompositeOperation = 'destination-out';
    gx.globalCompositeOperation = 'lighter';
    for (const l of M.lights) {
      const x = l.x * 8 + 4, y = l.y * 8 + 4;
      let gr = lmx.createRadialGradient(x, y, 0, x, y, l.r);
      gr.addColorStop(0, 'rgba(0,0,0,0.95)'); gr.addColorStop(0.5, 'rgba(0,0,0,0.6)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
      lmx.fillStyle = gr; lmx.fillRect(x - l.r, y - l.r, l.r * 2, l.r * 2);
      gr = gx.createRadialGradient(x, y, 0, x, y, l.r * 0.8);
      gr.addColorStop(0, hexA(l.c, 0.28)); gr.addColorStop(1, hexA(l.c, 0));
      gx.fillStyle = gr; gx.fillRect(x - l.r, y - l.r, l.r * 2, l.r * 2);
    }
    return { world, decals, lightMask, glow, amb, blood: new Map() };
  }

  // Calques à la taille de l'écran (éclairage, vignette, décor du titre) : refaits si la résolution change.
  function screenBuffers() {
    if (lm && lm.width === C.W && lm.height === C.H) return;
    lm = canvas(C.W, C.H);
    ac = canvas(C.W, C.H);   // calque des personnages
    vignette = canvas(C.W, C.H);
    skyline = null;
    const v = vignette.getContext('2d');
    const gr = v.createRadialGradient(C.W / 2, C.H / 2, C.H / 3, C.W / 2, C.H / 2, C.W * 0.62);
    gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,0.55)');
    v.fillStyle = gr; v.fillRect(0, 0, C.W, C.H);
  }
  function hexA(hex, a) {
    const n = parseInt(hex.slice(1), 16);
    return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${a})`;
  }
  // Taches de sang permanentes sur le calque des décalques (et comptées par tuile pour les traces de pas).
  const countBlood = (x, y, n) => { if (!bloodMap) return; const k = Math.floor(y / 8) * M.MW + Math.floor(x / 8); bloodMap.set(k, (bloodMap.get(k) || 0) + n); };
  // count = false : la tache ne compte pas comme du sang (douilles, traces de pas)
  R.decal = (x, y, color, size = 1, count = true) => {
    if (!dctx) return;
    dctx.fillStyle = color; dctx.fillRect(Math.round(x), Math.round(y), size, size);
    if (count) countBlood(x, y, size);
  };
  R.bloodAt = (x, y) => (bloodMap ? bloodMap.get(Math.floor(y / 8) * M.MW + Math.floor(x / 8)) || 0 : 0);
  // Grosse tache irrégulière (giclée au sol).
  R.splat = (x, y, r) => {
    if (!dctx) return;
    for (let i = 0; i < r * 6; i++) {
      const a = Math.random() * 6.28, d = Math.random() * r * (Math.random() < 0.15 ? 1.8 : 1);
      dctx.fillStyle = Math.random() < 0.5 ? '#6e0a18' : '#8c0f22';
      const s = d < r * 0.5 ? 2 : 1;
      dctx.fillRect(Math.round(x + Math.cos(a) * d), Math.round(y + Math.sin(a) * d * 0.8), s, s);
    }
    countBlood(x, y, r * 4);
  };
  // Goutte écrasée contre un mur : petite tache sur la face du mur, qui coule vers le bas.
  R.wallSplat = (x, y, vx, vy) => {
    if (!dctx) return;
    const s = Math.hypot(vx, vy) || 1, wx = x + (vx / s) * 2, wy = y + (vy / s) * 2;
    dctx.fillStyle = '#8c0f22'; dctx.fillRect(Math.round(wx) - 1, Math.round(wy) - 1, 2, 2);
    if (Math.random() < 0.5) { dctx.fillStyle = '#6e0a18'; dctx.fillRect(Math.round(wx), Math.round(wy) + 1, 1, 2 + ((Math.random() * 4) | 0)); }
  };
  // Morceau resté au sol : un bout de chair (ou d'os, de chrome) cerné de sang.
  R.gib = (x, y, color, w, h) => {
    if (!dctx) return;
    const X = Math.round(x), Y = Math.round(y);
    dctx.fillStyle = '#6e0a18'; dctx.fillRect(X - 1, Y - 1, w + 2, h + 2);
    dctx.fillStyle = color; dctx.fillRect(X, Y, w, h);
    dctx.fillStyle = '#3a0610'; dctx.fillRect(X, Y + h - 1, w, 1);
    countBlood(x, y, 3);
  };

  // ---------- éléments du monde ----------
  function enemyColors(e) {
    const fac = e.faction && D.factions[e.faction], lk = e.outfit || {};
    return {
      jacket: fac ? (e.type === 'brute' ? shade(fac.jacket, 1.3) : fac.jacket) : e.d.jacket,
      hair: fac && e.type !== 'brute' ? fac.hair : lk.hair || e.d.hair,
      skin: lk.skin || '#c9926c', chrome: e.d.chrome || (e.type === 'brute' || e.psycho ? '#b8c4d6' : null), eye: e.d.eye || null,
      pants: lk.pants, style: lk.style, cap: lk.cap,
    };
  }
  // Pose d'un corps qui vient de tomber : il plie puis bascule (0,25 s), avant de rester à terre.
  const fallPose = t => (t < 0.11 ? ['fall', 0] : t < 0.24 ? ['fall', 1] : ['down', 1]);

  function drawBody(g, e, t) {
    const col = enemyColors(e), dark = e.state === 'dead' ? 0.5 : e.state === 'spared' ? 0.75 : 0.85;
    const o = Object.assign(col, { jacket: shade(col.jacket, dark), scale: e.r > 4 ? 1.25 : 1 });
    if (e.state === 'spared') { drawChar(g, e.x, e.y, e.aim, Object.assign(o, { pose: 'sit' })); return; }
    // flaque qui s'étale sous le corps, puis le corps allongé dans le sens du coup reçu
    bloodPool(g, e.x - Math.cos(e.downAng) * 1, e.y - Math.sin(e.downAng) * 1, Math.min(e.gibbed ? 12 : e.state === 'dead' ? 10 : 7, Math.max(0, (e.downT || 0) - 0.2) * 2 + (e.gibbed ? 6 : 2)));
    if (e.gibbed) return;   // il n'en reste que des morceaux
    const [pose, frame] = fallPose(e.downT || 0);
    drawChar(g, e.x, e.y, e.downAng, Object.assign(o, { pose, frame, shadow: false }));
    if (e.state === 'down' && Math.sin(t * 8) > 0) {
      // repère clignotant : décision à prendre
      g.fillStyle = C.game.near === e ? '#ffffff' : '#ff8a5a';
      g.fillRect(Math.round(e.x) - 1, Math.round(e.y) - 12, 3, 1); g.fillRect(Math.round(e.x), Math.round(e.y) - 11, 1, 1);
    }
  }

  // Corps du leader précédent, à fouiller.
  function drawCorpse(g, c, t) {
    drawChar(g, c.x, c.y, -0.4, { jacket: shade(PAL.player.jacket, 0.5), hair: PAL.player.hair, skin: PAL.player.skin, pose: 'down', shadow: false });
    if (!c.taken && Math.sin(t * 6) > 0) { g.fillStyle = '#f2d43a'; g.fillRect(Math.round(c.x), Math.round(c.y) - 12, 3, 1); g.fillRect(Math.round(c.x) + 1, Math.round(c.y) - 11, 1, 1); }
  }

  // Compagnon (veste cyan) : debout avec son arme, ou allongé quand il est à terre.
  function drawComp(g, c, t) {
    const CD = D.companion, o = { jacket: CD.jacket, hair: CD.hair, skin: '#d9a07a' };
    if (c.state === 'down') {
      drawChar(g, c.x, c.y, c.downAng || 0, Object.assign(o, { jacket: shade(CD.jacket, 0.6), pose: 'down', shadow: false }));
      if (Math.sin(t * 8) > 0) { g.fillStyle = '#3ec8ff'; g.fillRect(Math.round(c.x), Math.round(c.y) - 12, 3, 1); g.fillRect(Math.round(c.x) + 1, Math.round(c.y) - 11, 1, 1); }
      return;
    }
    drawChar(g, c.x, c.y, c.aim, Object.assign(o, { pose: c.muzzle > 0 ? 'fire' : 'gun', frame: frameOf(c), flash: c.hurtT > 0 }));
  }

  function drawEnemy(g, e) {
    const o = enemyColors(e);
    if (e.wpn) { o.gunLen = D.weapons[e.wpn].len; o.gunColor = D.weapons[e.wpn].color; }
    if (e.d.drop === 'katana') { o.blade = '#e8f6ff'; o.bladeLen = 15; }
    o.scale = e.r > 4 ? 1.25 : 1;
    o.frame = frameOf(e);
    o.flash = e.hurtT > 0 || (e.windT > 0 && Math.sin(e.windT * 60) > 0);
    if (e.state === 'friend') o.pose = 'bare';
    else if (e.d.weapon) o.pose = e.muzzle > 0 ? 'fire' : 'gun';
    else if (e.psycho || e.d.drop === 'katana') o.pose = e.windT > 0 ? 'slash' : e.psycho ? 'fists' : 'bare';
    else o.pose = e.state === 'alert' ? 'fists' : 'bare';
    if (e.psycho) {
      o.blade = '#ff3ec8';
      // halo magenta qui grésille autour du cyberpsycho
      if (Math.sin(C.game.time * 18) > 0) drawChar(g, e.x, e.y, e.aim, Object.assign({}, o, { solid: '#ff3ec8', scale: 1.3, alpha: 0.5, flash: false }));
    }
    drawChar(g, e.x, e.y, e.aim, o);
    if (e.state === 'alert' && e.react > 0) {
      // point d'exclamation au moment où il te repère
      g.fillStyle = '#ffffff';
      g.fillRect(Math.round(e.x), Math.round(e.y) - 13, 1, 3);
      g.fillRect(Math.round(e.x), Math.round(e.y) - 9, 1, 1);
    }
  }

  function drawPlayer(g, p, G) {
    if (p.invT > 0 && p.dashT <= 0 && Math.sin(G.time * 60) > 0) return;
    const m = G.mods || {}, imp = G.leader ? G.leader.implants : {}, W = D.weapons[p.weapon], B = D.weapons[p.melee];
    const o = { jacket: PAL.player.jacket, hair: PAL.player.hair, skin: PAL.player.skin, eye: m.scan ? '#ff2040' : null, flash: p.hurtT > 0, frame: frameOf(p),
      gunLen: W.len, gunColor: W.color, bladeLen: B.bladeLen };
    // le chrome se voit : bras métalliques, lame magenta des Mantis
    if (imp['BRAS']) o.chrome = m.mantis ? '#c8c8d8' : '#b8c4d6';
    o.blade = m.mantis ? '#ff3ec8' : '#e8f6ff';
    if (p.slashT > 0) { o.pose = 'slash'; drawChar(g, p.x, p.y, p.slashA, o); }
    else { o.pose = M.def && (M.id === 'planque' || (M.def.outdoor && !(p.drawnT > 0))) ? 'bare' : p.fireCd > W.rate - 0.07 ? 'fire' : 'gun'; drawChar(g, p.x, p.y, p.aim, o); }
    if (p.slashT > 0) {
      // arc de la lame (plus grand et magenta avec les lames Mantis)
      const extra = (m.bladeArc || 0) + (B.arc - 1.2), a0 = p.slashA - 0.7 - extra / 2, span = 1.4 + extra, k = 1 - p.slashT / (B.parry ? 0.22 : 0.15);
      const r = 11 + Math.round(((m.bladeRange || 0) + (B.range - 15)) * 0.6);
      for (let i = 0; i <= 12; i++) {
        const a = a0 + (span * i) / 12;
        if (i / 12 > k + 0.2) break;
        g.fillStyle = i / 12 > k - 0.2 ? '#ffffff' : m.mantis ? '#ff3ec8' : '#7ff6ff';
        g.fillRect(Math.round(p.x + Math.cos(a) * r), Math.round(p.y + Math.sin(a) * r), 1, 1);
        g.fillRect(Math.round(p.x + Math.cos(a) * (r + 1)), Math.round(p.y + Math.sin(a) * (r + 1)), 1, 1);
      }
    }
    if (p.injT > 0) {
      g.fillStyle = '#5dff9a';
      const w = Math.round(9 * (1 - p.injT / D.player.injectTime));
      g.fillRect(Math.round(p.x) - 4, Math.round(p.y) + 8, w, 1);
    }
  }

  // ---------- HUD ----------
  function bar(g, x, y, w, h, f, col, bg) {
    g.fillStyle = '#05050a'; g.fillRect(x - 1, y - 1, w + 2, h + 2);
    g.fillStyle = bg; g.fillRect(x, y, w, h);
    g.fillStyle = col; g.fillRect(x, y, Math.round(w * C.clamp(f, 0, 1)), h);
  }
  const T = (g, s, x, y, c, o = {}) => C.text(g, s, x, y, c, Object.assign({ shadow: '#05050a' }, o));
  const K = c => '[' + C.keyLabel(c) + ']';

  function drawHUD(g, G) {
    const p = G.player, P = D.player, W = D.weapons[p.weapon], S = G.sandy, t = G.time;
    // gauche : PV, injecteurs, munitions
    T(g, 'PV', 4, 4, '#c7d5e0');
    bar(g, 14, 4, 60, 5, p.hp / p.maxHp, p.hp < 35 && Math.sin(t * 10) > 0 ? '#ff8a9a' : '#ff4d6d', '#3a1018');
    for (let i = 0; i < P.injectors; i++) {
      const x = 4 + i * 6, y = 12, on = i < p.inj;
      g.fillStyle = '#05050a'; g.fillRect(x - 1, y - 1, 5, 9);
      g.fillStyle = on ? '#5dff9a' : '#1d3326'; g.fillRect(x, y + 2, 3, 5);
      g.fillStyle = on ? '#c8ffe0' : '#24402f'; g.fillRect(x + 1, y, 1, 2);
    }
    T(g, K('KeyF'), 24, 13, '#6f7c8a');
    if (G.leader) T(g, G.leader.eddies + ' €$', 74, 24, '#ffd23e', { align: 'right' });
    if (p.reloadT > 0) T(g, 'RECHARGE...', 4, 24, '#ffd23e');
    else T(g, p.mag + '/' + W.mag, 4, 24, p.mag === 0 ? '#ff4d6d' : '#c7d5e0');
    T(g, W.name + (p.melee !== 'blade' ? ' · ' + D.weapons[p.melee].name : ''), 4, 31, '#8f98a0');   // armes en main

    if (G.drive) {
      // compteur de vitesse (1 pixel/s ~ 1 km/h, à peu près)
      const car = G.drive, kmh = Math.round(Math.abs(car.speed) * 0.9);
      T(g, C.cars.MODELS[car.model].nom, 4, C.H - 30, '#c7d5e0');
      T(g, kmh + ' KM/H', 4, C.H - 22, '#f2d43a', { scale: 2 });
    }
    // compagnon : nom, PV, loyauté, ordre
    const c = G.comp;
    if (c) {
      T(g, c.nom, 4, 40, '#3ec8ff');
      bar(g, 4, 47, 40, 2, c.hp / c.maxHp, c.state === 'down' ? '#ff8a5a' : '#3ec8ff', '#0d2a30');
      T(g, c.state === 'down' ? 'À TERRE' : 'LOYAUTÉ ' + Math.round(c.loyalty), 4, 52, c.state === 'down' ? '#ff8a5a' : c.loyalty < 25 ? '#ff8a5a' : '#8f98a0');
      if (c.state === 'up') T(g, K('KeyG') + ' ' + (c.order === 'suivre' ? 'SUIVRE' : 'TENIR'), 4, 60, '#6f7c8a');
    }

    // droite : Sandevistan et humanité
    const rx = C.W - 4;
    T(g, 'SANDEVISTAN', rx, 4, S.on ? '#7ff6ff' : '#c7d5e0', { align: 'right' });
    const ready = S.charge >= G.sandyDur() * D.sandy.minCharge;
    bar(g, rx - 60, 11, 60, 3, S.charge / G.sandyDur(), S.on ? '#ffffff' : ready ? '#3ef0ff' : '#1f6f7a', '#0d2a30');
    const hum = Math.round(G.humanity);
    const low = G.humanity < D.humanity.hallucinate;
    T(g, 'HUMANITÉ ' + hum, rx, 18, low ? '#ff3ec8' : '#c7d5e0', { align: 'right' });
    bar(g, rx - 60, 25, 60, 3, G.humanity / 100, low ? '#ff3ec8' : '#c45cff', '#2a1030');
    if (low && Math.sin(t * 6) > 0) T(g, 'INSTABLE', rx, 31, '#ff3ec8', { align: 'right' });

    // haut : cibles restantes
    const n = G.alive();
    const kc = G.contract;
    if (kc) {
      const f = D.factions[kc.faction];
      let st = kc.failed ? 'RATÉ' : kc.done ? 'REMPLI' : kc.type === 'data' ? 'TERMINAL À PIRATER' : C.contracts.is(kc) ? C.contracts.status(kc) : 'EN COURS';
      if (kc.grand && !kc.done && !kc.failed && G.alertedOnce) st = 'IL FILE DANS ' + Math.ceil(kc.timer) + ' S';
      T(g, (kc.grand ? 'GRAND CONTRAT ' : '') + f.nom + ' · ' + (kc.grand ? 'LE CADRE' : D.contracts[kc.type].nom) + ' · ' + st, C.W / 2, 12, kc.failed ? '#ff2040' : kc.done ? '#5dff9a' : f.color, { align: 'center' });
    } else if (G.leader && M.id === 'planque') {
      T(g, 'PASSE VOIR ' + G.fixer.nom + ' POUR UN CONTRAT', C.W / 2, 12, '#8f98a0', { align: 'center' });
    }
    const who = G.leader ? G.leader.nom + ' · GIG ' + G.leader.gigs + ' · ' : '';
    const site = M.def.site;
    T(g, who + (!site ? M.def.nom : n ? 'CIBLES ' + n : 'BÂTIMENT NETTOYÉ'), C.W / 2, 4, !site || n ? '#c7d5e0' : '#5dff9a', { align: 'center' });
    if (G.revealT > 0) {
      // un allié t'a montré les positions : repères sur les ennemis, flèches au bord pour ceux hors champ
      T(g, 'POSITIONS RÉVÉLÉES ' + Math.ceil(G.revealT), C.W / 2, 20, '#5dff9a', { align: 'center' });
      const sx = G.cam.x, sy = G.cam.y;
      g.fillStyle = Math.sin(t * 10) > 0 ? '#ff4d6d' : '#ff9aaa';
      for (const e of G.enemies) {
        if (!G.ALIVE(e)) continue;
        const x = e.x - sx, y = e.y - sy;
        if (x > 4 && x < C.W - 4 && y > 4 && y < C.H - 4) {
          g.fillRect(Math.round(x) - 6, Math.round(y) - 6, 2, 1); g.fillRect(Math.round(x) - 6, Math.round(y) - 6, 1, 2);
          g.fillRect(Math.round(x) + 5, Math.round(y) + 6, 2, 1); g.fillRect(Math.round(x) + 6, Math.round(y) + 5, 1, 2);
        } else {
          const ex = Math.round(C.clamp(x, 3, C.W - 4)), ey = Math.round(C.clamp(y, 20, C.H - 4));
          g.fillRect(ex - 1, ey - 1, 3, 3);
        }
      }
    }

    // flèche vers l'objectif : porte du contrat, planque, métro, ou objectif sur place (colis, otage, voiture...)
    {
      const gl = G.goal();
      if (gl) {
        const x = gl.x - G.cam.x, y = gl.y - G.cam.y, col = gl.color, bob = Math.round(Math.sin(t * 6) * 1.5);
        if (x > 8 && x < C.W - 8 && y > 22 && y < C.H - 8) {
          g.fillStyle = col;
          g.fillRect(Math.round(x) - 2, Math.round(y) - 16 + bob, 5, 1); g.fillRect(Math.round(x) - 1, Math.round(y) - 15 + bob, 3, 1); g.fillRect(Math.round(x), Math.round(y) - 14 + bob, 1, 1);
        } else {
          // hors champ : flèche au bord de l'écran, dans la direction de la porte, avec la distance
          const a = Math.atan2(y - C.H / 2, x - C.W / 2);
          const ex = C.clamp(C.W / 2 + Math.cos(a) * C.W, 10, C.W - 10), ey = C.clamp(C.H / 2 + Math.sin(a) * C.H, 64, C.H - 24);   // sous le HUD de gauche
          g.fillStyle = col;
          for (let i = 0; i < 4; i++) g.fillRect(Math.round(ex + Math.cos(a) * (3 - i) - 0.5), Math.round(ey + Math.sin(a) * (3 - i) - 0.5), 2, 2);
          const m = Math.round(C.dist(G.player.x, G.player.y, gl.x, gl.y) / 8);
          T(g, gl.label + ' ' + m + ' M', C.clamp(ex, 40, C.W - 40), ey + (ey > C.H / 2 ? -10 : 5), col, { align: 'center' });
        }
      }
    }

    // bas : décision sur un ennemi à terre, ou aide des touches au début (sur un bandeau sombre pour rester lisible)
    if (G.near || G.prompt || G.gigOver() || G.time < 12) {
      g.fillStyle = 'rgba(5,5,10,0.6)';
      g.fillRect(0, G.near || G.prompt || G.gigOver() ? C.H - 15 : C.H - 21, C.W, 21);
    }
    if (G.near) {
      T(g, K('KeyE') + ' ACHEVER     ' + K('KeyC') + ' ÉPARGNER', C.W / 2, C.H - 12, '#ffffff', { align: 'center' });
    } else if (G.prompt) {
      T(g, K('KeyE') + ' ' + G.prompt, C.W / 2, C.H - 12, '#f2d43a', { align: 'center' });
    } else if (G.gigOver()) {
      T(g, 'CONTRAT ' + (G.contract.done ? 'TERMINÉ' : 'RATÉ') + ' · RETOURNE À LA PLANQUE POUR LE GIG SUIVANT', C.W / 2, C.H - 12, G.contract.done ? '#5dff9a' : '#ff8a5a', { align: 'center' });
    } else if (G.time < 12 && M.id === 'planque') {
      T(g, C.keyLabel('KeyW') + ' AVANCER VERS LA SOURIS   CLIC TIR   CLIC DROIT LAME', C.W / 2, C.H - 18, '#8f98a0', { align: 'center' });
      T(g, 'ESPACE DASH   MAJ SANDEVISTAN   TAB HACK   ' + C.keyLabel('KeyF') + ' SOIN   ' + C.keyLabel('KeyR') + ' RECHARGER', C.W / 2, C.H - 10, '#8f98a0', { align: 'center' });
    }

    C.net.drawHUD(g);   // RAM et panneau des quickhacks
    C.skills.drawHUD(g); // niveau et barre d'expérience
    C.music.drawHUD(g);  // radio et animateur
    C.ncpd.drawHUD(g);  // étoiles de recherche
    C.gangs.drawHUD(g); // territoire, brouillage
    C.home.drawHUD(g);  // bandeau N54 devant la télé de la planque
    if (C.cheat.active()) T(g, 'ROOT', 80, 13, Math.sin(G.time * 3) > 0 ? '#ff3ec8' : '#7a1a5a');   // une triche est active
    // viseur
    const mx = Math.round(C.input.mx), my = Math.round(C.input.my);
    const cc = p.reloadT > 0 || p.mag === 0 ? '#ff4d6d' : S.on ? '#7ff6ff' : '#ffffff';
    g.fillStyle = '#05050a';
    g.fillRect(mx - 4, my - 1, 3, 3); g.fillRect(mx + 2, my - 1, 3, 3); g.fillRect(mx - 1, my - 4, 3, 3); g.fillRect(mx - 1, my + 2, 3, 3);
    g.fillStyle = cc;
    g.fillRect(mx - 3, my, 2, 1); g.fillRect(mx + 2, my, 2, 1); g.fillRect(mx, my - 3, 1, 2); g.fillRect(mx, my + 2, 1, 2);
    g.fillRect(mx, my, 1, 1);
  }

  // ---------- écrans ----------
  function buildSkyline() {
    const c = canvas(C.W, C.H), g = c.getContext('2d');
    const sky = g.createLinearGradient(0, 0, 0, C.H - 30);
    const base = C.H - 30;   // ligne de la rue
    sky.addColorStop(0, '#05030c'); sky.addColorStop(0.7, '#1c0826'); sky.addColorStop(1, '#3a0d38');
    g.fillStyle = sky; g.fillRect(0, 0, C.W, C.H);
    C.reseed(77);
    const layer = (base, hmin, hmax, col, winP) => {
      let x = -10;
      while (x < C.W + 10) {
        const w = C.rr(14, 38) | 0, h = C.rr(hmin, hmax) | 0, y = base - h;
        g.fillStyle = col; g.fillRect(x, y, w, h);
        if (C.rand() < 0.3) g.fillRect(x + (w / 2 | 0), y - 8, 1, 8);   // antenne
        for (let wy = y + 3; wy < base - 2; wy += 3) for (let wx = x + 2; wx < x + w - 2; wx += 2) {
          if (C.rand() < winP) { g.fillStyle = ['#ffd23e', '#3ef0ff', '#ff3ec8', '#7a5cff'][(C.rand() * 4) | 0]; g.globalAlpha = C.rr(0.3, 0.9); g.fillRect(wx, wy, 1, 1); g.globalAlpha = 1; }
        }
        x += w + (C.rr(0, 4) | 0);
      }
    };
    const k = C.H / 180;
    layer(base, 50 * k, 110 * k, '#120a1f', 0.05);
    layer(base, 20 * k, 70 * k, '#09060f', 0.08);
    g.fillStyle = '#060409'; g.fillRect(0, base, C.W, 30);
    g.fillStyle = '#ff3ec8'; g.globalAlpha = 0.35; g.fillRect(0, base, C.W, 1); g.globalAlpha = 1;
    return c;
  }

  let quitRect = null;
  R.overQuit = () => {
    if (!IS_STREAZ || !quitRect) return false;
    const { mx, my } = C.input;
    return mx >= quitRect[0] && mx < quitRect[0] + quitRect[2] && my >= quitRect[1] && my < quitRect[1] + quitRect[3];
  };

  function drawTitle(g, now) {
    if (!skyline) skyline = buildSkyline();
    g.drawImage(skyline, 0, 0);
    // pluie
    g.fillStyle = 'rgba(140,160,230,0.35)';
    for (let i = 0; i < 70; i++) {
      const x = (i * 53 + now * 40 * (1 + (i % 3))) % (C.W + 20) - 10;
      const y = (i * 97 + now * 220 * (1 + (i % 2) * 0.4)) % C.H;
      g.fillRect(Math.round(x), Math.round(y), 1, 3);
    }
    const oy = Math.floor((C.H - 180) / 2);   // le contenu du titre reste centré en 480x270
    T(g, 'CYBERPUNK', C.W / 2, oy + 18, '#f2d43a', { align: 'center', scale: 4, shadow: '#a0157a' });
    T(g, 'EDGERUNNER LEGACY', C.W / 2, oy + 42, '#3ef0ff', { align: 'center', scale: 2, shadow: '#1a1030' });
    T(g, 'PROTOTYPE DE COMBAT · ' + C.VERSION, C.W / 2, oy + 56, '#8f98a0', { align: 'center' });

    const mv = C.keyLabel('KeyW') + C.keyLabel('KeyA') + C.keyLabel('KeyS') + C.keyLabel('KeyD');
    g.fillStyle = 'rgba(5,4,12,0.75)'; g.fillRect(C.W / 2 - 120, oy + 68, 240, 44);
    T(g, '[' + mv + '] BOUGER   [CLIC] TIRER   [CLIC DROIT] LAME', C.W / 2, oy + 73, '#c7d5e0', { align: 'center' });
    T(g, '[ESPACE] DASH   [MAJ] SANDEVISTAN   ' + K('KeyF') + ' INJECTEUR', C.W / 2, oy + 82, '#c7d5e0', { align: 'center' });
    T(g, K('KeyR') + ' RECHARGER   ENNEMI À TERRE : ' + K('KeyE') + ' ACHEVER  ' + K('KeyC') + ' ÉPARGNER', C.W / 2, oy + 91, '#c7d5e0', { align: 'center' });
    T(g, 'LE SANDEVISTAN COÛTE DE L\'HUMANITÉ. À 0 : CYBERPSYCHOSE.', C.W / 2, oy + 101, '#ff3ec8', { align: 'center' });

    // mur des légendes : les derniers leaders de cette ville
    const city = C.legacy.city;
    if (city.leaders.length) {
      T(g, 'MUR DES LÉGENDES', C.W / 2, oy + 112, '#f2d43a', { align: 'center' });
      city.leaders.slice(-3).reverse().forEach((l, i) => T(g, legendLine(l), C.W / 2, oy + 121 + i * 8, i ? '#6f7c8a' : '#c7d5e0', { align: 'center' }));
    }
    const sv = C.run.info(), cy = oy + (city.leaders.length ? 148 : 126);
    if (sv) {
      // partie sauvegardée : on reprend le leader, ou on en crée un nouveau (l'ancien disparaît)
      if (Math.sin(now * 4) > -0.3) T(g, 'CLIC : CONTINUER AVEC ' + sv.nom + ' · GIG ' + sv.gigs + ' · NV ' + sv.lvl + ' · ' + sv.eddies + ' €$', C.W / 2, cy, '#ffffff', { align: 'center' });
      T(g, C.game.abandonT > 0 ? '[N] ENCORE : ' + sv.nom + ' DISPARAÎT POUR DE BON' : '[N] NOUVEAU LEADER', C.W / 2, cy + 9, C.game.abandonT > 0 ? '#ff3e5a' : '#8f98a0', { align: 'center' });
    } else if (Math.sin(now * 4) > -0.3) T(g, 'CLIC POUR COMMENCER', C.W / 2, cy + 2, '#ffffff', { align: 'center' });
    T(g, K('KeyV') + ' RÉSOLUTION ' + C.W + '×' + C.H + '   ' + K('KeyM') + ' MUSIQUE ' + (C.music.enabled ? 'OUI' : 'NON'), 4, C.H - 12, '#8f98a0');
    if (C.game.wipeT > 0) T(g, 'SUPPR ENCORE POUR EFFACER LA VILLE', 4, C.H - 20, '#ff3e5a');
    else if (city.gen) T(g, '[SUPPR] EFFACER LA VILLE', 4, C.H - 20, '#6f7c8a');

    quitRect = null;
    if (IS_STREAZ) {
      quitRect = [C.W - 70, C.H - 16, 66, 12];
      const hov = R.overQuit();
      g.fillStyle = hov ? '#ff3e5a' : 'rgba(5,4,12,0.8)'; g.fillRect(...quitRect);
      g.fillStyle = '#ff3e5a'; g.fillRect(quitRect[0], quitRect[1] + quitRect[3] - 1, quitRect[2], 1);
      T(g, 'QUITTER LE JEU', quitRect[0] + quitRect[2] / 2, quitRect[1] + 4, '#ffffff', { align: 'center' });
    }
    // curseur
    const mx = Math.round(C.input.mx), my = Math.round(C.input.my);
    g.fillStyle = '#05050a'; g.fillRect(mx - 1, my - 1, 3, 3);
    g.fillStyle = '#ffffff'; g.fillRect(mx, my, 1, 1);
  }

  const pl = (n, w) => n + ' ' + w + (n > 1 ? 'S' : '');
  function legendLine(l) {
    const fin = { psycho: 'CYBERPSYCHO', legende: 'LÉGENDE', fixer: 'FIXER', disparu: 'DISPARU' }[l.fin] || 'MORT';
    return l.nom + ' · ' + C.legacy.origin(l.origine).nom + ' · ' + fin + ' AU GIG ' + l.gigs + ' · ' + pl(l.acheves, 'ACHEVÉ') + ' · ' + pl(l.epargnes, 'ÉPARGNÉ');
  }

  // Écran de création : trois profils, un par origine.
  let cards = [];
  R.cardUnderMouse = () => {
    const { mx, my } = C.input;
    return cards.findIndex(([x, y, w, h]) => mx >= x && mx < x + w && my >= y && my < y + h);
  };
  function drawCreate(g, G, now) {
    if (!skyline) skyline = buildSkyline();
    g.drawImage(skyline, 0, 0);
    g.fillStyle = 'rgba(4,3,10,0.7)'; g.fillRect(0, 0, C.W, C.H);
    const oy = Math.floor((C.H - 180) / 2), city = C.legacy.city;
    T(g, 'NOUVEAU LEADER', C.W / 2, oy + 12, '#f2d43a', { align: 'center', scale: 2, shadow: '#a0157a' });
    const n = city.gen;
    T(g, n ? 'LA VILLE SE SOUVIENT DE ' + n + ' LEADER' + (n > 1 ? 'S' : '') : 'NIGHT CITY NE TE CONNAÎT PAS ENCORE.', C.W / 2, oy + 30, '#8f98a0', { align: 'center' });
    const cw = 92, gap = 6, ch = 86, x0 = Math.round(C.W / 2 - (cw * 3 + gap * 2) / 2), y0 = oy + 42;
    const hover = G.createSel >= 0 ? G.createSel : R.cardUnderMouse();   // flèches / manette, sinon la souris
    cards = [];
    G.profiles.forEach((pr, i) => {
      const x = x0 + i * (cw + gap), o = C.legacy.origin(pr.origine), on = hover === i;
      cards.push([x, y0, cw, ch]);
      g.fillStyle = on ? 'rgba(242,212,58,0.12)' : 'rgba(10,8,20,0.9)'; g.fillRect(x, y0, cw, ch);
      g.fillStyle = on ? '#f2d43a' : '#2d3150';
      g.fillRect(x, y0, cw, 1); g.fillRect(x, y0 + ch - 1, cw, 1); g.fillRect(x, y0, 1, ch); g.fillRect(x + cw - 1, y0, 1, ch);
      T(g, '[' + (i + 1) + ']', x + 4, y0 + 4, '#6f7c8a');
      T(g, pr.nom, x + cw / 2, y0 + 14, '#ffffff', { align: 'center', scale: 2 });
      T(g, o.nom, x + cw / 2, y0 + 30, '#c7d5e0', { align: 'center' });
      T(g, o.perk, x + cw / 2, y0 + 39, '#5dff9a', { align: 'center' });
      if (pr.lien) T(g, pr.lien, x + cw / 2, y0 + 50, '#ff3ec8', { align: 'center' });
      drawChar(g, x + cw / 2, y0 + 70, -Math.PI / 2 + Math.sin(now * 2 + i) * 0.6, { jacket: PAL.player.jacket, hair: PAL.player.hair, skin: PAL.player.skin, gun: true });
    });
    // ce que les leaders passés ont laissé
    const left = [];
    if (city.corpse && !city.corpse.taken) left.push('LE CORPS DE ' + city.corpse.nom);
    const sp = city.spared.filter(s => !s.used).length;
    if (sp) left.push(sp + ' ÉPARGNÉ' + (sp > 1 ? 'S' : ''));
    if (city.psycho && !city.psycho.defeated) left.push(city.psycho.nom + ' (CYBERPSYCHO)');
    if (left.length) T(g, 'DANS LA VILLE : ' + left.join(' · '), C.W / 2, y0 + ch + 8, '#b89a22', { align: 'center' });
    T(g, 'CLIC OU [1] [2] [3] POUR CHOISIR   [ÉCHAP] RETOUR', C.W / 2, y0 + ch + 20, '#6f7c8a', { align: 'center' });
    const mx = Math.round(C.input.mx), my = Math.round(C.input.my);
    g.fillStyle = '#05050a'; g.fillRect(mx - 1, my - 1, 3, 3);
    g.fillStyle = '#ffffff'; g.fillRect(mx, my, 1, 1);
  }

  // Boutique du ripperdoc (jeu en pause).
  let shopRows = [];
  R.shopRowUnderMouse = () => {
    const { mx, my } = C.input;
    return shopRows.findIndex(([x, y, w, h]) => mx >= x && mx < x + w && my >= y && my < y + h);
  };
  function drawShop(g, G) {
    const L0 = G.leader, s = G.shop, items = G.shopItems();
    g.fillStyle = 'rgba(4,3,10,0.7)'; g.fillRect(0, 0, C.W, C.H);
    const w = 280, h = 152, x = Math.round((C.W - w) / 2), y = Math.round((C.H - h) / 2);
    g.fillStyle = '#0b0a16'; g.fillRect(x, y, w, h);
    g.fillStyle = '#3ef0ff'; g.fillRect(x, y, w, 1);
    g.fillStyle = '#2d3150'; g.fillRect(x, y + h - 1, w, 1); g.fillRect(x, y, 1, h); g.fillRect(x + w - 1, y, 1, h);
    T(g, 'DOC ZHAO · RIPPERDOC', x + 6, y + 6, '#d8dde6');
    T(g, L0.eddies + ' €$', x + w - 6, y + 6, '#ffd23e', { align: 'right' });
    T(g, 'HUMANITÉ ' + Math.round(G.humanity), x + w - 6, y + 14, G.humanity < D.humanity.hallucinate ? '#ff3ec8' : '#c45cff', { align: 'right' });
    shopRows = [];
    items.forEach((id, i) => {
      const ry = y + 24 + i * 8, sel = i === s.sel;
      shopRows.push([x + 2, ry - 1, w - 4, 8]);
      if (sel) { g.fillStyle = 'rgba(62,240,255,0.14)'; g.fillRect(x + 2, ry - 1, w - 4, 8); T(g, '>', x + 4, ry, '#3ef0ff'); }
      if (id === 'immuno') {
        const it = D.immuno;
        T(g, 'SOIN', x + 10, ry, '#6f7c8a');
        T(g, it.nom, x + 46, ry, '#ffffff');
        T(g, it.prix + ' €$  +' + it.hum + ' HUM', x + w - 6, ry, L0.eddies >= it.prix ? '#5dff9a' : '#6f7c8a', { align: 'right' });
        return;
      }
      const imp = D.implants[id], on = L0.implants[imp.slot] === id;
      const rich = L0.eddies >= imp.prix;
      T(g, imp.slot, x + 10, ry, '#6f7c8a');
      T(g, imp.nom, x + 46, ry, on ? '#3ef0ff' : '#ffffff');
      T(g, on ? 'POSÉ' : imp.prix + ' €$  -' + imp.hum + ' HUM', x + w - 6, ry, on ? '#3ef0ff' : rich ? '#ffd23e' : '#6f7c8a', { align: 'right' });
    });
    const cur = items[s.sel], info = cur === 'immuno' ? D.immuno.desc : D.implants[cur].desc;
    T(g, info, x + 6, y + 112, '#c7d5e0');
    if (cur !== 'immuno') {
      const imp = D.implants[cur], other = L0.implants[imp.slot];
      if (other && other !== cur) T(g, 'REMPLACE : ' + D.implants[other].nom, x + 6, y + 120, '#8f98a0');
    }
    if (s.msgT > 0) T(g, s.msg, x + 6, y + 130, s.msgCol);
    T(g, '[HAUT/BAS] CHOISIR  [E] POSER  [X] RETIRER  [ÉCHAP] SORTIR', C.W / 2, y + h - 10, '#6f7c8a', { align: 'center' });
    const mx = Math.round(C.input.mx), my = Math.round(C.input.my);
    g.fillStyle = '#05050a'; g.fillRect(mx - 1, my - 1, 3, 3);
    g.fillStyle = '#ffffff'; g.fillRect(mx, my, 1, 1);
  }

  // Concessionnaire (jeu en pause) : une ligne par modèle, avec l'aperçu de la voiture.
  let dealerRows = [];
  R.dealerRowUnderMouse = () => {
    const { mx, my } = C.input;
    return dealerRows.findIndex(([x, y, w, h]) => mx >= x && mx < x + w && my >= y && my < y + h);
  };
  function drawDealer(g, G) {
    const s = G.dealerMenu, L0 = G.leader, ids = G.dealerItems();
    g.fillStyle = 'rgba(4,3,10,0.7)'; g.fillRect(0, 0, C.W, C.H);
    const w = 280, h = 150, x = Math.round((C.W - w) / 2), y = Math.round((C.H - h) / 2);
    g.fillStyle = '#0b0a16'; g.fillRect(x, y, w, h);
    g.fillStyle = '#c9a227'; g.fillRect(x, y, w, 1);
    g.fillStyle = '#2d3150'; g.fillRect(x, y + h - 1, w, 1); g.fillRect(x, y, 1, h); g.fillRect(x + w - 1, y, 1, h);
    T(g, G.dealer.nom + ' · VOITURES', x + 6, y + 6, '#d8dde6');
    T(g, L0.eddies + ' €$', x + w - 6, y + 6, '#ffd23e', { align: 'right' });
    dealerRows = [];
    ids.forEach((id, i) => {
      const m = C.cars.MODELS[id], ry = y + 20 + i * 34, sel = i === s.sel, mine = L0.car && L0.car.model === id;
      dealerRows.push([x + 3, ry - 2, w - 6, 32]);
      g.fillStyle = sel ? 'rgba(201,162,39,0.16)' : 'rgba(255,255,255,0.03)'; g.fillRect(x + 3, ry - 2, w - 6, 32);
      C.cars.draw(g, { x: x + 30, y: ry + 14, ang: -0.35 + Math.sin(G.time * 1.5 + i) * 0.15, model: id, color: mine ? L0.car.color : C.cars.COLORS[(i * 3 + 1) % C.cars.COLORS.length] });
      T(g, m.nom, x + 58, ry + 3, '#ffffff');
      T(g, mine ? 'À TOI' : m.prix + ' €$', x + w - 8, ry + 3, mine ? '#5dff9a' : L0.eddies >= m.prix ? '#ffd23e' : '#6f7c8a', { align: 'right' });
      T(g, m.desc, x + 58, ry + 12, '#8f98a0');
      T(g, 'VITESSE ' + Math.round(m.speed * 0.9) + ' KM/H', x + 58, ry + 21, '#6f7c8a');
    });
    if (s.msgT > 0) T(g, s.msg, C.W / 2, y + h - 20, s.msgCol, { align: 'center' });
    T(g, '[HAUT/BAS] CHOISIR   [E] ACHETER   [ÉCHAP] SORTIR', C.W / 2, y + h - 10, '#6f7c8a', { align: 'center' });
    const mx = Math.round(C.input.mx), my = Math.round(C.input.my);
    g.fillStyle = '#05050a'; g.fillRect(mx - 1, my - 1, 3, 3);
    g.fillStyle = '#ffffff'; g.fillRect(mx, my, 1, 1);
  }

  // Tableau des contrats du fixer (jeu en pause).
  let boardRows = [];
  R.boardRowUnderMouse = () => {
    const { mx, my } = C.input;
    return boardRows.findIndex(([x, y, w, h]) => mx >= x && mx < x + w && my >= y && my < y + h);
  };
  function drawBoard(g, G) {
    const b = G.board, L0 = G.leader;
    g.fillStyle = 'rgba(4,3,10,0.7)'; g.fillRect(0, 0, C.W, C.H);
    const w = 280, h = 150, x = Math.round((C.W - w) / 2), y = Math.round((C.H - h) / 2);
    g.fillStyle = '#0b0a16'; g.fillRect(x, y, w, h);
    g.fillStyle = '#c45cff'; g.fillRect(x, y, w, 1);
    g.fillStyle = '#2d3150'; g.fillRect(x, y + h - 1, w, 1); g.fillRect(x, y, 1, h); g.fillRect(x + w - 1, y, 1, h);
    T(g, G.fixer.nom + ' · CONTRATS', x + 6, y + 6, '#d8dde6');
    T(g, L0.eddies + ' €$', x + w - 6, y + 6, '#ffd23e', { align: 'right' });
    const arcs = Object.keys(L0.arcs).map(f => 'ARC ' + D.factions[f].nom + ' ' + Math.min(L0.arcs[f], D.arcLength) + '/' + D.arcLength).join('   ');
    T(g, arcs + (L0.burned ? '   GRILLÉ' : ''), x + 6, y + 15, L0.burned ? '#ff8a5a' : '#8f98a0');
    boardRows = [];
    b.offers.forEach((o, i) => {
      const ry = y + 28 + i * 30, sel = i === b.sel, f = D.factions[o.faction];
      boardRows.push([x + 3, ry - 3, w - 6, 28]);
      g.fillStyle = sel ? 'rgba(196,92,255,0.16)' : 'rgba(255,255,255,0.03)'; g.fillRect(x + 3, ry - 3, w - 6, 28);
      if (sel) { g.fillStyle = '#c45cff'; g.fillRect(x + 3, ry - 3, 1, 28); }
      T(g, (o.grand ? 'GRAND CONTRAT · ' : '') + f.nom, x + 8, ry, f.color);
      T(g, o.pay + ' €$', x + w - 8, ry, '#ffd23e', { align: 'right' });
      T(g, (o.grand ? 'LE CADRE ' + f.nom : D.contracts[o.type].nom) + ' · ' + (C.MAPS[o.site].outdoor ? 'RUES DE ' : C.MAPS[o.site].nom + ' · ') + C.MAPS[C.districtOf(o.site)].quartier, x + 8, ry + 8, '#ffffff');
      T(g, o.grand ? D.grand.desc : D.contracts[o.type].desc, x + 8, ry + 16, '#8f98a0');
    });
    const sel = b.offers[b.sel];
    if (sel && sel.grand) T(g, 'MORT = LÉGENDE · RÉUSSITE = TU DEVIENS FIXER', C.W / 2, y + h - 20, '#ffd23e', { align: 'center' });
    T(g, '[HAUT/BAS] CHOISIR   [E] ACCEPTER   [ÉCHAP] PLUS TARD', C.W / 2, y + h - 10, '#6f7c8a', { align: 'center' });
    const mx = Math.round(C.input.mx), my = Math.round(C.input.my);
    g.fillStyle = '#05050a'; g.fillRect(mx - 1, my - 1, 3, 3);
    g.fillStyle = '#ffffff'; g.fillRect(mx, my, 1, 1);
  }

  // Plan du métro NCART (jeu en pause) : la ligne, les stations, ce qui t'attend dans chaque quartier.
  let metroRows = [];
  R.metroRowUnderMouse = () => {
    const { mx, my } = C.input;
    return metroRows.findIndex(([x, y, w, h]) => mx >= x && mx < x + w && my >= y && my < y + h);
  };
  function drawMetro(g, G) {
    const s = G.metroMenu, line = C.LINE;
    g.fillStyle = 'rgba(4,3,10,0.75)'; g.fillRect(0, 0, C.W, C.H);
    const w = 290, h = 156, x = Math.round((C.W - w) / 2), y = Math.round((C.H - h) / 2);
    g.fillStyle = '#0b0a16'; g.fillRect(x, y, w, h);
    g.fillStyle = '#ffb000'; g.fillRect(x, y, w, 1);
    g.fillStyle = '#2d3150'; g.fillRect(x, y + h - 1, w, 1); g.fillRect(x, y, 1, h); g.fillRect(x + w - 1, y, 1, h);
    T(g, 'NCART · LIGNE 1', x + 6, y + 6, '#ffb000');
    T(g, 'STATION ' + C.MAPS[M.id].quartier, x + w - 6, y + 6, '#8f98a0', { align: 'right' });
    // plan : silhouette de la ville, côte, ligne jaune
    const px = x + 8, py = y + 18, pw = 116, ph = 116;
    g.fillStyle = '#10101c'; g.fillRect(px, py, pw, ph);
    for (let i = 0; i < 40; i++) { g.fillStyle = '#181828'; g.fillRect(px + 4 + ((i * 37) % (pw - 12)), py + 4 + ((i * 53) % (ph - 12)), 6 + (i % 3) * 2, 4 + (i % 4)); }
    g.fillStyle = '#0a2a3a';
    for (let yy = 0; yy < ph; yy++) { const sh = Math.round(pw * 0.08 + (yy / ph) * pw * 0.12 + Math.sin(yy * 0.2) * 2); g.fillRect(px, py + yy, sh, 1); }
    const P = id => [px + Math.round(C.STATIONS[id].x * pw), py + Math.round(C.STATIONS[id].y * ph)];
    for (let i = 0; i < line.length - 1; i++) {
      const [ax, ay] = P(line[i]), [bx, by] = P(line[i + 1]);
      pline(g, ax, ay, bx, by, '#ffb000'); pline(g, ax + 1, ay, bx + 1, by, '#c98a00');
    }
    const k = G.contract, goalD = G.goalDistrict();
    metroRows = [];
    line.forEach((id, i) => {
      const [sx, sy] = P(id), here = id === M.id, sel = i === s.sel, D0 = C.MAPS[id];
      g.fillStyle = '#05050a'; g.fillRect(sx - 3, sy - 3, 7, 7);
      g.fillStyle = here ? '#5dff9a' : sel ? '#ffffff' : '#ffb000'; g.fillRect(sx - 2, sy - 2, 5, 5);
      if (sel && Math.sin(G.time * 8) > 0) { g.fillStyle = '#ffffff'; g.fillRect(sx - 4, sy - 4, 9, 1); g.fillRect(sx - 4, sy + 4, 9, 1); }
      T(g, D0.quartier, sx + (C.STATIONS[id].x > 0.6 ? -5 : 5), sy - 2, here ? '#5dff9a' : '#c7d5e0', { align: C.STATIONS[id].x > 0.6 ? 'right' : 'left' });
      // liste à droite
      const rx = x + 132, ry = y + 20 + i * 32;
      metroRows.push([rx - 2, ry - 3, w - 136, 30]);
      g.fillStyle = sel ? 'rgba(255,176,0,0.16)' : 'rgba(255,255,255,0.03)'; g.fillRect(rx - 2, ry - 3, w - 136, 30);
      if (sel) { g.fillStyle = '#ffb000'; g.fillRect(rx - 2, ry - 3, 1, 30); }
      T(g, D0.quartier, rx + 2, ry, here ? '#5dff9a' : '#ffffff');
      T(g, here ? 'TU ES ICI' : Math.abs(C.LINE.indexOf(M.id) - i) + ' ARRÊT' + (Math.abs(C.LINE.indexOf(M.id) - i) > 1 ? 'S' : ''), rx + w - 142, ry, here ? '#5dff9a' : '#6f7c8a', { align: 'right' });
      T(g, C.STATIONS[id].sub, rx + 2, ry + 8, '#8f98a0');
      const notes = [];
      if (id === 'rue') notes.push('PLANQUE');
      if (id === 'rue') notes.push('VOITURES');
      if (k && !k.done && !k.failed && C.districtOf(k.site) === id) notes.push('CONTRAT : ' + C.MAPS[k.site].nom);
      const own = G.leader.car;
      if (own && own.map === id && id !== 'rue') notes.push('TA VOITURE');
      T(g, notes.join(' · '), rx + 2, ry + 16, id === goalD ? '#f2d43a' : '#6f7c8a');
    });
    T(g, '[HAUT/BAS] CHOISIR   [E] MONTER   [ÉCHAP] SORTIR', C.W / 2, y + h - 10, '#6f7c8a', { align: 'center' });
    const mx = Math.round(C.input.mx), my = Math.round(C.input.my);
    g.fillStyle = '#05050a'; g.fillRect(mx - 1, my - 1, 3, 3);
    g.fillStyle = '#ffffff'; g.fillRect(mx, my, 1, 1);
  }

  // Le trajet : vue de côté d'une rame NCART, le tunnel puis la ville qui défilent derrière les vitres.
  function drawRide(g, G) {
    const r = G.ride, t = r.t, k = Math.min(1, t / r.dur), W = C.W, H = C.H;
    const speed = Math.sin(Math.min(1, k * 1.15) * Math.PI) * 0.9 + 0.1;   // départ, pleine vitesse, freinage
    r.scroll = (r.scroll || 0) + speed * 9;
    g.fillStyle = '#07070c'; g.fillRect(0, 0, W, H);
    const wy = Math.round(H * 0.18), wh = Math.round(H * 0.34);
    // dehors : tunnel (début et fin) ou ville de nuit (milieu du trajet, la ligne est aérienne)
    const outside = k > 0.22 && k < 0.8;
    if (outside) {
      g.fillStyle = '#0c0a1e'; g.fillRect(0, wy, W, wh);
      for (let layer = 0; layer < 2; layer++) {
        const sp = layer ? 1 : 0.4, step = layer ? 26 : 14;
        for (let i = -1; i < W / step + 2; i++) {
          const n = Math.floor(r.scroll * sp / step) + i, bx = Math.round(i * step - ((r.scroll * sp) % step));
          const hh = 10 + (((n * 7919) % 97) / 97) * wh * (layer ? 0.8 : 0.6);
          g.fillStyle = layer ? '#14142a' : '#101024'; g.fillRect(bx, wy + wh - hh, step - 3, hh);
          for (let j = 0; j < 6; j++) if (((n * 31 + j * 17) % 7) < 2) { g.fillStyle = ['#ff3ec8', '#3ef0ff', '#ffd23e', '#7a5cff'][(n + j) % 4]; g.fillRect(bx + 2 + (j % 3) * 4, wy + wh - hh + 3 + Math.floor(j / 3) * 5, 2, 1); }
        }
      }
    } else {
      g.fillStyle = '#0a0a10'; g.fillRect(0, wy, W, wh);
      // lampes du tunnel qui filent
      for (let i = 0; i < 6; i++) {
        const lx = Math.round(((i * 97 - r.scroll * 2.2) % (W + 60) + W + 60) % (W + 60) - 30);
        g.fillStyle = '#ffcf8a'; g.fillRect(lx, wy + 6, Math.round(4 + speed * 30), 1);
        g.fillStyle = 'rgba(255,207,138,0.15)'; g.fillRect(lx, wy + 3, Math.round(4 + speed * 30), 7);
      }
      g.fillStyle = '#14141c'; g.fillRect(0, wy + wh - 8, W, 8);
    }
    // la rame : parois, montants de fenêtres, sièges, barres
    g.fillStyle = '#1e2230'; g.fillRect(0, 0, W, wy); g.fillRect(0, wy + wh, W, H - wy - wh);
    g.fillStyle = '#ffb000'; g.fillRect(0, wy - 3, W, 2);
    for (let x = 0; x < W; x += 64) { g.fillStyle = '#1e2230'; g.fillRect(x, wy, 8, wh); g.fillStyle = '#2a3042'; g.fillRect(x + 2, wy, 1, wh); }
    g.fillStyle = 'rgba(255,255,255,0.05)'; for (let x = 12; x < W; x += 64) g.fillRect(x, wy + 2, 20, 1);
    const sy0 = wy + wh + 10;
    for (let x = 6; x < W; x += 40) { g.fillStyle = '#3a1a4a'; g.fillRect(x, sy0, 30, 12); g.fillStyle = '#5a2a6a'; g.fillRect(x, sy0, 30, 3); }
    g.fillStyle = '#8a8f9a'; for (let x = 36; x < W; x += 80) g.fillRect(x, 0, 2, sy0 - 2);
    g.fillStyle = '#12141c'; g.fillRect(0, H - 34, W, 34);
    // secousses de la voie
    if (Math.random() < speed * 0.3) { g.fillStyle = 'rgba(0,0,0,0.25)'; g.fillRect(0, 0, W, H); }
    // bandeau : la ligne et la progression
    const lx0 = 30, lx1 = W - 30, ly = H - 20, i0 = C.LINE.indexOf(r.from), i1 = C.LINE.indexOf(r.to);
    const n = C.LINE.length, xs = i => lx0 + ((lx1 - lx0) * i) / (n - 1);
    g.fillStyle = '#ffb000'; g.fillRect(lx0, ly, lx1 - lx0, 1);
    C.LINE.forEach((id, i) => {
      g.fillStyle = i === i1 ? '#5dff9a' : '#ffb000'; g.fillRect(Math.round(xs(i)) - 2, ly - 2, 5, 5);
      T(g, C.MAPS[id].quartier, xs(i), ly + 5, i === i1 ? '#5dff9a' : '#6f7c8a', { align: 'center' });
    });
    const tx = xs(i0) + (xs(i1) - xs(i0)) * (k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2);
    g.fillStyle = '#ffffff'; g.fillRect(Math.round(tx) - 3, ly - 4, 7, 3);
    T(g, 'PROCHAIN ARRÊT : ' + C.MAPS[r.to].quartier, W / 2, 8, '#ffb000', { align: 'center' });
    T(g, C.STATIONS[r.to].sub, W / 2, 16, '#8f98a0', { align: 'center' });
    if (t > 0.5) T(g, K('KeyE') + ' PASSER', W - 6, H - 44, '#6f7c8a', { align: 'right' });
    if (k > 0.85) { g.fillStyle = `rgba(0,0,0,${(k - 0.85) / 0.15})`; g.fillRect(0, 0, W, H); }
    if (t < 0.25) { g.fillStyle = `rgba(0,0,0,${1 - t / 0.25})`; g.fillRect(0, 0, W, H); }
  }

  function drawOver(g, G) {
    const a = Math.min(1, G.overT * 2);
    g.fillStyle = `rgba(6,0,10,${0.72 * a})`;
    g.fillRect(0, 0, C.W, C.H);
    if (G.overT < 0.25) return;
    const oy = Math.floor((C.H - 180) / 2);
    const why = G.overReason, psycho = why === 'psycho';
    const title = { psycho: 'CYBERPSYCHOSE', legende: 'LÉGENDE', fixer: 'NOUVEAU FIXER' }[why] || 'LEADER À TERRE';
    const tcol = { psycho: '#ff3ec8', legende: '#ffd23e', fixer: '#3ef0ff' }[why] || '#ff3e5a';
    if (psycho) T(g, title, C.W / 2 + 1, oy + 48, '#3ef0ff', { align: 'center', scale: 3 });
    T(g, title, C.W / 2, oy + 48, tcol, { align: 'center', scale: 3 });
    const ld = G.leader;
    T(g, ld.nom + ' · ' + C.legacy.origin(ld.origine).nom + ' · NIVEAU ' + (ld.lvl || 1) + ' · ' + ld.gigs + ' GIG' + (ld.gigs > 1 ? 'S' : ''), C.W / 2, oy + 68, '#f2d43a', { align: 'center' });
    const line = {
      psycho: 'LE CHROME A GAGNÉ. LE MAXTAC EST EN ROUTE.',
      legende: 'MORT EN PLEIN GRAND CONTRAT. ON PARLERA DE ' + ld.nom + ' LONGTEMPS.',
      fixer: ld.nom + ' RACCROCHE LES FLINGUES. RÉPUTATION ' + '*'.repeat(G.fixerStars || 1) + '.',
    }[why] || (G.wanted && G.wanted.stars > 0 && M.def.outdoor ? "ABATTU PAR LE NCPD EN PLEINE RUE." : "SA PARTIE S'ARRÊTE ICI. LA VILLE S'EN SOUVIENDRA.");
    T(g, line, C.W / 2, oy + 78, '#c7d5e0', { align: 'center' });
    const r = G.reg, down = G.enemies.filter(e => e.state === 'down').length;
    T(g, 'ACHEVÉS ' + r.acheves + '   ÉPARGNÉS ' + r.epargnes + '   LAISSÉS À TERRE ' + down, C.W / 2, oy + 92, '#ffffff', { align: 'center' });
    const s = Math.round(r.temps);
    T(g, 'TEMPS ' + Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0') + '   TIRS ' + r.tirs + '   TOUCHÉS ' + r.touches, C.W / 2, oy + 102, '#8f98a0', { align: 'center' });
    // ce qu'il laisse au leader suivant
    const inj = G.player.inj, sp = ld.spared.length;
    const legs = psycho ? 'IL RÔDE MAINTENANT DANS LA VILLE.' : why === 'fixer' ? 'IL DONNERA LES CONTRATS AU PROCHAIN LEADER.' : 'IL LAISSE SON CORPS' + (inj ? ' ET ' + inj + ' INJECTEUR' + (inj > 1 ? 'S' : '') : '') + '.';
    T(g, legs, C.W / 2, oy + 116, '#b89a22', { align: 'center' });
    if (sp) T(g, sp + ' ÉPARGNÉ' + (sp > 1 ? 'S' : '') + ' SE SOUVIENDR' + (sp > 1 ? 'ONT' : 'A') + ' DE ' + ld.nom + '.', C.W / 2, oy + 125, '#5dff9a', { align: 'center' });
    if (G.comp) T(g, G.comp.state === 'up' ? G.comp.nom + ' SURVIT ET POURRAIT REPRENDRE LE FLAMBEAU.' : G.comp.nom + ' NE SE RELÈVERA PAS.', C.W / 2, oy + 134, G.comp.state === 'up' ? '#3ec8ff' : '#ff8a5a', { align: 'center' });
    if (G.overT > 0.8 && Math.sin(G.overT * 4) > -0.3) T(g, K('Enter') + ' NOUVEAU LEADER', C.W / 2, oy + 150, '#f2d43a', { align: 'center' });
  }

  // ---------- image ----------
  R.draw = function (now) {
    const g = C.g, G = C.game;
    g.globalAlpha = 1;
    g.globalCompositeOperation = 'source-over';
    screenBuffers();
    if (G.mode === 'title') { drawTitle(g, now); return; }
    if (G.mode === 'create') { drawCreate(g, G, now); return; }
    if (G.mode === 'play' && G.ride) { drawRide(g, G); return; }

    const shx = G.shake ? C.rr(-G.shake, G.shake) : 0, shy = G.shake ? C.rr(-G.shake, G.shake) : 0;
    const sx = Math.round(G.cam.x + shx), sy = Math.round(G.cam.y + shy);
    g.fillStyle = '#07070c';
    g.fillRect(0, 0, C.W, C.H);
    g.drawImage(world, -sx, -sy);
    g.drawImage(decals, -sx, -sy);

    // 1. le sol : corps, flaques, terminal, fauteuil, sang et douilles (assombris par l'éclairage comme le décor)
    g.save();
    g.translate(-sx, -sy);
    if (G.corpse) drawCorpse(g, G.corpse, G.time);
    for (const e of G.enemies) if (e.state === 'dead' || e.state === 'spared' || e.state === 'down') drawBody(g, e, G.time);
    for (const q of G.peds || []) if (q.dead) {
      // civil tué : flaque et corps
      bloodPool(g, q.x - Math.cos(q.downAng), q.y - Math.sin(q.downAng), Math.min(q.gibbed ? 12 : 9, (q.gibbed ? 6 : 2) + Math.max(0, q.downT - 0.2) * 2));
      if (q.gibbed) continue;
      const [pose, frame] = fallPose(q.downT);
      drawChar(g, q.x, q.y, q.downAng, Object.assign({}, q.outfit, { jacket: shade(q.jacket, 0.6), pose, frame, shadow: false }));
    }
    const home = M.id === 'planque';
    if (home && G.doc) {
      // fauteuil du ripperdoc
      const x = Math.round(G.doc.x) + 7, y = Math.round(G.doc.y) - 5;
      g.fillStyle = '#05050a'; g.fillRect(x - 1, y - 1, 8, 12);
      g.fillStyle = '#5a1a2a'; g.fillRect(x, y, 6, 10);
      g.fillStyle = '#7a2a3a'; g.fillRect(x, y, 6, 2); g.fillRect(x, y + 2, 1, 8); g.fillRect(x + 5, y + 2, 1, 8);
      g.fillStyle = '#b8c4d6'; g.fillRect(x + 2, y + 5, 2, 1);
    }
    const k = G.contract;
    C.arsenal.drawDrops(g, G.time);   // armes au sol
    C.contracts.drawFloor(g, G.time, drawChar);
    C.home.drawFloor(g, G.time);   // bar de Luna, écran N54   // colis, générateur, otage mort
    for (const q of G.parts) {
      if (q.kind === 'blood' || q.kind === 'shell') { g.fillStyle = q.color; g.fillRect(Math.round(q.x), Math.round(q.y), q.size || 1, q.size || 1); }
      else if (q.kind === 'gib') {
        g.fillStyle = '#1a0408'; g.fillRect(Math.round(q.x) - 1, Math.round(q.y) - 1, q.w + 2, q.h + 2);
        g.fillStyle = q.color; g.fillRect(Math.round(q.x), Math.round(q.y), q.w, q.h);
      }
    }
    g.restore();

    // 2. les personnages, sur un calque à part : ils seront moins assombris que le décor (plus lisibles)
    const a = ac.getContext('2d');
    a.setTransform(1, 0, 0, 1, 0, 0);
    a.globalAlpha = 1; a.globalCompositeOperation = 'source-over';
    a.clearRect(0, 0, C.W, C.H);
    a.translate(-sx, -sy);
    // voitures (garées, et celle du leader)
    for (const car of G.cars || []) C.cars.draw(a, car);
    if (G.dealer) drawChar(a, G.dealer.x, G.dealer.y, G.dealer.aim, { jacket: '#8a6a3a', hair: '#cfcfcf', skin: '#c9926c', pose: 'bare' });
    for (const e of G.enemies) if (e.state === 'friend') drawEnemy(a, e);
    // passants de la rue
    for (const q of G.peds || []) if (!q.dead) drawChar(a, q.x, q.y, q.aim, { jacket: q.jacket, hair: q.outfit.hair, skin: q.outfit.skin, pants: q.outfit.pants, style: q.outfit.style, cap: q.outfit.cap, pose: 'bare', flash: q.hurtT > 0, frame: C.sprites.walkFrame(q.walk, q.running || (q.tx !== null && q.wait <= 0)) });
    if (home && G.doc) drawChar(a, G.doc.x, G.doc.y, G.doc.aim, { jacket: '#d8dde6', hair: '#6f7c8a', skin: '#d9a07a', pose: 'bare' });
    if (home && G.fixer) drawChar(a, G.fixer.x, G.fixer.y, G.fixer.aim, { jacket: G.fixer.former ? PAL.player.jacket : '#7a3cff', hair: G.fixer.former ? PAL.player.hair : '#2a1030', skin: '#c9926c', pose: 'bare' });
    if (home && G.recruit) drawChar(a, G.recruit.x, G.recruit.y, G.recruit.aim, { jacket: '#2a8fb8', hair: '#16263a', skin: '#d9a07a', pose: 'bare' });
    C.contracts.drawActors(a, G.time, drawChar);   // l'otage
    C.home.drawActors(a, G.time, drawChar);   // Luna
    if (home && G.gunsmith) drawChar(a, G.gunsmith.x, G.gunsmith.y, G.gunsmith.aim, { jacket: '#5a4a2a', hair: '#b8b8b8', skin: '#c9926c', style: 'cap', cap: '#ff7a1a', pose: 'gun', gunLen: 11 });
    if (G.comp && !G.comp.inCar) drawComp(a, G.comp, G.time);
    // images rémanentes du Sandevistan (cyan / magenta) et du dash (jaune)
    for (const tr of G.trail) {
      const col = tr.kind === 'dash' ? '#f2d43a' : tr.kind === 'psycho' ? (Math.round(tr.x) % 2 ? '#ff3ec8' : '#b89a22') : (Math.round(tr.x + tr.y) % 2 ? '#3ef0ff' : '#ff3ec8');
      drawChar(a, tr.x, tr.y, tr.aim, { jacket: col, solid: col, pose: tr.kind === 'psycho' ? 'fists' : 'gun', alpha: (tr.t / tr.max) * (tr.kind === 'sandy' ? 0.6 : 0.4), shadow: false });
    }
    for (const e of G.enemies) if (G.ALIVE(e)) drawEnemy(a, e);
    for (const h of G.ghosts) {
      if (Math.random() < 0.25) continue;   // elles clignotent
      drawChar(a, h.x + (Math.random() < 0.2 ? 1 : 0), h.y, h.aim, { jacket: '#ff3ec8', hair: '#120010', skin: '#ff9ad8', gun: true, alpha: 0.75 });
    }
    if ((G.mode === 'play' || G.overReason) && !G.drive) drawPlayer(a, G.player, G);
    a.setTransform(1, 0, 0, 1, 0, 0);

    // éclairage : voile sombre percé autour des néons, du joueur et des tirs
    const l = lm.getContext('2d');
    l.globalCompositeOperation = 'source-over';
    l.clearRect(0, 0, C.W, C.H);
    l.drawImage(lightMask, -sx, -sy);
    l.globalCompositeOperation = 'destination-out';
    const hole = (x, y, r, a) => {
      const gr = l.createRadialGradient(x - sx, y - sy, 0, x - sx, y - sy, r);
      gr.addColorStop(0, `rgba(0,0,0,${a})`); gr.addColorStop(1, 'rgba(0,0,0,0)');
      l.fillStyle = gr; l.fillRect(x - sx - r, y - sy - r, r * 2, r * 2);
    };
    hole(G.player.x, G.player.y, 36, 0.55);
    if (G.drive) {
      // phares : deux trouées de lumière devant la voiture
      const car = G.drive, ca = Math.cos(car.ang), sa = Math.sin(car.ang);
      hole(car.x + ca * 30, car.y + sa * 30, 26, 0.7);
      hole(car.x + ca * 56, car.y + sa * 56, 30, 0.5);
    }
    // phares des voitures qui roulent
    for (const car of G.cars || []) {
      if (!car.ai || car === G.drive || Math.abs(car.speed) < 3) continue;
      if (car.x < sx - 60 || car.x > sx + C.W + 60 || car.y < sy - 60 || car.y > sy + C.H + 60) continue;
      hole(car.x + Math.cos(car.ang) * 26, car.y + Math.sin(car.ang) * 26, 20, 0.5);
    }
    if (G.muzzle > 0) hole(G.muzzleX, G.muzzleY, 60, 0.9);
    for (const e of G.enemies) if (e.muzzle > 0) hole(e.x, e.y, 50, 0.8);
    if (G.comp && G.comp.muzzle > 0) hole(G.comp.x, G.comp.y, 50, 0.8);
    if (!G.cheats.light) g.drawImage(lm, 0, 0);   // triche : vision nocturne
    g.globalCompositeOperation = 'lighter';
    g.drawImage(glow, -sx, -sy);
    if (C.amb.raining() && M.def.outdoor) {
      // sol mouillé : les néons se reflètent en traînées vers le bas
      g.globalAlpha = 0.3; g.drawImage(glow, -sx, -sy + 6);
      g.globalAlpha = 0.15; g.drawImage(glow, -sx, -sy + 14);
      g.globalAlpha = 1;
    }
    if (G.muzzle > 0) {
      const gr = g.createRadialGradient(G.muzzleX - sx, G.muzzleY - sy, 0, G.muzzleX - sx, G.muzzleY - sy, 24);
      gr.addColorStop(0, 'rgba(255,220,120,0.5)'); gr.addColorStop(1, 'rgba(255,220,120,0)');
      g.fillStyle = gr; g.fillRect(G.muzzleX - sx - 24, G.muzzleY - sy - 24, 48, 48);
    }
    g.globalCompositeOperation = 'source-over';
    // les personnages reçoivent la moitié de l'ombre : on distingue leurs silhouettes même dans le noir
    a.globalCompositeOperation = 'source-atop';
    a.globalAlpha = 0.5;
    if (!G.cheats.light) a.drawImage(lm, 0, 0);
    a.globalAlpha = 1;
    a.globalCompositeOperation = 'source-over';
    g.drawImage(ac, 0, 0);

    // éléments lumineux par-dessus l'éclairage : lampes, balles, étincelles, textes
    g.save();
    g.translate(-sx, -sy);
    C.amb.drawLit(g, G.time, sx, sy);   // enseignes, vapeur, flaques, AV
    // décor animé et reflets sur l'eau, seulement ce qui est à l'écran
    const vx0 = Math.floor(sx / 8) - 3, vy0 = Math.floor(sy / 8) - 3, vx1 = vx0 + Math.ceil(C.W / 8) + 6, vy1 = vy0 + Math.ceil(C.H / 8) + 6;
    for (const pr of M.def.props || []) if (pr.x >= vx0 && pr.x <= vx1 && pr.y >= vy0 && pr.y <= vy1) C.decor.drawDynamic(g, pr, G.time);
    if (M.def.outdoor) {
      for (let ty = Math.max(0, vy0); ty < Math.min(M.MH, vy1); ty++) for (let tx = Math.max(0, vx0); tx < Math.min(M.MW, vx1); tx++) {
        if (M.tile(tx, ty) !== 'w') continue;
        const k = Math.sin(G.time * 1.6 + tx * 0.7 + ty * 1.3);
        if (k > 0.7) { g.fillStyle = 'rgba(127,246,255,0.35)'; g.fillRect(tx * 8 + ((tx * 3 + ty) % 5), ty * 8 + 3 + Math.round(k * 2), 3, 1); }
      }
    }
    for (const lt of M.lights) {
      const x = lt.x * 8 + 4, y = lt.y * 8 + 4;
      if (M.def.outdoor && M.tile(lt.x, lt.y) !== 's') continue;   // dans la rue, seuls les lampadaires ont un pied
      g.fillStyle = lt.c; g.fillRect(x - 3, y - 1, 6, 2);
      g.fillStyle = '#ffffff'; g.fillRect(x - 2, y - 1, 4, 1);
    }
    // enseignes au-dessus des portes
    const kk = G.contract;
    for (const d of M.def.doors) {
      const to = C.MAPS[d.to], open = d.metro || to.outdoor || d.to === 'planque' || (kk && kk.site === d.to && !kk.done && !kk.failed);
      if (!M.def.outdoor && C.dist(G.player.x, G.player.y, d.x * 8 + 4, d.y * 8 + 4) > 60) continue;
      T(g, M.def.outdoor ? d.label : 'SORTIE', d.x * 8 + 4, d.y * 8 - (d.y * 8 + 4 < G.player.y ? 7 : -10), open ? d.color : '#6f7c8a', { align: 'center' });
    }
    C.net.drawWorld(g, G.time);   // terminal, caméras, tourelles, quickhacks en cours
    C.ncpd.drawWorld(g, G.time);  // gyrophares
    C.gangs.drawWorld(g, G.time); // piratages des Voodoo Boys
    for (const b of G.bullets) {
      const col = b.team === 0 ? '#fff6b0' : b.team === 1 ? '#ff4d6d' : '#ff3ec8';
      pline(g, b.x - b.vx * 0.02, b.y - b.vy * 0.02, b.x, b.y, shade(col, 0.6));
      pline(g, b.x - b.vx * 0.01, b.y - b.vy * 0.01, b.x, b.y, col);
      g.fillStyle = '#ffffff'; g.fillRect(Math.round(b.x), Math.round(b.y), 1, 1);   // tête de la balle
    }
    // éclairs de tir : une petite étoile au bout du canon
    const flashAt = (x, y, a, col) => {
      const cx = Math.round(x), cy = Math.round(y), fx = Math.round(Math.cos(a) * 2), fy = Math.round(Math.sin(a) * 2);
      g.fillStyle = col; g.fillRect(cx - 1, cy - 1, 3, 3); g.fillRect(cx + fx * 1.5, cy + fy * 1.5, 1, 1);
      g.fillRect(cx - fy, cy + fx, 1, 1); g.fillRect(cx + fy, cy - fx, 1, 1);
      g.fillStyle = '#ffffff'; g.fillRect(cx, cy, 1, 1);
    };
    if (G.muzzle > 0) flashAt(G.player.x + Math.cos(G.player.aim) * 10, G.player.y + Math.sin(G.player.aim) * 10, G.player.aim, '#ffd23e');
    for (const e of G.enemies) if (e.muzzle > 0 && G.ALIVE(e)) flashAt(e.x + Math.cos(e.aim) * 10 * (e.r > 4 ? 1.25 : 1), e.y + Math.sin(e.aim) * 10 * (e.r > 4 ? 1.25 : 1), e.aim, '#ff8a5a');
    if (G.comp && G.comp.muzzle > 0) flashAt(G.comp.x + Math.cos(G.comp.aim) * 10, G.comp.y + Math.sin(G.comp.aim) * 10, G.comp.aim, '#7ff6ff');
    for (const q of G.parts) if (q.kind === 'spark') { g.fillStyle = q.color; g.fillRect(Math.round(q.x), Math.round(q.y), 1, 1); }
    // noms de ceux qui viennent de l'héritage
    const tag = (x, y, txt, col) => T(g, txt, x, y - 13, col, { align: 'center' });
    for (const e of G.enemies) {
      if (e.state === 'dead') continue;
      if (e.state === 'friend') tag(e.x, e.y, e.nom, '#5dff9a');
      else if (e.psycho) tag(e.x, e.y, e.nom + ' · CYBERPSYCHO', '#ff3ec8');
      else if (e.rival && G.ALIVE(e)) tag(e.x, e.y, e.nom + ' · RIVAL', '#ff5a7a');
    }
    if (G.corpse && !G.corpse.taken) tag(G.corpse.x, G.corpse.y - 2, G.corpse.nom, '#b89a22');
    if (home && G.recruit) tag(G.recruit.x, G.recruit.y, G.recruit.nom + ' · ' + G.recruit.lien, '#c7d5e0');
    if (G.dealer) tag(G.dealer.x, G.dealer.y, G.dealer.nom + ' · VOITURES', '#c9a227');
    const own = G.leader && G.leader.car;
    if (own && own.map === M.id && G.drive !== own) tag(own.x, own.y - 4, 'TA ' + C.cars.MODELS[own.model].nom, '#f2d43a');
    if (home && G.doc) tag(G.doc.x, G.doc.y, G.doc.nom + ' · RIPPERDOC', '#d8dde6');
    C.contracts.drawTags(g, G.time, tag);
    C.home.drawTags(g, G.time, tag);   // bulles de dialogue de la planque
    if (home && G.gunsmith) tag(G.gunsmith.x, G.gunsmith.y, G.gunsmith.nom + ' · ARMURIER', '#ff7a1a');
    if (home && G.fixer) tag(G.fixer.x, G.fixer.y, G.fixer.nom + ' · FIXER' + (G.fixer.stars ? ' ' + '*'.repeat(G.fixer.stars) : ''), G.fixer.former ? '#f2d43a' : '#c45cff');
    if (k && k.target && G.ALIVE(k.target)) {
      // la cible du contrat : losange rouge au-dessus de sa tête
      const t = k.target, x = Math.round(t.x), y = Math.round(t.y) - 20;
      g.fillStyle = Math.sin(G.time * 8) > 0 ? '#ff2040' : '#ff8aa0';
      g.fillRect(x, y - 2, 1, 1); g.fillRect(x - 1, y - 1, 3, 1); g.fillRect(x - 2, y, 5, 1); g.fillRect(x - 1, y + 1, 3, 1); g.fillRect(x, y + 2, 1, 1);
      tag(t.x, t.y, t.nom + ' · CIBLE', '#ff2040');
    }
    if (G.mods && G.mods.scan) {
      // optique Kiroshi : PV des ennemis, et regard de ceux qui ne t'ont pas encore vu
      for (const e of G.enemies) {
        if (!G.ALIVE(e)) continue;
        const x = Math.round(e.x) - 5, y = Math.round(e.y) + 6;
        g.fillStyle = '#05050a'; g.fillRect(x - 1, y - 1, 12, 3);
        g.fillStyle = '#ff2040'; g.fillRect(x, y, Math.max(1, Math.round(10 * e.hp / e.maxHp)), 1);
        if (e.state === 'idle') {
          g.fillStyle = 'rgba(255,32,64,0.45)';
          for (const da of [-1.1, 0, 1.1]) for (let r = 8; r < 40; r += 4) g.fillRect(Math.round(e.x + Math.cos(e.aim + da) * r), Math.round(e.y + Math.sin(e.aim + da) * r), 1, 1);
        }
      }
    }
    if (G.comp && G.comp.state === 'up') {
      const c = G.comp, x = Math.round(c.x) - 6, y = Math.round(c.y) - 7;
      tag(c.x, c.y - 3, c.nom, '#3ec8ff');
      g.fillStyle = '#05050a'; g.fillRect(x - 1, y - 1, 14, 3);
      g.fillStyle = '#3ec8ff'; g.fillRect(x, y, Math.round(12 * c.hp / c.maxHp), 1);
    }
    for (const f of G.floats) {
      g.globalAlpha = Math.min(1, f.t * 2);
      T(g, f.text, f.x, f.y, f.color, { align: 'center' });
    }
    g.globalAlpha = 1;
    g.restore();

    // effets plein écran
    if (G.sandy.on) {
      g.fillStyle = 'rgba(30,255,220,0.07)'; g.fillRect(0, 0, C.W, C.H);
      g.fillStyle = 'rgba(255,62,200,0.05)';
      for (let y = (G.time * 60 | 0) % 3; y < C.H; y += 3) g.fillRect(0, y, C.W, 1);
    }
    if (G.flash > 0) { g.fillStyle = `rgba(200,255,255,${G.flash * 1.5})`; g.fillRect(0, 0, C.W, C.H); }
    if (G.redFlash > 0) { g.fillStyle = `rgba(255,20,50,${G.redFlash})`; g.fillRect(0, 0, C.W, C.H); }
    g.drawImage(vignette, 0, 0);
    if (G.fade > 0) { g.fillStyle = `rgba(0,0,0,${Math.min(1, G.fade / 0.35)})`; g.fillRect(0, 0, C.W, C.H); }   // fondu au changement de carte
    if (G.glitchT > 0) {
      // humanité basse : l'image se déchire
      for (let i = 0; i < 4; i++) {
        const y = (Math.random() * C.H) | 0, h = 2 + ((Math.random() * 8) | 0), dx = ((Math.random() - 0.5) * 16) | 0;
        g.drawImage(C.low, 0, y, C.W, h, dx, y, C.W, h);
      }
      g.fillStyle = 'rgba(255,62,200,0.25)'; g.fillRect(0, (Math.random() * C.H) | 0, C.W, 1);
    }

    C.amb.drawScreen(g, G.time, sx, sy);   // pluie
    if (G.mode === 'play') C.net.drawScanTint(g, sx, sy, G.time);
    if (G.mode === 'play') drawHUD(g, G);
    if (G.mode === 'play' && G.shop) drawShop(g, G);
    if (G.mode === 'play' && G.board) drawBoard(g, G);
    if (G.mode === 'play' && G.metroMenu) drawMetro(g, G);
    if (G.mode === 'play' && G.gunMenu) C.arsenal.drawShop(g);
    if (G.mode === 'play' && G.breach) C.net.drawBreach(g, G.time);
    if (G.mode === 'play' && G.cheatMenu) C.cheat.draw(g, G.time);
    if (G.mode === 'play' && G.skillMenu) C.skills.draw(g, G.time);
    if (G.mode === 'play' && G.dealerMenu) drawDealer(g, G);
    if (G.mode === 'play' && G.barMenu) C.home.drawBar(g);
    else drawOver(g, G);
  };
})();
