'use strict';
// Les cartes du quartier. Chaque carte est une grille de tuiles 8x8 construite par build(carve, put).
//
// Tuiles : '#' mur, '.' sol, ',' moquette, 'c' caisse/meuble (bloque balles et déplacements, pas la vue)
//          'D' porte (bloquante, on l'utilise avec E), 'r' route, '=' marquage au sol, 's' trottoir,
//          'B' immeuble (toit vu de dessus), 'p' parking (praticable).
//          Les voitures ne sont pas des tuiles : ce sont des entités (cars.js), listées dans parked.
//
// Une carte définit :
//   w, h            taille en tuiles
//   nom             nom affiché
//   outdoor         true pour la rue : pas de combat, des passants
//   site            true pour un bâtiment où peut se jouer un contrat
//   palette         couleurs du sol
//   doors           [{id, x, y, sx, sy, to, toDoor, label, color}] : (sx, sy) = tuile où l'on arrive devant la porte
//   lights          [{x, y, c, r}] en tuiles
//   enemies         [[type, x, y, {patrol}]] : les « emplacements » d'un bâtiment (l'héritage s'en sert)
//   term, cadre, psycho   positions du terminal (breach protocol), du cadre du grand contrat, du cyberpsycho
//   cams, turrets   caméras (contre un mur) et tourelles du bâtiment (voir netrun.js)
//   npcs            positions des PNJ de la planque
(function () {
  const C = CEL;

  function grid(w, h, fill) {
    const g = [];
    for (let y = 0; y < h; y++) g.push(new Array(w).fill(fill));
    return g;
  }

  const MAPS = (C.MAPS = {});

  // ---------- planque ----------
  MAPS.planque = {
    nom: 'PLANQUE', w: 26, h: 16,
    palette: { floor: '#141826', seam: '#10131e', speck: ['#191e30', '#11141f'], carpet: '#2a1430', carpetDot: '#35193c' },
    build(carve, put) {
      carve(1, 1, 24, 13, '.');
      carve(15, 2, 22, 7, ',');
      for (const [x, y] of [[2, 12], [3, 12], [22, 11], [23, 11], [23, 12], [8, 2], [9, 2]]) put(x, y, 'c');
      for (const x of [5, 6, 7]) put(x, 12, 'c');   // comptoir du bar de Luna
    },
    doors: [{ id: 'sortie', x: 12, y: 14, sx: 12, sy: 13, to: 'rue', toDoor: 'planque', label: 'SORTIE', color: '#3ef0ff' }],
    lights: [{ x: 4, y: 2, c: '#3ef0ff', r: 60 }, { x: 19, y: 2, c: '#ff3ec8', r: 70 }, { x: 12, y: 11, c: '#ffd23e', r: 55 }, { x: 6, y: 12, c: '#ff9ad8', r: 40 }],
    npcs: { doc: [4, 4], fixer: [19, 5], recruit: [8, 9], gunsmith: [20, 11], luna: [6, 13] },
    start: [12, 11],
    enemies: [],
  };

  // ---------- la rue ----------
  const STREET_LIGHT = '#ffcf8a';
  MAPS.rue = {
    nom: 'RUE', w: 96, h: 56, outdoor: true,
    palette: { floor: '#262634', seam: '#1e1e2a', speck: ['#2c2c3c', '#202030'], carpet: '#262634', carpetDot: '#262634' },
    build(carve, put, g) {
      // trottoirs d'abord, puis les chaussées par-dessus (les carrefours restent en chaussée)
      const H = [[12, 16], [34, 38]], V = [[20, 24], [50, 54], [78, 82]];
      for (const [a, b] of H) carve(0, a - 2, 95, b + 2, 's');
      for (const [a, b] of V) carve(a - 2, 0, b + 2, 55, 's');
      for (const [a, b] of H) carve(0, a, 95, b, 'r');
      for (const [a, b] of V) carve(a, 0, b, 55, 'r');
      // marquages au centre des chaussées (pas dans les carrefours)
      const inV = x => V.some(([a, b]) => x >= a && x <= b), inH = y => H.some(([a, b]) => y >= a && y <= b);
      for (const [a, b] of H) { const y = (a + b) / 2; for (let x = 0; x < 96; x++) if (!inV(x) && x % 4 < 2) put(x, y, '='); }
      for (const [a, b] of V) { const x = (a + b) / 2; for (let y = 0; y < 56; y++) if (!inH(y) && y % 4 < 2) put(x, y, '='); }
      // parking du concessionnaire
      carve(60, 19, 72, 24, 'p');
    },
    doors: [
      { id: 'planque', x: 9, y: 19, sx: 9, sy: 18, to: 'planque', toDoor: 'sortie', label: 'PLANQUE', color: '#f2d43a' },
      { id: 'entrepot', x: 37, y: 19, sx: 37, sy: 18, to: 'entrepot', toDoor: 'sortie', label: 'ENTREPÔT', color: '#ffd23e' },
      { id: 'club', x: 66, y: 9, sx: 66, sy: 10, to: 'club', toDoor: 'sortie', label: 'CLUB NÉON', color: '#ff3ec8' },
      { id: 'labo', x: 90, y: 41, sx: 90, sy: 40, to: 'labo', toDoor: 'sortie', label: 'LABO', color: '#3ef0ff' },
    ],
    lights: (() => {
      const L = [];
      for (const y of [10, 18, 32, 40]) for (const x of [6, 32, 44, 62, 70, 90]) L.push({ x, y, c: STREET_LIGHT, r: 44 });
      for (const x of [18, 26, 48, 56, 76, 84]) for (const y of [4, 26, 48]) L.push({ x, y, c: STREET_LIGHT, r: 44 });
      // néons des enseignes devant chaque porte
      L.push({ x: 66, y: 21, c: '#3ef0ff', r: 70 }, { x: 9, y: 18, c: '#f2d43a', r: 50 }, { x: 37, y: 18, c: '#ffd23e', r: 60 }, { x: 66, y: 10, c: '#ff3ec8', r: 70 }, { x: 90, y: 40, c: '#3ef0ff', r: 60 });
      return L;
    })(),
    enemies: [],
    peds: 18,
    npcs: { dealer: [62, 20] },
    lot: { x: 66 * 8 + 4, y: 22 * 8 + 4, ang: -Math.PI / 2 },   // là où apparaît la voiture achetée
    // voitures garées le long des chaussées (positions en pixels, centre de la voiture)
    parked: (() => {
      const P = [];
      const edgeH = { 12: 105, 16: 127, 34: 281, 38: 303 }, edgeV = { 20: 169, 24: 191, 50: 409, 54: 431, 78: 633, 82: 655 };
      for (const [x, y] of [[4, 12], [30, 12], [60, 12], [88, 12], [10, 16], [40, 16], [70, 16], [6, 34], [34, 34], [64, 34], [28, 38], [58, 38], [90, 38]]) P.push({ x: x * 8 + 16, y: edgeH[y], ang: y === 12 || y === 34 ? 0 : Math.PI });
      for (const [x, y] of [[20, 3], [20, 44], [24, 26], [24, 50], [50, 22], [54, 4], [54, 46], [78, 24], [82, 6], [82, 48]]) P.push({ x: edgeV[x], y: y * 8 + 16, ang: x === 20 || x === 50 || x === 78 ? Math.PI / 2 : -Math.PI / 2 });
      return P;
    })(),
  };

  // ---------- l'entrepôt (l'ancienne carte de test ; la planque y est devenue un hall d'entrée) ----------
  MAPS.entrepot = {
    nom: 'ENTREPÔT', w: 56, h: 31, site: true,
    palette: { floor: '#141826', seam: '#10131e', speck: ['#191e30', '#11141f'], carpet: '#2a1430', carpetDot: '#35193c' },
    build(carve, put) {
      carve(1, 1, 14, 9);
      carve(16, 1, 38, 14);
      carve(40, 1, 54, 9);
      carve(1, 16, 20, 29);
      carve(22, 16, 54, 29);
      carve(15, 4, 15, 5); carve(39, 6, 39, 7); carve(30, 15, 31, 15); carve(6, 10, 7, 15); carve(21, 24, 21, 25); carve(47, 10, 48, 15);
      carve(22, 4, 32, 11, ',');
      const crates = [[11, 3], [12, 3], [19, 10], [20, 10], [35, 3], [35, 4], [46, 4], [47, 4], [46, 5], [47, 5],
        [8, 22], [9, 22], [10, 22], [11, 22], [12, 22], [28, 20], [29, 20], [28, 21], [29, 21], [40, 25], [41, 25], [42, 25], [46, 19], [46, 20]];
      for (const [x, y] of crates) put(x, y, 'c');
    },
    doors: [{ id: 'sortie', x: 7, y: 0, sx: 7, sy: 1, to: 'rue', toDoor: 'entrepot', label: 'SORTIE', color: '#ffd23e' }],
    lights: [
      { x: 5, y: 2, c: '#3ef0ff', r: 70 }, { x: 27, y: 2, c: '#ff3ec8', r: 90 }, { x: 27, y: 13, c: '#3ef0ff', r: 80 },
      { x: 52, y: 2, c: '#ffd23e', r: 70 }, { x: 4, y: 27, c: '#ff3ec8', r: 80 }, { x: 25, y: 17, c: '#3ef0ff', r: 70 },
      { x: 51, y: 27, c: '#ff3ec8', r: 80 }, { x: 38, y: 23, c: '#ffd23e', r: 70 },
    ],
    enemies: [
      ['thug', 30, 6, { patrol: [[30, 6], [34, 12]] }], ['thug', 24, 12], ['thug', 45, 3], ['thug', 51, 7, { patrol: [[51, 7], [42, 7]] }],
      ['brute', 40, 22], ['thug', 33, 26], ['thug', 50, 19], ['thug', 10, 25], ['brute', 16, 18],
    ],
    cams: [[16, 1], [54, 16], [1, 16], [40, 9]], turrets: [[53, 8]],   // sécurité (netrun.js)
    term: [52, 4], cadre: [50, 5], psycho: [27, 8],
  };

  // ---------- le club ----------
  MAPS.club = {
    nom: 'CLUB NÉON', w: 50, h: 30, site: true,
    palette: { floor: '#16121f', seam: '#120e19', speck: ['#1d1728', '#130f1a'], carpet: '#3a0f3a', carpetDot: '#5a1a52' },
    build(carve, put) {
      carve(1, 20, 10, 28);    // entrée
      carve(12, 2, 37, 18);    // piste
      carve(12, 22, 37, 28);   // couloir du bas
      carve(40, 2, 48, 12);    // carré VIP
      carve(40, 15, 48, 28);   // arrière-salle
      carve(11, 24, 11, 25); carve(20, 19, 21, 21); carve(30, 19, 31, 21); carve(38, 6, 39, 7); carve(38, 24, 39, 25); carve(44, 13, 45, 14);
      carve(17, 6, 32, 15, ',');   // piste de danse
      for (let y = 4; y <= 12; y++) put(14, y, 'c');   // le bar
      for (const [x, y] of [[42, 4], [43, 4], [46, 20], [46, 21], [42, 26], [43, 26], [3, 22], [3, 23]]) put(x, y, 'c');
    },
    doors: [{ id: 'sortie', x: 5, y: 29, sx: 5, sy: 28, to: 'rue', toDoor: 'club', label: 'SORTIE', color: '#ff3ec8' }],
    lights: [
      { x: 20, y: 4, c: '#ff3ec8', r: 90 }, { x: 30, y: 15, c: '#3ef0ff', r: 90 }, { x: 25, y: 10, c: '#7a5cff', r: 70 },
      { x: 5, y: 22, c: '#3ef0ff', r: 60 }, { x: 44, y: 4, c: '#ff2040', r: 60 }, { x: 44, y: 26, c: '#ff3ec8', r: 60 }, { x: 24, y: 25, c: '#3ef0ff', r: 60 },
    ],
    enemies: [
      ['thug', 20, 8], ['thug', 28, 12], ['thug', 33, 5, { patrol: [[33, 5], [33, 16]] }], ['brute', 25, 10], ['thug', 18, 16],
      ['thug', 16, 25, { patrol: [[16, 25], [34, 25]] }], ['thug', 46, 8], ['brute', 44, 22], ['thug', 41, 18],
    ],
    cams: [[12, 2], [37, 18], [40, 15]], turrets: [[41, 11]],   // sécurité (netrun.js)
    term: [47, 3], cadre: [45, 7], psycho: [25, 12],
  };

  // ---------- le labo ----------
  MAPS.labo = {
    nom: 'LABO', w: 52, h: 32, site: true,
    palette: { floor: '#1a1f26', seam: '#222a33', speck: ['#1f252e', '#171b21'], carpet: '#16303a', carpetDot: '#1d3d4a' },
    build(carve, put) {
      carve(1, 1, 12, 8);      // accueil
      carve(1, 10, 50, 12);    // couloir
      carve(14, 1, 24, 8); carve(26, 1, 36, 8); carve(38, 1, 50, 8);   // labos du nord
      carve(1, 14, 24, 30);    // grand labo
      carve(26, 14, 50, 30);   // salle des serveurs
      carve(5, 9, 6, 9); carve(19, 9, 20, 9); carve(31, 9, 32, 9); carve(44, 9, 45, 9); carve(10, 13, 11, 13); carve(37, 13, 38, 13);
      const bench = (x0, x1, y) => { for (let x = x0; x <= x1; x++) put(x, y, 'c'); };
      bench(17, 21, 4); bench(29, 33, 4); bench(41, 47, 5);
      bench(4, 10, 18); bench(14, 20, 18); bench(4, 10, 24); bench(14, 20, 24);
      for (const x of [30, 34, 42]) for (let y = 17; y <= 25; y++) put(x, y, 'c');   // baies de serveurs
    },
    doors: [{ id: 'sortie', x: 6, y: 0, sx: 6, sy: 1, to: 'rue', toDoor: 'labo', label: 'SORTIE', color: '#3ef0ff' }],
    lights: [
      { x: 6, y: 3, c: '#bfe9ff', r: 60 }, { x: 19, y: 3, c: '#bfe9ff', r: 60 }, { x: 31, y: 3, c: '#3ef0ff', r: 60 }, { x: 44, y: 3, c: '#bfe9ff', r: 60 },
      { x: 25, y: 11, c: '#3ef0ff', r: 70 }, { x: 12, y: 21, c: '#bfe9ff', r: 80 }, { x: 38, y: 22, c: '#3ef0ff', r: 90 }, { x: 47, y: 28, c: '#5dff9a', r: 50 },
    ],
    enemies: [
      ['thug', 25, 11, { patrol: [[15, 11], [45, 11]] }], ['thug', 16, 6], ['brute', 35, 6], ['thug', 48, 3],
      ['thug', 8, 21], ['thug', 18, 27], ['thug', 38, 20], ['brute', 44, 28], ['thug', 28, 28],
    ],
    cams: [[1, 10], [50, 12], [24, 14], [38, 1]], turrets: [[26, 30], [50, 15]],   // sécurité (netrun.js)
    term: [48, 29], cadre: [40, 27], psycho: [12, 21],
  };

  // Construit la grille d'une carte (appelé à chaque chargement : les caisses ne bougent pas, mais c'est simple et sûr).
  C.buildMap = function (def) {
    const g = grid(def.w, def.h, def.outdoor ? 'B' : '#');
    const carve = (x0, y0, x1, y1, ch = '.') => {
      for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) g[y][x] = ch;
    };
    const put = (x, y, ch) => { g[y][x] = ch; };
    def.build(carve, put, g);
    for (const d of def.doors) g[d.y][d.x] = 'D';
    return g;
  };
})();
