'use strict';
// Musique et radio : tout est synthétisé en direct (WebAudio), comme les bruitages. Aucun fichier audio.
//
// Un morceau = un tempo, une gamme, une grille d'accords (4 mesures) et des motifs sur 16 pas :
// basse, arpège, nappe, grosse caisse, caisse claire, charleston. Une couche « combat » (batterie et basse en plus)
// monte quand ça se bat. Un séquenceur prévoit les notes un peu à l'avance (horloge audio, pas celle du jeu).
// Le morceau suit l'endroit : écran titre, planque, bâtiments, chaque quartier, le métro ; au volant, c'est la radio
// (R pour changer de station) et l'animateur commente ce que tu fais. M coupe ou remet la musique.
(function () {
  const C = CEL;
  const MU = (C.music = {});
  const G = () => C.game;
  const midiF = m => 440 * Math.pow(2, (m - 69) / 12);
  const MINOR = [0, 2, 3, 5, 7, 8, 10], DORIAN = [0, 2, 3, 5, 7, 9, 10], PHRYG = [0, 1, 3, 5, 7, 8, 10], INSEN = [0, 1, 5, 7, 10];

  // ---------- les morceaux ----------
  // prog : degrés de la gamme (un accord par mesure) ; motifs : 'x' = coup, '.' = silence ;
  // arp : indices dans l'accord (0, 1, 2 = notes de l'accord, 3 = fondamentale à l'octave), joués tous les arpEvery pas.
  const T = {
    title: { bpm: 70, root: 45, scale: MINOR, prog: [0, 5, 2, 6], pad: 0.09, arp: [0, 1, 2, 3, 2, 1], arpEvery: 4, arpVol: 0.05, arpWave: 'triangle' },
    planque: { bpm: 80, root: 50, scale: DORIAN, prog: [0, 3, 0, 4], pad: 0.07, bass: 'x.......x.....x.', bassVol: 0.12,
      kick: 'x......x..x.....', snare: '....x.......x...', hat: '..x...x...x...x.', drumVol: 0.45, arp: [0, 2, 1, 3], arpEvery: 4, arpVol: 0.04, arpWave: 'sine' },
    rue: { bpm: 104, root: 45, scale: MINOR, prog: [0, 5, 3, 4], pad: 0.05, bass: 'x.xxx.xxx.xxx.xx', bassVol: 0.13,
      arp: [0, 2, 1, 2, 0, 2, 1, 3], arpEvery: 1, arpVol: 0.035, arpWave: 'square',
      kick: 'x...x...x...x...', snare: '....x.......x...', hat: '..x...x...x...x.', drumVol: 0.7,
      combat: { kick: 'x.x.x.x.x.x.x.x.', snare: '....x..x....x.xx', bass: 'xxxxxxxxxxxxxxxx' } },
    japantown: { bpm: 92, root: 50, scale: INSEN, prog: [0, 2, 3, 1], pad: 0.06, bass: 'x.....x...x.....', bassVol: 0.1,
      arp: [0, 1, 2, 3, 2, 1, 0, 1], arpEvery: 2, arpVol: 0.05, arpWave: 'triangle', echo: true,
      kick: 'x.....x...x.....', snare: '........x.......', hat: 'x.x.x.x.x.x.x.x.', drumVol: 0.5,
      combat: { kick: 'x...x.x.x...x.x.', snare: '....x.......x...', bass: 'x.x.x.x.x.x.x.x.' } },
    centre: { bpm: 118, root: 40, scale: MINOR, prog: [0, 0, 5, 6], pad: 0.035, bass: 'x..x..x.x..x..x.', bassVol: 0.13,
      arp: [3, 3, 2, 3], arpEvery: 4, arpOffset: 2, arpVol: 0.04, arpWave: 'square',
      kick: 'x...x...x...x...', snare: '....x.......x...', hat: '..x...x...x...x.', drumVol: 0.75,
      combat: { kick: 'x...x...x...x.x.', snare: '..x...x...x...x.', bass: 'x.xxx.xxx.xxx.xx' } },
    pacifica: { bpm: 84, root: 38, scale: PHRYG, prog: [0, 1, 0, 6], pad: 0.06, padLow: true, bass: 'x.....x.x.......', bassVol: 0.15, dist: true,
      kick: 'x.......x..x....', snare: '....x.......x..x', hat: '......x.......x.', drumVol: 0.65,
      arp: [0, 1], arpEvery: 8, arpVol: 0.03, arpWave: 'sawtooth',
      combat: { kick: 'x..x..x.x..x..x.', snare: '....x.......xx.x', bass: 'x.x.x.xxx.x.x.xx' } },
    site: { bpm: 124, root: 41, scale: MINOR, prog: [0, 0, 1, 0], pad: 0.05, bass: 'x.x.x.x.x.x.x.x.', bassVol: 0.12,
      hat: 'x.x.x.x.x.x.x.x.', kick: 'x.......x.......', drumVol: 0.55, arp: [0, 3], arpEvery: 8, arpVol: 0.03, arpWave: 'square',
      combat: { kick: 'x...x...x...x...', snare: '....x.......x...', bass: 'xxxxxxxxxxxxxxxx', hat: 'xxxxxxxxxxxxxxxx' } },
    ride: { bpm: 70, root: 43, scale: DORIAN, prog: [0, 4, 3, 0], pad: 0.08, arp: [0, 1, 2, 1], arpEvery: 4, arpVol: 0.04, arpWave: 'sine', hat: '....x.......x...', drumVol: 0.3 },
  };
  MU.TRACKS = T;
  // Stations de radio (au volant) : un morceau et un style d'animateur.
  MU.STATIONS = [
    { nom: 'RADIO KABUKI 88.1', track: 'rue', dj: 'MAX NEON' },
    { nom: 'NEO-SHAMAN FM 95.3', track: 'pacifica', dj: 'MAMA LOA' },
    { nom: 'PACIFIC DREAMS 102.7', track: 'japantown', dj: 'SAKURA-CHAN' },
    { nom: 'CORPO BEATS 107.7', track: 'centre', dj: 'DJ SYNERGIE' },
  ];

  // ---------- instruments ----------
  let A = null, out = null, bus = null, cbus = null, curId = null, step = 0, next = 0, timer = null, intensity = 0;
  const on = () => { try { return localStorage.getItem('cel-music') !== '0'; } catch (e) { return true; } };
  MU.enabled = on();
  function env(g, t, a, peak, dur) { g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(peak, t + a); g.gain.exponentialRampToValueAtTime(0.0001, t + dur); }
  function osc(type, f, t, dur, vol, dest, filt) {
    const o = A.ac.createOscillator(), g = A.ac.createGain();
    o.type = type; o.frequency.setValueAtTime(f, t);
    let node = o;
    if (filt) { const fl = A.ac.createBiquadFilter(); fl.type = 'lowpass'; fl.frequency.setValueAtTime(filt, t); o.connect(fl); node = fl; }
    node.connect(g); g.connect(dest);
    env(g, t, 0.005, vol, dur);
    o.start(t); o.stop(t + dur + 0.05);
    return o;
  }
  function noise(t, dur, vol, type, freq, dest) {
    const s = A.ac.createBufferSource(), f = A.ac.createBiquadFilter(), g = A.ac.createGain();
    s.buffer = A.noise; f.type = type; f.frequency.value = freq;
    s.connect(f); f.connect(g); g.connect(dest);
    env(g, t, 0.002, vol, dur);
    s.start(t, Math.random() * 0.5); s.stop(t + dur + 0.05);
  }
  const kick = (t, v, d) => { const o = osc('sine', 140, t, 0.3, 0.9 * v, d); o.frequency.exponentialRampToValueAtTime(42, t + 0.12); };
  const snare = (t, v, d) => { noise(t, 0.16, 0.45 * v, 'bandpass', 1800, d); osc('triangle', 200, t, 0.1, 0.25 * v, d); };
  const hat = (t, v, d) => noise(t, 0.04, 0.18 * v, 'highpass', 7000, d);
  function bassNote(t, m, dur, v, tr, d) {
    osc('sawtooth', midiF(m), t, dur, v, d, tr.dist ? 1400 : 520);
    if (tr.dist) osc('square', midiF(m) * 1.005, t, dur, v * 0.5, d, 900);
  }
  function padChord(t, ms, dur, v, d) {
    for (const m of ms) for (const det of [-6, 6]) {
      const o = A.ac.createOscillator(), f = A.ac.createBiquadFilter(), g = A.ac.createGain();
      o.type = 'sawtooth'; o.frequency.value = midiF(m); o.detune.value = det;
      f.type = 'lowpass'; f.frequency.value = 900;
      o.connect(f); f.connect(g); g.connect(d);
      g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(v, t + dur * 0.3); g.gain.linearRampToValueAtTime(0.0001, t + dur);
      o.start(t); o.stop(t + dur + 0.05);
    }
  }
  // note de la gamme : degré d (peut dépasser la gamme : on monte d'octave)
  const deg = (tr, d) => tr.root + tr.scale[((d % tr.scale.length) + tr.scale.length) % tr.scale.length] + 12 * Math.floor(d / tr.scale.length);
  const chord = (tr, d) => [deg(tr, d), deg(tr, d + 2), deg(tr, d + 4), deg(tr, d) + 12];

  // ---------- séquenceur ----------
  function play(tr, i, t) {
    const sp = 60 / tr.bpm / 4, bar = Math.floor(i / 16) % tr.prog.length, s = i % 16, ch = chord(tr, tr.prog[bar]);
    const hit = (pat, k) => pat && pat[k % pat.length] === 'x';
    const dv = tr.drumVol || 0.6;
    if (hit(tr.kick, s)) kick(t, dv, bus);
    if (hit(tr.snare, s)) snare(t, dv, bus);
    if (hit(tr.hat, s)) hat(t, dv * (s % 4 === 2 ? 1 : 0.6), bus);
    if (hit(tr.bass, s)) bassNote(t, ch[0] - 12, sp * 1.6, tr.bassVol || 0.1, tr, bus);
    if (tr.pad && s === 0) padChord(t, tr.padLow ? ch.slice(0, 3).map(m => m - 12) : ch.slice(0, 3), sp * 16, tr.pad, bus);
    if (tr.arp && (s - (tr.arpOffset || 0)) % tr.arpEvery === 0 && s >= (tr.arpOffset || 0)) {
      const k = Math.floor(s / tr.arpEvery) % tr.arp.length, m = ch[tr.arp[k]] + 12;
      osc(tr.arpWave || 'square', midiF(m), t, sp * tr.arpEvery * 0.9, tr.arpVol || 0.04, bus, 2600);
      if (tr.echo) osc(tr.arpWave || 'square', midiF(m), t + sp * 3, sp * tr.arpEvery * 0.8, (tr.arpVol || 0.04) * 0.4, bus, 1800);
    }
    // couche combat
    const cb = tr.combat;
    if (cb && intensity > 0.05) {
      if (hit(cb.kick, s)) kick(t, 0.9, cbus);
      if (hit(cb.snare, s)) snare(t, 0.8, cbus);
      if (hit(cb.hat, s)) hat(t, 0.7, cbus);
      if (hit(cb.bass, s)) bassNote(t, ch[0], sp * 0.9, 0.08, { dist: true }, cbus);
    }
  }
  function tick() {
    if (!A || !curId || !bus) return;
    const tr = T[curId], sp = 60 / tr.bpm / 4;
    while (next < A.ac.currentTime + 0.15) { try { play(tr, step, next); } catch (e) { /* note ignorée */ } step++; next += sp; }
  }
  // Change de morceau en fondu (l'ancien s'éteint en 1,5 s, le nouveau monte).
  function switchTo(id) {
    if (id === curId) return;
    curId = id;
    if (!A) return;
    const t = A.ac.currentTime;
    if (bus) { const ob = bus, oc = cbus; ob.gain.setTargetAtTime(0, t, 0.5); oc.gain.setTargetAtTime(0, t, 0.3); setTimeout(() => { try { ob.disconnect(); oc.disconnect(); } catch (e) {} }, 3000); }
    if (!id) { bus = cbus = null; return; }
    bus = A.ac.createGain(); cbus = A.ac.createGain();
    bus.gain.value = 0; cbus.gain.value = 0;
    bus.connect(out); cbus.connect(out);
    bus.gain.setTargetAtTime(1, t, 0.6);
    step = 0; next = t + 0.1;
  }
  function ensure() {
    if (A || !C.audio()) return !!A;
    A = C.audio();
    out = A.ac.createGain(); out.gain.value = MU.enabled ? 1.2 : 0; out.connect(A.master);
    timer = setInterval(tick, 25);
    const id = curId; curId = null; switchTo(id);
    return true;
  }

  // ---------- radio ----------
  let station = 0, djMsg = null, djT = 20, events = [], stationShow = 0;
  const LINES = {
    intro: ['ICI {dj} SUR {radio}. NIGHT CITY NE DORT JAMAIS, ET TOI NON PLUS.', 'BIENVENUE SUR {radio}. ACCROCHEZ VOS IMPLANTS.', '{dj} AU MICRO. ROULEZ VITE, MOUREZ PLUS TARD.'],
    contract: ['ON ME SIGNALE UN JOB PROPRE CHEZ {faction}. LE GENRE DE TRAVAIL QUI FAIT UNE LÉGENDE.', 'ENCORE UN CONTRAT BOUCLÉ PAR {nom}. LES FIXERS ADORENT.'],
    fail: ['UN CONTRAT QUI TOURNE MAL À {quartier}. ÇA ARRIVE AUX MEILLEURS.', 'DES RUMEURS DISENT QUE {nom} S\'EST PLANTÉ. ON EN REPARLE.'],
    stars: ['LE NCPD CHERCHE UN SOLO À {quartier}. SI C\'EST TOI : ROULE.', 'ALERTE ROUGE À {quartier}. LES FLICS SONT NERVEUX CE SOIR.', 'LE NCPD A SORTI LES AV. QUELQU\'UN A FAIT UNE BÊTISE.'],
    maxtac: ['MAXTAC EST DE SORTIE. JE RÉPÈTE : MAXTAC. QUE LES DIEUX DU CHROME TE GARDENT.'],
    gang: ['LES {gang} ONT UN NOUVEL ENNEMI. JE NE VOUDRAIS PAS ÊTRE DANS SES BASKETS.', 'GUERRE DE TERRITOIRE : LES {gang} SONT FURIEUX.'],
    gib: ['ON A RETROUVÉ DES MORCEAUX DE GANGER À {quartier}. LITTÉRALEMENT.', 'LES NETTOYEURS DE RUE FONT DES HEURES SUP CE SOIR.'],
    carjack: ['UNE VOITURE VOLÉE À {quartier}. SI VOUS LA VOYEZ : NE DITES RIEN.', 'VOL DE VOITURE EN PLEINE RUE. CLASSIQUE.'],
    level: ['{nom} PREND DU GALON, PARAÎT-IL. LA RUE EN PARLE.'],
    news: ['MÉTÉO : PLUIE ACIDE PRÉVUE. GARDEZ VOS PARAPLUIES.', 'ARASAKA DÉMENT TOUT. COMME D\'HABITUDE.', 'MILITECH RECRUTE. MILITECH RECRUTE TOUJOURS.', 'KANG TAO SORT UN NOUVEAU PISTOLET SMART. LES BALLES VOUS AIMENT.', 'LE MÉTRO NCART EST EN RETARD. RIEN DE NOUVEAU.', 'À PACIFICA, LES VOODOO BOYS ÉCOUTENT. TOUJOURS.', 'BRAINDANCE DE LA SEMAINE : NE LE REGARDEZ PAS.'],
  };
  const fill = s => {
    const g = G(), L0 = g.leader, k = g.contract, st = MU.STATIONS[station], map = C.map.def || {};
    const gangId = C.gangs && C.gangs.gangOf(C.map.id);
    return s.replace('{dj}', st.dj).replace('{radio}', st.nom).replace('{nom}', L0 ? L0.nom : 'QUELQU\'UN')
      .replace('{quartier}', map.quartier || 'NIGHT CITY').replace('{faction}', k ? C.DEF.factions[k.faction].nom : 'UNE CORPO')
      .replace('{gang}', gangId ? C.DEF.gangs[gangId].nom : (events.find(e => e.gang) || {}).gang || 'GANGS');
  };
  const pickLine = kind => fill(LINES[kind][(Math.random() * LINES[kind].length) | 0]);
  // Le jeu signale un évènement ; l'animateur en parlera la prochaine fois qu'il prend le micro.
  MU.event = function (kind, data) {
    events.push(Object.assign({ kind, t: G().time || 0 }, data || {}));
    if (events.length > 6) events.shift();
    if (G().drive && djT > 4) djT = 2 + Math.random() * 2;   // au volant, il réagit vite
  };
  function speak(text) { djMsg = { text, t: 7 }; C.sfx('radio'); }
  MU.nextStation = function () { station = (station + 1) % MU.STATIONS.length; stationShow = 3; djT = 1.5; C.sfx('radio'); speak(pickLine('intro')); };

  // ---------- quel morceau ? ----------
  MU.want = function () {
    const g = G(), M = C.map;
    if (!g || g.mode === 'title' || g.mode === 'create') return 'title';
    if (g.mode === 'over') return null;
    if (g.ride) return 'ride';
    if (g.drive) return MU.STATIONS[station].track;
    if (M.id === 'planque') return 'planque';
    if (M.def && M.def.site) return 'site';
    return T[M.id] ? M.id : 'rue';
  };
  let wasDriving = false;
  MU.update = function (dt) {
    const g = G();
    if (C.keyHit('KeyM')) { MU.toggle(); }
    if (!ensure()) { curId = MU.want(); return; }
    switchTo(MU.want());
    // intensité du combat : ennemis en alerte, flics qui te voient
    const fight = g.enemies && g.mode === 'play' && (g.enemies.some(e => g.ALIVE(e) && e.state === 'alert' && !e.neutral) || (g.wanted && g.wanted.seen));
    intensity += ((fight ? 1 : 0) - intensity) * Math.min(1, dt * (fight ? 3 : 0.6));
    if (cbus) cbus.gain.setTargetAtTime(intensity, A.ac.currentTime, 0.2);
    // radio
    stationShow -= dt;
    if (djMsg) { djMsg.t -= dt; if (djMsg.t <= 0) djMsg = null; }
    if (g.drive && !wasDriving) { stationShow = 3; djT = Math.min(djT, 2.5); }
    wasDriving = !!g.drive;
    if (g.drive && g.mode === 'play') {
      djT -= dt;
      if (djT <= 0) {
        djT = 30 + Math.random() * 25;
        const ev = events.pop();
        speak(ev ? pickLine(LINES[ev.kind] ? ev.kind : 'news') : Math.random() < 0.3 ? pickLine('intro') : pickLine('news'));
      }
    }
  };
  MU.toggle = function () {
    MU.enabled = !MU.enabled;
    try { localStorage.setItem('cel-music', MU.enabled ? '1' : '0'); } catch (e) {}
    if (out) out.gain.setTargetAtTime(MU.enabled ? 1.2 : 0, A.ac.currentTime, 0.2);
    MU.toastT = 2;
  };
  MU.state = () => ({ track: curId, station: MU.STATIONS[station].nom, dj: djMsg && djMsg.text, enabled: MU.enabled, intensity: Math.round(intensity * 100) / 100, events: events.length });

  // ---------- HUD ----------
  MU.drawHUD = function (g) {
    const gm = G(), Tx = (s, x, y, c, o = {}) => C.text(g, s, x, y, c, Object.assign({ shadow: '#05050a' }, o));
    MU.toastT = (MU.toastT || 0) - C.STEP;
    if (MU.toastT > 0) Tx(MU.enabled ? 'MUSIQUE : OUI' : 'MUSIQUE : NON', C.W - 4, C.H - 10, '#8f98a0', { align: 'right' });
    if (!gm.drive) return;
    if (stationShow > 0 || djMsg) Tx(C.keyLabel('KeyR') + ' · ' + MU.STATIONS[station].nom, 4, C.H - 38, '#ff3ec8');
    if (djMsg) {
      // sous-titre de l'animateur, coupé en lignes de 70 caractères
      const words = djMsg.text.split(' '), lines = [''];
      for (const w of words) { if ((lines[lines.length - 1] + ' ' + w).length > Math.floor((C.W - 12) / 4)) lines.push(w); else lines[lines.length - 1] = (lines[lines.length - 1] + ' ' + w).trim(); }
      const y0 = 70;
      g.fillStyle = 'rgba(5,5,10,0.6)'; g.fillRect(0, y0 - 3, C.W, lines.length * 7 + 11);
      Tx(MU.STATIONS[station].dj + ' :', 6, y0, '#ff3ec8');
      lines.forEach((l, i) => Tx(l, 6, y0 + 8 + i * 7, '#ffffff'));
    }
  };
})();
