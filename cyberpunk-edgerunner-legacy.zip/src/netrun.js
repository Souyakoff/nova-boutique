'use strict';
// Netrunning : RAM du cyberdeck, scan (TAB), quickhacks, caméras et tourelles des bâtiments, breach protocol.
//
// Chaque bâtiment a sa sécurité (G.net, gardée avec le bâtiment pendant le gig) :
//   cams     caméras fixées au mur qui balaient un cône ; si elles te voient assez longtemps : alarme
//   turrets  tourelles : se réveillent si elles te voient ou à l'alarme ; peuvent être retournées contre les ennemis
//   term     le terminal du bâtiment : point d'accès au réseau (breach protocol)
// TAB maintenu = scan : le monde ralentit, on vise une cible à la souris et on envoie un quickhack (touches 1 à 5 ou clic).
// L'envoi prend un peu de temps et coûte de la RAM, qui se recharge toute seule.
(function () {
  const C = CEL, D = C.DEF, M = C.map;
  const N = (C.net = {});
  const G = () => C.game;
  const QH = D.quickhacks, CAM = D.camera, TUR = D.turret;

  // ---------- mise en place ----------
  // Une caméra regarde à l'opposé du mur auquel elle est fixée.
  function wallFacing(tx, ty) {
    let ax = 0, ay = 0;
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) if (M.solid(tx + dx, ty + dy)) { ax -= dx; ay -= dy; }
    return ax || ay ? Math.atan2(ay, ax) : 0;
  }
  N.spawn = function (def) {
    return {
      alarm: false,
      cams: (def.cams || []).map(([x, y], i) => ({ x: x * 8 + 4, y: y * 8 + 4, base: wallFacing(x, y), ang: 0, t: i * 1.7, on: true, dead: false, hp: CAM.hp, sus: 0 })),
      turrets: (def.turrets || []).map(([x, y]) => ({ x: x * 8 + 4, y: y * 8 + 4, aim: wallFacing(x, y), on: true, dead: false, ally: false, active: false, sus: 0, hp: TUR.hp, maxHp: TUR.hp, fireCd: 0, muzzle: 0 })),
      term: def.term ? { x: def.term[0] * 8 + 4, y: def.term[1] * 8 + 4, used: false } : null,
    };
  };

  // L'alarme réveille les ennemis autour et les tourelles du bâtiment.
  function alarm(x, y) {
    const g = G(), net = g.net;
    if (!net || net.alarm) return;
    net.alarm = true;
    g.fx.addFloat(x, y - 10, 'ALARME !', '#ff2040');
    C.sfx('alarm');
    for (const e of g.enemies) if (e.state === 'idle' && C.dist(e.x, e.y, x, y) < CAM.alarmRadius) g.fx.alertEnemy(e, false);
    for (const t of net.turrets) if (t.on && !t.ally) t.active = true;
  }
  N.alarm = alarm;

  // ---------- cibles du scan ----------
  // Ce qu'on peut pirater : à portée et en vue du joueur.
  N.targets = function () {
    const g = G(), p = g.player, out = [], R = D.net.range;
    const ok = (x, y) => C.dist(p.x, p.y, x, y) < R && M.los(p.x, p.y, x, y);
    for (const e of g.enemies) if (g.ALIVE(e) && ok(e.x, e.y)) out.push({ kind: 'enemy', ref: e, x: e.x, y: e.y });
    if (M.def.outdoor) for (const q of g.peds) if (!q.dead && ok(q.x, q.y)) out.push({ kind: 'civil', ref: q, x: q.x, y: q.y });
    if (g.net) {
      for (const c of g.net.cams) if (!c.dead && ok(c.x, c.y)) out.push({ kind: 'camera', ref: c, x: c.x, y: c.y });
      for (const t of g.net.turrets) if (!t.dead && ok(t.x, t.y)) out.push({ kind: 'turret', ref: t, x: t.x, y: t.y });
    }
    return out;
  };
  N.hacksFor = kind => Object.keys(QH).filter(id => QH[id].on === (kind === 'civil' ? 'enemy' : kind));   // un civil se pirate comme un ennemi
  // Peut-on lancer ce quickhack sur cette cible ? renvoie null si oui, sinon la raison.
  N.why = function (tg, id) {
    const g = G(), h = QH[id], r = tg.ref;
    if (h.tier > g.mods.tier) return 'DECK MK.' + h.tier;
    if (g.uploads.some(u => u.tgt.ref === r)) return 'ENVOI EN COURS';
    if (id === 'distraction' && tg.kind === 'enemy' && r.state !== 'idle') return 'DÉJÀ EN ALERTE';
    if ((tg.kind === 'camera' || tg.kind === 'turret') && !r.on) return 'ÉTEINTE';
    if (id === 'turAlly' && r.ally) return 'DÉJÀ À TOI';
    if (g.ram < h.ram) return 'RAM';
    return null;
  };
  const nameOf = tg => (tg.kind === 'enemy' ? tg.ref.nom : tg.kind === 'civil' ? 'CIVIL' : tg.kind === 'camera' ? 'CAMÉRA' : 'TOURELLE');
  N.nameOf = nameOf;

  // Pendant le scan : la cible la plus proche du curseur, et les touches 1 à 5 / le clic pour envoyer.
  N.scan = function () {
    const g = G(), I = C.input;
    g.scanT = null;
    if (!g.scanOn) return;
    const wx = g.cam.x + I.mx, wy = g.cam.y + I.my;
    let best = null, bd = 18;
    for (const t of N.targets()) { const d = C.dist(wx, wy, t.x, t.y); if (d < bd) { bd = d; best = t; } }
    g.scanT = best;
    if (!best) return;
    const ids = N.hacksFor(best.kind);
    let pick = -1;
    for (let i = 0; i < ids.length; i++) if (C.keyHit('Digit' + (i + 1)) || C.keyHit('Numpad' + (i + 1))) pick = i;
    const row = N.panelRowUnderMouse();
    if (I.mhit[0] && row >= 0) pick = row;
    if (pick < 0) return;
    const id = ids[pick], why = N.why(best, id);
    if (why) { C.sfx('empty'); g.fx.addFloat(best.x, best.y - 14, why, '#8f98a0'); return; }
    g.ram -= QH[id].ram;
    g.uploads.push({ tgt: best, id, t: 0, dur: QH[id].up * g.mods.upload });
    C.sfx('upload');
  };

  // ---------- effets des quickhacks ----------
  function apply(u) {
    const g = G(), h = QH[u.id], r = u.tgt.ref, fx = g.fx, p = g.player;
    const ang = Math.atan2(r.y - p.y, r.x - p.x);
    if (u.tgt.kind === 'civil') {
      // un passant : les dégâts passent par le NCPD (témoins, étoiles)
      const P = C.ncpd;
      if (u.id === 'distraction') { const s = M.randomFloorNear(r.x, r.y, 24, 60); if (s) { r.tx = s[0]; r.ty = s[1]; r.wait = 0; } }
      else if (u.id === 'aveugle') r.blindT = h.dur;
      else if (u.id === 'surchauffe') { r.burnT = h.dur; r.burnAcc = 0; P.panic(r.x, r.y, 80); }
      else { fx.sparks(r.x, r.y, u.id === 'synapse' ? '#ff3ec8' : '#7ff6ff', 12); P.hitPed(r, h.dmg, ang); }
      C.sfx('hack');
      return;
    }
    switch (u.id) {
      case 'distraction': {
        const spot = M.randomFloorNear(r.x, r.y, 24, 60);
        if (spot) { r.distract = spot; r.distractT = h.dur; }
        fx.addFloat(r.x, r.y - 12, '?', '#d4f542');
        break;
      }
      case 'aveugle': r.blindT = h.dur; fx.addFloat(r.x, r.y - 12, 'OPTIQUE HS', '#d4f542'); break;
      case 'court': fx.sparks(r.x, r.y, '#7ff6ff', 12); r.stun = h.stun; fx.hitEnemy(r, h.dmg, ang); contagion(r, u.id); break;
      case 'surchauffe': r.burnT = h.dur; r.burnAcc = 0; fx.alertEnemy(r); contagion(r, u.id); break;
      case 'synapse': fx.sparks(r.x, r.y, '#ff3ec8', 18); G().flash = 0.1; fx.hitEnemy(r, h.dmg, ang); break;
      case 'camOff': r.on = false; r.sus = 0; break;
      case 'camMark': g.revealT = Math.max(g.revealT, h.dur); break;
      case 'turOff': r.on = false; r.active = false; break;
      case 'turAlly': r.ally = true; r.active = true; fx.addFloat(r.x, r.y - 12, 'TOURELLE À TOI', '#3ef0ff'); break;
    }
    C.sfx('hack');
    C.skills.gain(3);
    C.home.note('hacks');
  }
  // Compétence « contagion » : le quickhack saute sur l'ennemi le plus proche (70 px).
  function contagion(r, id) {
    const g = G();
    if (!g.mods.contagion) return;
    let best = null, bd = 70;
    for (const e of g.enemies) if (e !== r && g.ALIVE(e)) { const d = C.dist(e.x, e.y, r.x, r.y); if (d < bd) { bd = d; best = e; } }
    if (!best) return;
    // un arc électrique entre les deux
    for (let i = 0; i <= 8; i++) g.fx.part(r.x + (best.x - r.x) * i / 8 + (Math.random() - 0.5) * 4, r.y + (best.y - r.y) * i / 8 + (Math.random() - 0.5) * 4, 0, 0, 0.25, '#d4f542', 'spark');
    if (id === 'court') { best.stun = QH.court.stun; g.fx.hitEnemy(best, QH.court.dmg, Math.atan2(best.y - r.y, best.x - r.x)); }
    else { best.burnT = QH.surchauffe.dur; best.burnAcc = 0; g.fx.alertEnemy(best); }
  }
  const valid = u => {
    const r = u.tgt.ref;
    return u.tgt.kind === 'enemy' ? G().ALIVE(r) : u.tgt.kind === 'civil' ? !r.dead : !r.dead && (r.on || u.id === 'camMark');
  };

  // ---------- mise à jour (dt : temps réel, wdt : temps du monde, ralenti par le Sandevistan ou le scan) ----------
  N.update = function (dt, wdt) {
    const g = G(), fx = g.fx;
    g.ram = Math.min(g.mods.ramMax, g.ram + g.mods.ramRegen * dt);
    for (const u of g.uploads) {
      if (!valid(u)) { u.dead = true; continue; }
      u.tgt.x = u.tgt.ref.x; u.tgt.y = u.tgt.ref.y;
      u.t += dt;
      if (u.t >= u.dur) { u.dead = true; apply(u); }
    }
    g.uploads = g.uploads.filter(u => !u.dead);
    // brûlure : dégâts par paquets de 6
    for (const e of g.enemies) {
      if (!(e.burnT > 0)) continue;
      if (!g.ALIVE(e)) { e.burnT = 0; continue; }
      e.burnT -= wdt;
      e.burnAcc += wdt * QH.surchauffe.dmg / QH.surchauffe.dur;
      if (C.rand() < wdt * 30) fx.part(e.x + C.rr(-3, 3), e.y + C.rr(-3, 2), C.rr(-8, 8), C.rr(-30, -14), 0.35, C.rand() < 0.5 ? '#ffb02a' : '#ff5a1a', 'spark');
      if (e.burnAcc >= 6) { e.burnAcc -= 6; fx.hitEnemy(e, 6, C.rand() * 6.28); }
    }
    const net = g.net;
    if (!net) return;
    const p = g.player;
    // caméras : balayage, soupçon qui monte quand elles te voient
    for (const c of net.cams) {
      if (!c.on) continue;
      c.t += wdt;
      c.ang = c.base + Math.sin(c.t * 0.8) * CAM.sweep;
      if (net.alarm) { c.sus = 1; continue; }
      const a = Math.atan2(p.y - c.y, p.x - c.x);
      const seen = !g.cheats.invis && C.dist(c.x, c.y, p.x, p.y) < CAM.range && Math.abs(C.angDiff(c.ang, a)) < CAM.fov && M.los(c.x, c.y, p.x, p.y);
      c.sus = C.clamp(c.sus + (seen ? wdt / CAM.detect : -wdt * 0.3), 0, 1);
      if (c.sus >= 1) alarm(c.x, c.y);
    }
    // tourelles
    for (const t of net.turrets) {
      if (t.dead || !t.on) continue;
      t.fireCd -= wdt; t.muzzle -= wdt;
      let tgt = null;
      const sees = o => C.dist(t.x, t.y, o.x, o.y) < TUR.range && M.los(t.x, t.y, o.x, o.y);
      if (t.ally) {
        let bd = 1e9;
        for (const e of g.enemies) if (g.ALIVE(e) && sees(e)) { const d = C.dist(t.x, t.y, e.x, e.y); if (d < bd) { bd = d; tgt = e; } }
      } else {
        const cands = g.cheats.invis ? [] : [p];
        if (g.comp && g.comp.state === 'up' && !g.comp.inCar) cands.push(g.comp);
        const seen = cands.filter(sees);
        if (!t.active) {
          t.sus = C.clamp(t.sus + (seen.length ? wdt / 0.7 : -wdt * 0.5), 0, 1);
          if (t.sus >= 1) { t.active = true; alarm(t.x, t.y); }
        }
        if (t.active && seen.length) tgt = seen[0];
      }
      if (tgt) {
        const a = Math.atan2(tgt.y - t.y, tgt.x - t.x);
        t.aim = C.turn(t.aim, a, wdt * TUR.turn);
        if (Math.abs(C.angDiff(t.aim, a)) < 0.14 && t.fireCd <= 0) {
          t.fireCd = TUR.rate;
          const s = t.aim + C.rr(-TUR.spread, TUR.spread);
          g.bullets.push({ x: t.x + Math.cos(t.aim) * 7, y: t.y + Math.sin(t.aim) * 7, vx: Math.cos(s) * TUR.speed, vy: Math.sin(s) * TUR.speed, dmg: TUR.dmg, team: t.ally ? 0 : 1, life: 0.9, turret: true });
          t.muzzle = 0.05;
          C.sfx('eshot');
        }
      } else if (!t.active) t.aim += wdt * 0.6;   // elle cherche
    }
  };

  // Une balle touche-t-elle une caméra ou une tourelle ? (les tiennes ne se tirent pas dessus)
  N.bulletHit = function (b) {
    const g = G(), net = g.net;
    if (!net || b.team === 2) return false;
    if (b.team === 0 && !b.turret) {
      for (const c of net.cams) {
        if (c.dead || C.dist(b.x, b.y, c.x, c.y) > 4) continue;
        c.hp -= b.dmg;
        g.fx.sparks(c.x, c.y, '#fff2a0', 6);
        if (c.hp <= 0) { c.dead = true; c.on = false; C.sfx('hit'); }
        return true;
      }
    }
    for (const t of net.turrets) {
      if (t.dead || (b.team === 0) === t.ally || C.dist(b.x, b.y, t.x, t.y) > 5) continue;
      t.hp -= b.dmg;
      g.fx.sparks(b.x, b.y, '#fff2a0', 5);
      if (!t.ally && t.on && !t.active) { t.active = true; alarm(t.x, t.y); }
      if (t.hp <= 0) { t.dead = true; t.on = false; g.fx.sparks(t.x, t.y, '#ffb02a', 20); G().shake = Math.max(G().shake, 3); C.sfx('down'); }
      return true;
    }
    return false;
  };

  // ---------- breach protocol ----------
  // Une grille 5x5 de codes. On choisit une case de la première ligne, puis une de sa colonne, puis de sa ligne, etc.
  // Les codes choisis remplissent le tampon ; un daemon réussit si sa séquence y apparaît d'un bloc.
  // Tous les daemons sont des morceaux d'un même chemin valide : on peut tous les réussir.
  const CODES = ['1C', '55', 'BD', 'E9', '7A', 'FF'];
  const rnd = n => (Math.random() * n) | 0;
  N.openBreach = function (term) {
    const g = G(), size = g.mods.buffer, grid = [];
    for (let r = 0; r < 5; r++) { grid.push([]); for (let c = 0; c < 5; c++) grid[r].push(CODES[rnd(CODES.length)]); }
    // chemin solution
    const used = new Set(), sol = [];
    let mode = 'row', line = 0;
    for (let i = 0; i < size; i++) {
      const cand = [];
      for (let j = 0; j < 5; j++) { const [r, c] = mode === 'row' ? [line, j] : [j, line]; if (!used.has(r * 5 + c)) cand.push([r, c]); }
      const [r, c] = cand[rnd(cand.length)];
      used.add(r * 5 + c);
      const code = CODES[rnd(CODES.length)];
      grid[r][c] = code; sol.push(code);
      if (mode === 'row') { mode = 'col'; line = c; } else { mode = 'row'; line = r; }
    }
    const k = g.contract, defs = [];
    if (k && k.type === 'data' && !k.done && !k.failed && k.site === M.id) defs.push({ id: 'data', nom: 'TÉLÉCHARGER LES DONNÉES', len: 3, main: true });
    defs.push({ id: 'secu', nom: 'COUPER LA SÉCURITÉ', len: 3 }, { id: 'eddies', nom: 'DÉTOURNER ' + D.net.breachEddies + ' €$', len: 2 }, { id: 'ram', nom: 'RECHARGER LA RAM', len: 2 });
    const daemons = defs.map(d => { const off = rnd(size - d.len + 1); return Object.assign(d, { seq: sol.slice(off, off + d.len), done: false }); });
    g.breach = { term, grid, size, buffer: [], mode: 'row', line: 0, used: new Set(), cur: 0, daemons, t: D.net.breachTime, started: false, over: false, endT: 0, msg: '', lmx: C.input.mx, lmy: C.input.my };
    C.sfx('upload');
  };
  const cellAt = (b, i) => (b.mode === 'row' ? [b.line, i] : [i, b.line]);
  function pick(b, r, c) {
    if (b.used.has(r * 5 + c)) { C.sfx('empty'); return; }
    b.used.add(r * 5 + c);
    b.buffer.push(b.grid[r][c]);
    b.started = true;
    if (b.mode === 'row') { b.mode = 'col'; b.line = c; b.cur = r; } else { b.mode = 'row'; b.line = r; b.cur = c; }
    C.sfx('breach');
    const str = b.buffer.join(' ');
    for (const d of b.daemons) if (!d.done && str.includes(d.seq.join(' '))) { d.done = true; C.sfx('hack'); }
    // plus aucune case libre sur la ligne : c'est fini
    let free = false;
    for (let i = 0; i < 5; i++) { const [rr, cc] = cellAt(b, i); if (!b.used.has(rr * 5 + cc)) free = true; }
    if (b.buffer.length >= b.size || b.daemons.every(d => d.done) || !free) finish(b);
  }
  function finish(b) {
    if (b.over) return;
    const g = G(), fx = g.fx, ok = b.daemons.filter(d => d.done), tm = b.term;
    b.over = true; b.endT = 1.8;
    C.skills.gain(10 * ok.length);
    for (const d of ok) {
      if (d.id === 'data') g.contract.hack = D.contracts.data.hack;
      else if (d.id === 'secu' && g.net) { for (const c of g.net.cams) { c.on = false; c.sus = 0; } for (const t of g.net.turrets) if (!t.ally) { t.on = false; t.active = false; } g.net.alarm = false; }
      else if (d.id === 'eddies') fx.earn(D.net.breachEddies, tm.x, tm.y - 10);
      else if (d.id === 'ram') g.ram = g.mods.ramMax;
    }
    const dataMissed = b.daemons.some(d => d.id === 'data' && !d.done);
    tm.used = !dataMissed;   // le terminal d'un vol de données reste accessible tant que les données ne sont pas prises
    if (!ok.length) { b.msg = 'BREACH ÉCHOUÉ · ALARME'; b.msgCol = '#ff2040'; alarm(tm.x, tm.y); }
    else { b.msg = ok.length + ' DAEMON' + (ok.length > 1 ? 'S' : '') + ' INSTALLÉ' + (ok.length > 1 ? 'S' : '') + (dataMissed ? ' · DONNÉES MANQUÉES' : ''); b.msgCol = dataMissed ? '#ffb02a' : '#d4f542'; }
    C.sfx(ok.length ? 'clear' : 'over');
  }
  N.updateBreach = function (dt) {
    const g = G(), b = g.breach, I = C.input;
    if (b.over) {
      b.endT -= dt;
      if (b.endT <= 0 || (b.endT < 1.4 && (C.keyHit('KeyE') || C.keyHit('Escape') || C.keyHit('Enter') || I.mhit[0]))) g.breach = null;
      return;
    }
    if (b.started) { b.t -= dt; if (b.t <= 0) { b.t = 0; finish(b); return; } }
    const back = C.keyHit('ArrowLeft') || C.keyHit('ArrowUp') || C.keyHit('KeyA') || C.keyHit('KeyW');
    const fwd = C.keyHit('ArrowRight') || C.keyHit('ArrowDown') || C.keyHit('KeyD') || C.keyHit('KeyS');
    if (back) b.cur = (b.cur + 4) % 5;
    if (fwd) b.cur = (b.cur + 1) % 5;
    const cell = N.breachCellUnderMouse();
    if (cell && (I.mx !== b.lmx || I.my !== b.lmy)) {
      const [r, c] = cell;
      if (b.mode === 'row' && r === b.line) b.cur = c;
      if (b.mode === 'col' && c === b.line) b.cur = r;
    }
    b.lmx = I.mx; b.lmy = I.my;
    if (C.keyHit('KeyE') || C.keyHit('Enter') || C.keyHit('Space')) { const [r, c] = cellAt(b, b.cur); pick(b, r, c); }
    else if (I.mhit[0] && cell) {
      const [r, c] = cell;
      if ((b.mode === 'row' && r === b.line) || (b.mode === 'col' && c === b.line)) pick(b, r, c);
      else C.sfx('empty');
    } else if (C.keyHit('Escape') || I.mhit[2]) finish(b);
  };

  // ---------- dessin ----------
  const T = (g, s, x, y, c, o = {}) => C.text(g, s, x, y, c, Object.assign({ shadow: '#05050a' }, o));
  const ACC = '#d4f542';   // vert-jaune des écrans de netrunner
  const rect = (g, c, x, y, w, h) => { g.fillStyle = c; g.fillRect(Math.round(x), Math.round(y), w, h); };

  // Dans le monde, par-dessus l'éclairage : terminal, caméras et leur cône, tourelles, envois en cours, états des ennemis.
  N.drawWorld = function (g, time) {
    const gm = G(), net = gm.net;
    if (net) {
      const tm = net.term;
      if (tm) {
        const x = Math.round(tm.x) - 4, y = Math.round(tm.y) - 3;
        rect(g, '#05050a', x - 1, y - 1, 10, 8);
        rect(g, '#2d3150', x, y, 8, 6);
        rect(g, '#1a1d2e', x, y + 5, 8, 1);
        rect(g, tm.used ? '#5dff9a' : Math.sin(time * 6) > 0 ? ACC : '#5a6a1a', x + 1, y + 1, 6, 3);
        rect(g, '#05050a', x + 2, y + 2, 3, 1);
      }
      for (const c of net.cams) {
        // cône de vision en pointillés : jaune, puis rouge quand elle t'a repéré
        if (c.on) {
          const col = net.alarm ? 'rgba(255,32,64,0.5)' : c.sus > 0 ? `rgba(255,${Math.round(210 - 180 * c.sus)},60,0.45)` : 'rgba(255,210,62,0.22)';
          g.fillStyle = col;
          for (let r = 10; r < CAM.range; r += 5) for (const da of [-CAM.fov, -CAM.fov / 2, 0, CAM.fov / 2, CAM.fov]) {
            const x = c.x + Math.cos(c.ang + da) * r, y = c.y + Math.sin(c.ang + da) * r;
            if (M.wall(Math.floor(x / 8), Math.floor(y / 8))) continue;
            if (!M.los(c.x, c.y, x, y)) continue;
            g.fillRect(Math.round(x), Math.round(y), 1, 1);
          }
        }
        const fx = Math.round(Math.cos(c.ang) * 3), fy = Math.round(Math.sin(c.ang) * 3);
        rect(g, '#05050a', c.x - 3, c.y - 3, 6, 6);
        rect(g, c.dead ? '#2a2a30' : '#8a8f9a', c.x - 2, c.y - 2, 4, 4);
        rect(g, c.dead ? '#141418' : c.on ? (net.alarm || c.sus > 0.5 ? '#ff2040' : Math.sin(time * 4) > 0 ? '#ff4d6d' : '#7a1a2a') : '#2a3a2a', c.x + fx - 0.5, c.y + fy - 0.5, 2, 2);
        if (c.on && c.sus > 0 && !net.alarm) { rect(g, '#05050a', c.x - 6, c.y - 9, 12, 3); rect(g, '#ffb02a', c.x - 5, c.y - 8, Math.round(10 * c.sus), 1); }
      }
      for (const t of net.turrets) {
        const ax = Math.cos(t.aim), ay = Math.sin(t.aim);
        rect(g, 'rgba(0,0,0,0.4)', t.x - 3, t.y - 2, 8, 7);
        rect(g, '#05050a', t.x - 5, t.y - 5, 10, 10);
        rect(g, t.dead ? '#24242a' : '#4a4e5a', t.x - 4, t.y - 4, 8, 8);
        rect(g, t.dead ? '#18181c' : '#6a6e7c', t.x - 3, t.y - 3, 6, 2);
        if (!t.dead) {
          for (let i = 2; i <= 8; i++) rect(g, i > 6 ? '#05050a' : '#2a2d36', t.x + ax * i - 0.5, t.y + ay * i - 0.5, 2, 2);   // canon
          const lc = !t.on ? '#1a1a1e' : t.ally ? '#3ef0ff' : t.active ? '#ff2040' : '#ffb02a';
          rect(g, lc, t.x - 1, t.y - 1, 2, 2);
          if (t.muzzle > 0) { rect(g, '#fff2a0', t.x + ax * 10 - 1, t.y + ay * 10 - 1, 3, 3); }
          if (t.hp < t.maxHp) { rect(g, '#05050a', t.x - 6, t.y + 7, 12, 3); rect(g, t.ally ? '#3ef0ff' : '#ff2040', t.x - 5, t.y + 8, Math.max(1, Math.round(10 * t.hp / t.maxHp)), 1); }
          if (!t.ally && t.on && !t.active && t.sus > 0) { rect(g, '#05050a', t.x - 6, t.y - 10, 12, 3); rect(g, '#ffb02a', t.x - 5, t.y - 9, Math.round(10 * t.sus), 1); }
        } else {
          rect(g, '#3a2a1a', t.x - 1, t.y + 1, 3, 1);
        }
      }
    }
    // états des ennemis piratés
    for (const e of gm.enemies) {
      if (!gm.ALIVE(e)) continue;
      if (e.blindT > 0) for (let i = 0; i < 4; i++) rect(g, Math.random() < 0.5 ? ACC : '#ff3ec8', e.x - 4 + Math.random() * 8, e.y - 8 + Math.random() * 4, 1, 1);
      if (e.distractT > 0) C.text(g, '?', e.x - 1, e.y - 15, ACC);
    }
    // envois en cours : barre au-dessus de la cible
    for (const u of gm.uploads) {
      const x = Math.round(u.tgt.x) - 9, y = Math.round(u.tgt.y) - 19;
      rect(g, '#05050a', x - 1, y - 1, 20, 4);
      rect(g, '#1a2a0a', x, y, 18, 2);
      rect(g, ACC, x, y, Math.round(18 * Math.min(1, u.t / u.dur)), 2);
    }
  };

  // Voile du scan (sous le HUD) : teinte verte, lignes de balayage, crochets sur chaque cible piratable.
  N.drawScanTint = function (g, sx, sy, time) {
    const gm = G();
    if (!gm.scanOn) return;
    g.fillStyle = 'rgba(160,255,80,0.07)'; g.fillRect(0, 0, C.W, C.H);
    g.fillStyle = 'rgba(212,245,66,0.05)';
    for (let y = (time * 40 | 0) % 4; y < C.H; y += 4) g.fillRect(0, y, C.W, 1);
    for (const t of N.targets()) {
      const x = Math.round(t.x - sx), y = Math.round(t.y - sy), sel = gm.scanT && gm.scanT.ref === t.ref, s = sel ? 8 : 6;
      const col = sel ? '#ffffff' : t.kind === 'enemy' ? ACC : '#3ef0ff';
      g.fillStyle = col;
      for (const [dx, dy] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) {
        g.fillRect(x + dx * s - (dx > 0 ? 1 : 0), y + dy * s - (dy > 0 ? 1 : 0), 1, 1);
        g.fillRect(x + dx * s - (dx > 0 ? 2 : -1) * 1, y + dy * s - (dy > 0 ? 1 : 0), 1, 1);
        g.fillRect(x + dx * s - (dx > 0 ? 1 : 0), y + dy * s - (dy > 0 ? 2 : -1), 1, 1);
      }
    }
  };

  // HUD : barre de RAM à droite, panneau des quickhacks pendant le scan.
  let panelRows = [];
  N.panelRowUnderMouse = () => {
    const { mx, my } = C.input;
    return panelRows.findIndex(([x, y, w, h]) => mx >= x && mx < x + w && my >= y && my < y + h);
  };
  N.drawHUD = function (g) {
    const gm = G(), rx = C.W - 4, max = gm.mods.ramMax, ram = gm.ram;
    T(g, 'RAM ' + Math.floor(ram) + '/' + max, rx, 38, gm.scanOn ? ACC : '#c7d5e0', { align: 'right' });
    const sw = Math.max(2, Math.floor((60 - (max - 1)) / max)), w0 = sw * max + (max - 1);
    for (let i = 0; i < max; i++) {
      const x = rx - w0 + i * (sw + 1), f = C.clamp(ram - i, 0, 1);
      g.fillStyle = '#05050a'; g.fillRect(x - 1, 44, sw + 2, 5);
      g.fillStyle = '#1e2a0e'; g.fillRect(x, 45, sw, 3);
      if (f > 0) { g.fillStyle = f >= 1 ? ACC : '#7a8a2a'; g.fillRect(x, 45, Math.max(1, Math.round(sw * f)), 3); }
    }
    panelRows = [];
    if (!gm.scanOn) return;
    const tg = gm.scanT;
    if (!tg) { T(g, 'SCAN · VISE UNE CIBLE', C.W / 2, C.H - 30, ACC, { align: 'center' }); return; }
    // panneau à côté de la cible, gardé dans l'écran
    const ids = N.hacksFor(tg.kind), pw = 132, ph = 14 + ids.length * 9;
    let px = Math.round(tg.x - gm.cam.x + 14), py = Math.round(tg.y - gm.cam.y - 10);
    if (px + pw > C.W - 4) px = Math.round(tg.x - gm.cam.x - 14 - pw);
    px = C.clamp(px, 4, C.W - pw - 4); py = C.clamp(py, 52, C.H - ph - 4);
    g.fillStyle = 'rgba(8,12,4,0.88)'; g.fillRect(px, py, pw, ph);
    g.fillStyle = ACC; g.fillRect(px, py, pw, 1);
    const r = tg.ref;
    T(g, nameOf(tg), px + 4, py + 4, '#ffffff');
    if (tg.kind === 'enemy') T(g, Math.ceil(r.hp) + ' PV', px + pw - 4, py + 4, '#ff8a9a', { align: 'right' });
    ids.forEach((id, i) => {
      const h = QH[id], why = N.why(tg, id), ry = py + 13 + i * 9;
      panelRows.push([px, ry - 2, pw, 9]);
      const hover = N.panelRowUnderMouse() === i;
      if (hover) { g.fillStyle = 'rgba(212,245,66,0.15)'; g.fillRect(px + 1, ry - 2, pw - 2, 9); }
      T(g, (i + 1) + ' ' + h.nom, px + 4, ry, why ? '#5a6a4a' : hover ? '#ffffff' : ACC);
      T(g, why && why !== 'RAM' ? why : h.ram + ' RAM', px + pw - 4, ry, why ? (why === 'RAM' ? '#ff5a7a' : '#5a6a4a') : '#c7d5e0', { align: 'right' });
    });
    const hr = N.panelRowUnderMouse();
    if (hr >= 0) T(g, QH[ids[hr]].desc, C.W / 2, C.H - 30, '#c7d5e0', { align: 'center' });
  };

  // Écran du breach protocol (jeu en pause).
  let cellRects = [];
  N.breachCellUnderMouse = () => {
    const { mx, my } = C.input;
    const r = cellRects.find(([x, y, w, h]) => mx >= x && mx < x + w && my >= y && my < y + h);
    return r ? [r[4], r[5]] : null;
  };
  N.drawBreach = function (g, time) {
    const b = G().breach;
    g.fillStyle = 'rgba(2,4,0,0.86)'; g.fillRect(0, 0, C.W, C.H);
    const w = 300, h = 168, x = Math.round((C.W - w) / 2), y = Math.round((C.H - h) / 2);
    g.fillStyle = '#080c04'; g.fillRect(x, y, w, h);
    g.fillStyle = ACC; g.fillRect(x, y, w, 1); g.fillRect(x, y, 1, 10);
    g.fillStyle = '#2a3a14'; g.fillRect(x, y + h - 1, w, 1); g.fillRect(x + w - 1, y, 1, h);
    T(g, 'BREACH PROTOCOL', x + 6, y + 5, ACC);
    T(g, b.started ? 'TEMPS ' + b.t.toFixed(1) : 'LE CHRONO DÉMARRE AU PREMIER CHOIX', x + w - 6, y + 5, b.started && b.t < 5 ? '#ff5a7a' : '#8f9a6a', { align: 'right' });
    // tampon
    T(g, 'TAMPON', x + 6, y + 17, '#8f9a6a');
    for (let i = 0; i < b.size; i++) {
      const bx = x + 34 + i * 16;
      g.fillStyle = i < b.buffer.length ? '#1e2a0e' : 'transparent';
      if (i < b.buffer.length) g.fillRect(bx, y + 14, 14, 10);
      g.fillStyle = '#3a4a1a'; g.fillRect(bx, y + 14, 14, 1); g.fillRect(bx, y + 23, 14, 1); g.fillRect(bx, y + 14, 1, 10); g.fillRect(bx + 13, y + 14, 1, 10);
      if (b.buffer[i]) T(g, b.buffer[i], bx + 7, y + 17, ACC, { align: 'center' });
    }
    // grille
    const gx = x + 8, gy = y + 34, cw = 22, ch = 16;
    g.fillStyle = '#0c1206'; g.fillRect(gx - 2, gy - 2, cw * 5 + 4, ch * 5 + 4);
    // bande de la ligne ou de la colonne jouable
    if (!b.over) {
      g.fillStyle = 'rgba(212,245,66,0.12)';
      if (b.mode === 'row') g.fillRect(gx - 2, gy + b.line * ch, cw * 5 + 4, ch);
      else g.fillRect(gx + b.line * cw, gy - 2, cw, ch * 5 + 4);
    }
    cellRects = [];
    const hoverSeq = [];
    for (let r = 0; r < 5; r++) for (let c = 0; c < 5; c++) {
      const cx = gx + c * cw, cy = gy + r * ch, used = b.used.has(r * 5 + c);
      cellRects.push([cx, cy, cw, ch, r, c]);
      const inLine = !b.over && (b.mode === 'row' ? r === b.line : c === b.line);
      const isCur = inLine && (b.mode === 'row' ? c === b.cur : r === b.cur);
      if (isCur) {
        g.fillStyle = 'rgba(212,245,66,0.3)'; g.fillRect(cx + 1, cy + 1, cw - 2, ch - 2);
        g.fillStyle = ACC; g.fillRect(cx, cy, cw, 1); g.fillRect(cx, cy + ch - 1, cw, 1); g.fillRect(cx, cy, 1, ch); g.fillRect(cx + cw - 1, cy, 1, ch);
        if (!used) hoverSeq.push(b.grid[r][c]);
      }
      T(g, used ? '[]' : b.grid[r][c], cx + cw / 2, cy + 5, used ? '#2a3a14' : isCur ? '#ffffff' : inLine ? ACC : '#6a7a4a', { align: 'center' });
    }
    // daemons
    const dx = x + 132;
    T(g, 'DAEMONS', dx, y + 34, '#8f9a6a');
    b.daemons.forEach((d, i) => {
      const dy = y + 46 + i * 24;
      g.fillStyle = d.done ? 'rgba(93,255,154,0.1)' : 'rgba(212,245,66,0.04)'; g.fillRect(dx - 3, dy - 3, w - 136, 22);
      if (d.main) { g.fillStyle = '#ffd23e'; g.fillRect(dx - 3, dy - 3, 1, 22); }
      T(g, d.nom, dx, dy, d.done ? '#5dff9a' : d.main ? '#ffd23e' : '#c7d5e0');
      if (d.done) T(g, 'OK', x + w - 8, dy, '#5dff9a', { align: 'right' });
      // séquence ; on éclaire ce qui correspond déjà à la fin du tampon
      let match = 0;
      if (!d.done) for (let n = Math.min(d.seq.length - 1, b.buffer.length); n > 0; n--) if (b.buffer.slice(-n).join(' ') === d.seq.slice(0, n).join(' ')) { match = n; break; }
      d.seq.forEach((code, j) => {
        const on = d.done || j < match, nextUp = !d.done && j === match && hoverSeq[0] === code;
        T(g, code, dx + j * 16, dy + 9, on ? '#5dff9a' : nextUp ? '#ffffff' : '#6a7a4a');
      });
    });
    if (b.over) T(g, b.msg, x + w / 2, y + h - 22, b.msgCol, { align: 'center' });
    T(g, '[FLÈCHES/SOURIS] CHOISIR   [E] VALIDER   [ÉCHAP] DÉCONNECTER', x + w / 2, y + h - 10, '#6a7a4a', { align: 'center' });
    const mx = Math.round(C.input.mx), my = Math.round(C.input.my);
    g.fillStyle = '#05050a'; g.fillRect(mx - 1, my - 1, 3, 3);
    g.fillStyle = '#ffffff'; g.fillRect(mx, my, 1, 1);
  };
})();
