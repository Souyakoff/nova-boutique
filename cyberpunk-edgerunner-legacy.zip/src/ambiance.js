'use strict';
// Ambiance des rues : enseignes néon animées, flaques, bouches d'égout qui fument, AV qui passent, pluie.
//
// A.scan(g)            à la construction de l'image d'une carte de rue : place enseignes, flaques et bouches
//                      d'égout (de façon stable, par hachage des tuiles) et dessine leur partie fixe dans l'image.
// A.drawLit(g, t, ...) par-dessus l'éclairage, dans le repère du monde : néons qui clignotent, vapeur, ronds dans
//                      les flaques sous la pluie, AV et leur ombre.
// A.drawScreen(g, t)   dans le repère de l'écran : rideau de pluie, éclaboussures, teinte humide.
// La météo d'un gig (pluie ou non) est tirée sans toucher au hasard du jeu : G.weather.
(function () {
  const C = CEL, M = C.map;
  const A = (C.amb = { cur: null });
  const G = () => C.game;
  const hash = (x, y, i = 0) => { let h = (x * 374761393 + y * 668265263 + i * 2147483647) | 0; h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; };
  const NEON = ['#ff3ec8', '#3ef0ff', '#ffd23e', '#7a5cff', '#5dff9a', '#ff2040', '#ff7a1a'];
  const WORDS = ['BAR', 'NOODLES', 'HOTEL', 'RIPPER', '24/7', 'CLUB', 'PAWN', 'BRAINDANCE', 'GUNS', 'TACOS', 'MOTEL', 'DOLLS'];
  const WALK = new Set(['s', 'k', 'q', 'z', 'p', 'g']);

  // Pluie sur ce gig ? Un peu moins d'un gig sur deux, selon le leader et le numéro du gig.
  A.rollWeather = function (leader) {
    let h = leader.gigs * 7919;
    for (const ch of leader.nom) h = (h * 31 + ch.charCodeAt(0)) | 0;
    return { rain: Math.abs(h) % 100 < 45 };
  };
  A.raining = () => { const g = G(); return !!(g.weather && g.weather.rain); };

  // ---------- placement et partie fixe ----------
  A.scan = function (g) {
    const def = M.def, out = { signs: [], puddles: [], vents: [] };
    if (!def.outdoor) return out;
    const words = def.signWords || WORDS, T = (x, y) => M.tile(x, y);
    const nearDoor = (x, y) => def.doors.some(d => Math.abs(d.x - x) < 4 && Math.abs(d.y - y) < 3);
    const taken = [];
    const free = (x, y) => !taken.some(([a, b]) => Math.abs(a - x) < 9 && Math.abs(b - y) < 4);
    for (let ty = 1; ty < M.MH - 1; ty++) for (let tx = 1; tx < M.MW - 1; tx++) {
      if (T(tx, ty) !== 'B' || hash(tx, ty, 77) > 0.09 || nearDoor(tx, ty) || !free(tx, ty)) continue;
      const dead = def.roof === 'ruin' ? hash(tx, ty, 78) < 0.5 : hash(tx, ty, 78) < 0.08;
      const col = NEON[(hash(tx, ty, 79) * NEON.length) | 0], col2 = NEON[(hash(tx, ty, 80) * NEON.length) | 0];
      const mode = ['steady', 'blink', 'chase', 'cycle', 'steady'][(hash(tx, ty, 81) * 5) | 0];
      // enseigne horizontale sur une façade qui donne au sud
      const word = words[(hash(tx, ty, 82) * words.length) | 0], w = C.textWidth(word) + 6, nt = Math.ceil(w / 8);
      let ok = true;
      for (let i = 0; i < nt; i++) if (T(tx + i, ty) !== 'B' || !WALK.has(T(tx + i, ty + 1)) && !['r', '='].includes(T(tx + i, ty + 1))) ok = false;
      if (ok && WALK.has(T(tx, ty + 1))) {
        out.signs.push({ kind: 'board', x: tx * 8 + 1, y: ty * 8, w, h: 7, word, col, col2, mode, dead, ph: hash(tx, ty, 83) * 10 });
        taken.push([tx, ty]);
        continue;
      }
      // enseigne verticale sur une façade qui donne à l'est ou à l'ouest
      const east = WALK.has(T(tx + 1, ty)), west = WALK.has(T(tx - 1, ty));
      if ((east || west) && T(tx, ty - 1) === 'B' && T(tx, ty + 1) === 'B') {
        const x = east ? tx * 8 + 4 : tx * 8 - 1;
        out.signs.push({ kind: 'vert', x, y: ty * 8 - 8, w: 5, h: 22, col, col2, mode, dead, ph: hash(tx, ty, 83) * 10, seed: tx * 13 + ty });
        taken.push([tx, ty]);
      }
    }
    // plaques des enseignes, éteintes (le néon est ajouté à chaque image)
    for (const s of out.signs) {
      g.fillStyle = '#05050a'; g.fillRect(s.x - 1, s.y - 1, s.w + 2, s.h + 2);
      g.fillStyle = '#14121e'; g.fillRect(s.x, s.y, s.w, s.h);
    }
    // flaques et bouches d'égout
    for (let ty = 0; ty < M.MH; ty++) for (let tx = 0; tx < M.MW; tx++) {
      const t = T(tx, ty);
      if (['r', 's', 'p', 'k', 'q'].includes(t) && !M.blocked(tx, ty) && hash(tx, ty, 90) < 0.03) {
        const p = { x: tx * 8 + 4, y: ty * 8 + 4, rx: 3 + hash(tx, ty, 91) * 5, ry: 1.5 + hash(tx, ty, 92) * 2 };
        for (let dy = -Math.ceil(p.ry); dy <= Math.ceil(p.ry); dy++) {
          const w = Math.round(p.rx * Math.sqrt(Math.max(0, 1 - (dy / (p.ry + 0.3)) ** 2)));
          if (!w) continue;
          g.fillStyle = '#0c111c'; g.fillRect(Math.round(p.x - w), Math.round(p.y + dy), w * 2 + 1, 1);
        }
        g.fillStyle = '#26344e'; g.fillRect(Math.round(p.x - p.rx * 0.5), Math.round(p.y - p.ry * 0.4), Math.max(1, Math.round(p.rx * 0.6)), 1);   // reflet
        out.puddles.push(p);
      } else if (t === 'r' && hash(tx, ty, 93) < 0.006) {
        const x = tx * 8 + 4, y = ty * 8 + 4;
        g.fillStyle = '#0a0a0e'; g.fillRect(x - 3, y - 2, 7, 5); g.fillRect(x - 2, y - 3, 5, 7);
        g.fillStyle = '#2a2a32'; for (let i = -2; i <= 2; i += 2) g.fillRect(x + i, y - 2, 1, 5);
        out.vents.push({ x, y, ph: hash(tx, ty, 94) * 10 });
      }
    }
    return out;
  };

  // ---------- par-dessus l'éclairage ----------
  function glowAt(g, x, y, r, col, a) {
    const gr = g.createRadialGradient(x, y, 0, x, y, r);
    gr.addColorStop(0, col + Math.round(a * 255).toString(16).padStart(2, '0'));
    gr.addColorStop(1, col + '00');
    g.fillStyle = gr; g.fillRect(x - r, y - r, r * 2, r * 2);
  }
  // Néon allumé à l'instant t ?
  function lit(s, t) {
    if (s.dead) return Math.sin(t * 23 + s.ph) > 0.93;   // enseigne morte : un sursaut de temps en temps
    if (s.mode === 'blink') return Math.sin(t * 3 + s.ph) > -0.4;
    // les autres grésillent rarement
    return !(Math.sin(t * 17 + s.ph * 3) > 0.985 || (Math.sin(t * 0.7 + s.ph) > 0.97 && Math.sin(t * 31) > 0));
  }
  const vis = (o, sx, sy, m = 40) => o.x > sx - m && o.x < sx + C.W + m && o.y > sy - m && o.y < sy + C.H + m;

  let av = null, avT = 6, lastT = 0;
  A.drawLit = function (g, t, sx, sy) {
    const a = A.cur, gm = G();
    if (!a || !M.def.outdoor) return;
    const dt = Math.min(0.5, Math.max(0, t - lastT)); lastT = t;   // temps du jeu : s'arrête dans les menus
    // enseignes
    for (const s of a.signs) {
      if (!vis(s, sx, sy)) continue;
      const on = lit(s, t), col = s.mode === 'cycle' && Math.sin(t * 1.3 + s.ph) > 0 ? s.col2 : s.col;
      if (!on) continue;
      g.globalCompositeOperation = 'lighter';
      glowAt(g, s.x + s.w / 2, s.y + s.h / 2, Math.max(s.w, s.h) * 0.9, col, 0.25);
      g.globalCompositeOperation = 'source-over';
      if (s.kind === 'board') {
        C.text(g, s.word, s.x + 3, s.y + 1, col);
        g.fillStyle = col; g.fillRect(s.x, s.y, s.w, 1); g.fillRect(s.x, s.y + s.h - 1, s.w, 1);
      } else {
        // colonne d'idéogrammes inventés : blocs de 3x3 pixels
        for (let i = 0; i < 5; i++) for (let b = 0; b < 9; b++) if (hash(s.seed, i, b) < 0.55) { g.fillStyle = col; g.fillRect(s.x + 1 + (b % 3), s.y + 1 + i * 4 + ((b / 3) | 0), 1, 1); }
        g.fillStyle = col; g.fillRect(s.x, s.y, 1, s.h); g.fillRect(s.x + s.w - 1, s.y, 1, s.h);
      }
      if (s.mode === 'chase') {
        // lumières qui courent autour du cadre
        const per = 2 * (s.w + s.h), k = Math.floor(t * 30 + s.ph * 10);
        g.fillStyle = '#ffffff';
        for (let i = 0; i < per; i += 6) {
          const d = (i + k) % per;
          const [x, y] = d < s.w ? [s.x + d, s.y - 1] : d < s.w + s.h ? [s.x + s.w, s.y + d - s.w] : d < 2 * s.w + s.h ? [s.x + 2 * s.w + s.h - d, s.y + s.h] : [s.x - 1, s.y + per - d];
          g.fillRect(x, y, 1, 1);
        }
      }
    }
    // vapeur des bouches d'égout
    for (const v of a.vents) {
      if (!vis(v, sx, sy)) continue;
      for (let i = 0; i < 6; i++) {
        const k = (t * 0.45 + i / 6 + v.ph) % 1, r = 2 + k * 7;
        g.fillStyle = `rgba(190,200,215,${0.16 * (1 - k)})`;
        const x = v.x + Math.sin(t + i * 2 + v.ph) * 3 + k * 6, y = v.y - k * 20;
        g.fillRect(Math.round(x - r), Math.round(y - r * 0.6), Math.round(r * 2), Math.round(r * 1.2));
      }
    }
    // ronds dans les flaques sous la pluie
    if (A.raining()) {
      g.fillStyle = 'rgba(150,190,240,0.4)';
      for (const p of a.puddles) {
        if (!vis(p, sx, sy)) continue;
        const k = (t * 1.6 + p.x * 0.13) % 1, r = k * p.rx;
        if (k > 0.8) continue;
        g.fillRect(Math.round(p.x - r), Math.round(p.y - r * 0.4), Math.max(1, Math.round(r * 2)), 1);
        g.fillRect(Math.round(p.x - r), Math.round(p.y + r * 0.4), Math.max(1, Math.round(r * 2)), 1);
      }
    }
    // AV : un véhicule volant traverse le ciel de temps en temps (ombre au sol, feux qui clignotent)
    avT -= dt;
    if (!av && avT <= 0) {
      const w = gm.wanted, police = !!w && w.stars >= 2, fromLeft = Math.random() < 0.5;
      const y = sy + C.H * (0.2 + Math.random() * 0.6);
      av = { x: fromLeft ? sx - 80 : sx + C.W + 80, y, vx: (fromLeft ? 1 : -1) * (police ? 70 : 110), vy: (Math.random() - 0.5) * 20, police };
    }
    if (av) {
      av.x += av.vx * dt; av.y += av.vy * dt;
      // la patrouille aérienne du NCPD ralentit au-dessus de toi
      if (av.police) { const p = gm.player; av.vx += (p.x - av.x) * dt * 0.6 - av.vx * dt * 0.5; av.vy += (p.y - 30 - av.y) * dt * 0.6 - av.vy * dt * 0.5; }
      const sh = { x: av.x + 26, y: av.y + 34 };
      g.fillStyle = 'rgba(0,0,0,0.28)';
      for (let dy = -6; dy <= 6; dy++) { const w = Math.round(20 * Math.sqrt(1 - (dy / 7) ** 2)); g.fillRect(Math.round(sh.x - w), Math.round(sh.y + dy), w * 2, 1); }
      // carlingue vue de dessus : coque métallique, verrière, deux réacteurs
      for (let dy = -4; dy <= 4; dy++) {
        const w = Math.round(14 * Math.sqrt(1 - (dy / 5) ** 2));
        g.fillStyle = dy < -1 ? '#6a7080' : dy < 2 ? '#454a5a' : '#2a2e3a';
        g.fillRect(Math.round(av.x - w), Math.round(av.y + dy), w * 2, 1);
      }
      const dir = av.vx >= 0 ? 1 : -1;
      g.fillStyle = '#1a2a40'; g.fillRect(Math.round(av.x + dir * 4 - 3), Math.round(av.y - 2), 6, 3);
      g.fillStyle = '#7ff6ff'; g.fillRect(Math.round(av.x + dir * 4 - 2), Math.round(av.y - 2), 2, 1);
      g.globalCompositeOperation = 'lighter';
      for (const side of [-1, 1]) glowAt(g, av.x - dir * 6, av.y + side * 6, 7, av.police ? '#3c6eff' : '#3ef0ff', 0.6);
      g.globalCompositeOperation = 'source-over';
      const blink = Math.floor(t * 4) % 2 === 0;
      g.fillStyle = av.police ? (blink ? '#ff2040' : '#3c6eff') : blink ? '#ff2040' : '#5a1020'; g.fillRect(Math.round(av.x - 14), Math.round(av.y), 2, 2);
      g.fillStyle = av.police ? (blink ? '#3c6eff' : '#ff2040') : blink ? '#ffffff' : '#40404a'; g.fillRect(Math.round(av.x + 13), Math.round(av.y), 2, 2);
      if (av.police) {
        // projecteur braqué sur la rue
        g.globalCompositeOperation = 'lighter';
        glowAt(g, sh.x - 26, sh.y - 20, 30, '#bfe9ff', 0.32);
        g.globalCompositeOperation = 'source-over';
      }
      // recherches abandonnées : la patrouille repart ; un AV sorti de l'écran disparaît
      if (av.police && !(gm.wanted && gm.wanted.stars >= 2)) { av.police = false; av.vx = av.vx >= 0 ? 110 : -110; av.vy = 0; }
      if (!av.police && (av.x < sx - 140 || av.x > sx + C.W + 140)) { av = null; avT = 14 + Math.random() * 16; }
    }
  };
  A.resetSky = () => { av = null; avT = 4 + Math.random() * 6; };
  A.sky = () => av;   // pour les tests

  // ---------- écran : la pluie ----------
  A.drawScreen = function (g, t, sx, sy) {
    if (!A.raining()) return;
    if (!M.def.outdoor) return;
    const W = C.W, H = C.H, n = Math.round((W * H) / 650);
    g.fillStyle = 'rgba(16,24,48,0.16)'; g.fillRect(0, 0, W, H);   // ciel bas, tout est mouillé
    g.fillStyle = 'rgba(170,200,240,0.42)';
    for (let i = 0; i < n; i++) {
      const sp = 220 + hash(i, 1) * 120, len = 4 + ((hash(i, 2) * 4) | 0);
      const x = (((hash(i, 3) * (W + 40) - sx * 1.0 + t * sp * 0.22) % (W + 40)) + W + 40) % (W + 40) - 20;
      const y = (((hash(i, 4) * (H + 40) - sy * 1.0 + t * sp) % (H + 40)) + H + 40) % (H + 40) - 20;
      for (let k = 0; k < len; k++) g.fillRect(Math.round(x + k * 0.25), Math.round(y + k), 1, 1);
    }
    // éclaboussures au sol
    g.fillStyle = 'rgba(190,215,250,0.5)';
    const f = Math.floor(t * 12);
    for (let i = 0; i < n / 5; i++) {
      const x = Math.round(hash(f, i, 5) * W), y = Math.round(hash(f, i, 6) * H);
      g.fillRect(x - 1, y, 1, 1); g.fillRect(x + 1, y, 1, 1); g.fillRect(x, y - 1, 1, 1);
    }
  };
  // Son de pluie : fort dehors, étouffé à l'intérieur.
  A.sound = function () {
    C.rainSound(A.raining() && G().mode === 'play' ? (M.def.outdoor ? 1 : 0.35) : 0);
  };
})();
