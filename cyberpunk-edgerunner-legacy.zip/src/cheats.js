'use strict';
// Triches : un cyberdeck piraté qu'on ouvre avec ² (` en QWERTY) ou F2. Le jeu se met en pause.
//
// À gauche, les MODS (interrupteurs qui restent actifs d'un gig à l'autre) ; à droite, les SCRIPTS (actions immédiates).
// Les mods sont lus par le reste du jeu dans G.cheats (godmode dans hurtPlayer, one shot dans hitEnemy, etc.)
// ou appliqués à chaque image par CH.update (RAM, Sandevistan, humanité infinis).
(function () {
  const C = CEL, D = C.DEF, M = C.map;
  const CH = (C.cheat = {});
  const G = () => C.game;
  C.game.cheats = {};
  const ACC = '#d4f542', MAG = '#ff3ec8';

  const MODS = [
    ['god', 'GODMODE', 'AUCUN DÉGÂT.'],
    ['ammo', 'MUNITIONS INFINIES', 'PLUS JAMAIS DE RECHARGE.'],
    ['oneshot', 'ONE SHOT', 'CHAQUE COUP MET À TERRE.'],
    ['gore', 'GORE MAX', 'TOUT LE MONDE EXPLOSE.'],
    ['sandy', 'SANDEVISTAN INFINI', 'RALENTI SANS FIN, GRATUIT.'],
    ['ram', 'RAM INFINIE', 'QUICKHACKS GRATUITS.'],
    ['hum', 'HUMANITÉ BLINDÉE', 'TOUJOURS 100. JAMAIS PSYCHO.'],
    ['invis', 'CAMO OPTIQUE', 'ENNEMIS, CAMÉRAS, TOURELLES NE TE VOIENT PAS.'],
    ['speed', 'SUPER VITESSE', 'TU COURS 80 % PLUS VITE.'],
    ['slowmo', 'BULLET TIME', 'LE MONDE TOURNE AU RALENTI.'],
    ['nocops', 'FANTÔME DU NCPD', 'AUCUNE ÉTOILE, JAMAIS.'],
    ['turbo', 'VOITURE TURBO', 'VITESSE ET ACCÉLÉRATION X2.'],
    ['light', 'VISION NOCTURNE', 'PLUS DE NUIT.'],
    ['bighead', 'GROSSES TÊTES', 'TOUT LE MONDE EN PLUS GROS.'],
  ];
  // Scripts : [nom, description, action, disponible ?]
  const tp = (id, door) => () => { G().enterMap(id, door); return 'TÉLÉPORTÉ : ' + (C.MAPS[id].quartier || C.MAPS[id].nom); };
  const SCRIPTS = [
    ['+10 000 €$', 'EDDIES TOMBÉS DU CAMION.', () => { G().leader.eddies += 10000; return '+10 000 €$'; }],
    ['SOIN COMPLET', 'PV ET INJECTEURS AU MAX.', () => { const p = G().player; p.hp = p.maxHp; p.inj = p.maxInj; p.mag = D.weapons[p.weapon].mag; return 'COMME NEUF.'; }],
    ['+1 NIVEAU', 'UN POINT DE COMPÉTENCE (K).', () => { const L0 = G().leader; C.skills.gain(C.skills.need(L0.lvl) - L0.xp); return 'NIVEAU ' + L0.lvl + '.'; }],
    ['ARSENAL', 'TOUTES LES ARMES PAR TERRE AUTOUR DE TOI.', () => {
      const p = G().player, ids = ['pistol', 'smg', 'shotgun', 'smart', 'sniper', 'katana'];
      ids.forEach((id, i) => C.arsenal.drop(id, p.x + Math.cos(i * 1.05) * 14, p.y + Math.sin(i * 1.05) * 14));
      return 'SERS-TOI.';
    }],
    ['GANGS : PAIX', 'TOUS LES GANGS T\'OUBLIENT.', () => { const r = C.legacy.city.rep = {}; for (const e of G().enemies) if (e.gang && G().ALIVE(e)) { e.neutral = true; e.state = 'idle'; } C.legacy.save(); return 'ON EST POTES.'; }],
    ['GANGS : GUERRE', 'TOUS LES GANGS TE DÉTESTENT.', () => { for (const id of Object.keys(D.gangs)) C.gangs.addRep(id, -200); return 'BONNE CHANCE.'; }],
    ['CHROME DE LUXE', 'LES MEILLEURS IMPLANTS, SANS PERTE D\'HUMANITÉ.', () => {
      const g = G();
      Object.assign(g.leader.implants, { 'SYSTÈME': 'sandy2', BRAS: 'mantis', YEUX: 'kiroshi', PEAU: 'peau', JAMBES: 'jambes', ORGANES: 'bio', DECK: 'deck3' });
      g.refreshMods(); g.ram = g.mods.ramMax; g.sandy.charge = g.sandyDur();
      return 'SANDY MK.2, MANTIS, KIROSHI, PEAU, JAMBES, BIO, NETDRIVER.';
    }],
    ['QUADRA TURBO-R', 'UNE SPORTIVE À TES PIEDS (DEHORS).', () => {
      const g = G(), p = g.player;
      if (!M.def.outdoor) return 'SORS DANS LA RUE D\'ABORD.';
      for (let k = 0; k < 24; k++) {
        const a = k * 0.52, r = 22 + (k % 3) * 10;
        const car = { x: p.x + Math.cos(a) * r, y: p.y + Math.sin(a) * r, ang: 0, speed: 0, model: 'turbo', color: '#ff3ec8', own: true, map: M.id };
        for (const ang of [0, Math.PI / 2]) { car.ang = ang; if (!C.cars.blocked(car, g.cars)) { if (g.leader.car) g.cars = g.cars.filter(c => c !== g.leader.car); g.leader.car = car; g.cars.push(car); return 'ELLE EST À CÔTÉ DE TOI.'; } }
      }
      return 'PAS DE PLACE ICI.';
    }],
    ['RECRUE INSTANTANÉE', 'UN COMPAGNON TE REJOINT.', () => {
      const g = G(), p = g.player;
      if (g.comp) { g.comp.hp = g.comp.maxHp; g.comp.state = 'up'; g.comp.loyalty = 100; return g.comp.nom + ' SOIGNÉ, LOYAUTÉ 100.'; }
      g.fx.recruit({ nom: C.legacy.thugName(), origine: 'rue', loyalty: 100, x: p.x + 8, y: p.y });
      return 'NOUVEAU COMPAGNON.';
    }],
    ['PURGE', 'TOUS LES ENNEMIS DE LA CARTE EXPLOSENT.', () => {
      const g = G(); let n = 0;
      for (const e of g.enemies) if (g.ALIVE(e)) { g.fx.hitEnemy(e, 999, Math.random() * 6.28); n++; }
      return n + ' CIBLE' + (n > 1 ? 'S' : '') + ' PURGÉE' + (n > 1 ? 'S' : '') + '.';
    }],
    ['CYBERPSYCHO', 'UN CYBERPSYCHO APPARAÎT À CÔTÉ.', () => {
      const g = G(), p = g.player, spot = M.randomFloorNear(p.x, p.y, 40, 80);
      if (!spot) return 'PAS DE PLACE.';
      const e = g.fx.makeEnemy('psycho', 0, 0, {}, -1);
      Object.assign(e, { x: spot[0], y: spot[1], nom: 'CYBERPSYCHO', psycho: true, state: 'alert', react: 0.8 });
      g.enemies.push(e);
      return 'BONNE CHANCE.';
    }],
    ['CONTRAT REMPLI', 'LE CONTRAT EN COURS EST VALIDÉ.', () => {
      const k = G().contract;
      if (!k || k.done || k.failed) return 'PAS DE CONTRAT EN COURS.';
      k.type = 'data'; k.hack = D.contracts.data.hack;   // updateContract le valide à l'image suivante
      return 'PAYÉ.';
    }],
    ['GRAND CONTRAT', 'ARCS ARASAKA ET MILITECH COMPLETS.', () => { const L0 = G().leader; L0.arcs.arasaka = L0.arcs.militech = D.arcLength; L0.burned = false; G().offers = null; return 'VA VOIR TON FIXER.'; }],
    ['NCPD +1 ÉTOILE', 'POUR LE SPORT.', () => { const w = G().wanted; G().cheats.nocops = false; w.stars = Math.min(5, w.stars + 1); w.lost = 0; w.spawnT = 0.3; w.flashT = 2; return w.stars + ' ÉTOILE' + (w.stars > 1 ? 'S' : '') + '.'; }],
    ['NCPD : OUBLIE-MOI', 'LES ÉTOILES RETOMBENT À ZÉRO.', () => { const w = G().wanted; w.stars = 0; w.lost = 0; return 'CASIER EFFACÉ.'; }],
    ['MÉTÉO : PLUIE', 'IL PLEUT OU IL NE PLEUT PLUS.', () => { const g = G(); g.weather.rain = !g.weather.rain; return g.weather.rain ? 'IL PLEUT.' : 'BEAU TEMPS.'; }],
    ['ALLER À WATSON', 'DEVANT LA BOUCHE DE MÉTRO.', tp('rue', 'metro')],
    ['ALLER À JAPANTOWN', '', tp('japantown', 'metro')],
    ['ALLER À CITY CENTER', '', tp('centre', 'metro')],
    ['ALLER À PACIFICA', '', tp('pacifica', 'metro')],
    ['ALLER À LA PLANQUE', '', tp('planque', null)],
    ['ALLER AU CONTRAT', 'DEVANT LA SORTIE DU BÂTIMENT.', () => { const k = G().contract; if (!k) return 'PAS DE CONTRAT.'; G().enterMap(k.site, 'sortie'); return 'TÉLÉPORTÉ : ' + C.MAPS[k.site].nom; }],
  ];
  CH.MODS = MODS; CH.SCRIPTS = SCRIPTS;

  // ---------- menu ----------
  CH.open = function () {
    G().cheatMenu = { t: 0, col: 0, sel: 0, msg: '', msgT: 0, lmx: C.input.mx, lmy: C.input.my };
    C.sfx('upload');
  };
  CH.updateMenu = function (dt) {
    const g = G(), m = g.cheatMenu, I = C.input;
    m.t += dt; m.msgT -= dt;
    if (C.keyHit('Escape') || C.keyHit('Backquote') || C.keyHit('F2') || I.mhit[2]) { g.cheatMenu = null; C.sfx('empty'); return; }
    if (m.t < 0.9) { if (C.keyHit('KeyE') || C.keyHit('Enter') || I.mhit[0]) m.t = 0.9; return; }   // séquence de démarrage
    const n = m.col ? SCRIPTS.length : MODS.length;
    if (C.keyHit('ArrowUp') || C.keyHit('KeyW')) m.sel = (m.sel + n - 1) % n;
    if (C.keyHit('ArrowDown') || C.keyHit('KeyS')) m.sel = (m.sel + 1) % n;
    if (C.keyHit('ArrowLeft') || C.keyHit('KeyA') || C.keyHit('ArrowRight') || C.keyHit('KeyD')) { m.col = 1 - m.col; m.sel = Math.min(m.sel, (m.col ? SCRIPTS.length : MODS.length) - 1); }
    const row = CH.rowUnderMouse();
    if (row && (I.mx !== m.lmx || I.my !== m.lmy)) { m.col = row[0]; m.sel = row[1]; }
    m.lmx = I.mx; m.lmy = I.my;
    if (C.keyHit('KeyE') || C.keyHit('Enter') || C.keyHit('Space') || (I.mhit[0] && row)) CH.run(m.col, m.sel);
  };
  CH.run = function (col, i) {
    const g = G(), m = g.cheatMenu;
    if (col === 0) {
      const [id, nom] = MODS[i];
      g.cheats[id] = !g.cheats[id];
      if (id === 'nocops' && g.cheats.nocops) g.wanted.stars = 0;
      if (m) { m.msg = nom + (g.cheats[id] ? ' : ACTIVÉ' : ' : COUPÉ'); m.msgCol = g.cheats[id] ? ACC : '#8f98a0'; m.msgT = 2.5; }
      C.sfx(g.cheats[id] ? 'hack' : 'empty');
    } else {
      const res = SCRIPTS[i][2]();
      if (m) { m.msg = SCRIPTS[i][0] + ' > ' + res; m.msgCol = MAG; m.msgT = 3; }
      C.sfx('hack');
      // un téléport ferme le deck : on veut voir où on arrive
      if (/^ALLER/.test(SCRIPTS[i][0]) && res.startsWith('TÉLÉPORTÉ')) g.cheatMenu = null;
    }
  };
  CH.active = () => Object.values(G().cheats).some(Boolean);

  // Ce que certains mods font à chaque image.
  CH.update = function () {
    const g = G(), ch = g.cheats;
    if (ch.ram) g.ram = g.mods.ramMax;
    if (ch.sandy) g.sandy.charge = g.sandyDur();
    if (ch.hum) g.humanity = 100;
    if (ch.god) g.player.hp = g.player.maxHp;
    if (ch.ammo) g.player.mag = D.weapons[g.player.weapon].mag;
    if (ch.nocops && g.wanted) g.wanted.stars = 0;
    if (g.drive) g.drive.boost = ch.turbo ? 2 : 1;
  };

  // ---------- dessin : le deck piraté ----------
  let rows = [];
  CH.rowUnderMouse = () => {
    const { mx, my } = C.input;
    const r = rows.find(([x, y, w, h]) => mx >= x && mx < x + w && my >= y && my < y + h);
    return r ? [r[4], r[5]] : null;
  };
  const T = (g, s, x, y, c, o = {}) => C.text(g, s, x, y, c, Object.assign({ shadow: '#05050a' }, o));
  const BOOT = ['> MILITECH PARALINE // FIRMWARE 2.0.77', '> CONNEXION AU DECK...', '> ICE CONTOURNÉ', '> ACCÈS ROOT : OK'];
  CH.draw = function (g, time) {
    const gm = G(), m = gm.cheatMenu;
    g.fillStyle = 'rgba(2,4,0,0.9)'; g.fillRect(0, 0, C.W, C.H);
    const w = 304, h = 176, x = Math.round((C.W - w) / 2), y = Math.round((C.H - h) / 2);
    g.fillStyle = '#080c04'; g.fillRect(x, y, w, h);
    g.fillStyle = MAG; g.fillRect(x, y, w, 1); g.fillRect(x, y, 1, 12); g.fillRect(x + w - 1, y + h - 12, 1, 12);
    g.fillStyle = '#2a3a14'; g.fillRect(x, y + h - 1, w, 1);
    // lignes de balayage et parasites
    g.fillStyle = 'rgba(212,245,66,0.035)';
    for (let yy = y + ((time * 30) | 0) % 3; yy < y + h; yy += 3) g.fillRect(x, yy, w, 1);
    if (Math.random() < 0.06) { g.fillStyle = 'rgba(255,62,200,0.25)'; g.fillRect(x, y + Math.random() * h, w, 1); }
    T(g, 'ROOT // DECK PIRATÉ', x + 6, y + 5, MAG);
    T(g, gm.leader ? 'UTILISATEUR : ' + gm.leader.nom : '', x + w - 6, y + 5, '#6a7a4a', { align: 'right' });
    if (m.t < 0.9) {
      // séquence de démarrage
      const n = Math.min(BOOT.length, Math.floor(m.t / 0.2) + 1);
      for (let i = 0; i < n; i++) T(g, BOOT[i], x + 10, y + 26 + i * 10, i === BOOT.length - 1 ? MAG : ACC);
      if (Math.sin(time * 10) > 0) { g.fillStyle = ACC; g.fillRect(x + 10, y + 26 + n * 10, 4, 5); }
      return;
    }
    rows = [];
    const cw = (w - 18) / 2, top = y + 28, rh = 7;
    T(g, 'MODS', x + 8, y + 17, '#8f9a6a');
    T(g, 'SCRIPTS', x + 12 + cw, y + 17, '#8f9a6a');
    MODS.forEach(([id, nom], i) => {
      const ry = top + i * rh, sel = m.col === 0 && m.sel === i, on = !!gm.cheats[id];
      rows.push([x + 4, ry - 1, cw, rh, 0, i]);
      if (sel) { g.fillStyle = 'rgba(212,245,66,0.16)'; g.fillRect(x + 4, ry - 1, cw, rh); }
      T(g, nom, x + 8, ry, sel ? '#ffffff' : on ? ACC : '#7a8a5a');
      T(g, on ? 'ON' : 'OFF', x + 4 + cw - 3, ry, on ? ACC : '#4a5a3a', { align: 'right' });
    });
    const sx0 = x + 10 + cw, vis = Math.floor((h - 52) / rh);
    // la colonne des scripts défile pour garder la ligne choisie visible
    const off = m.col === 1 ? Math.max(0, Math.min(SCRIPTS.length - vis, m.sel - (vis >> 1))) : (m.off || 0);
    m.off = off;
    if (off > 0) T(g, '...', sx0 + cw - 12, top - 8, '#6a7a4a');
    if (off + vis < SCRIPTS.length) T(g, '...', sx0 + cw - 12, top + vis * rh - 2, '#6a7a4a');
    SCRIPTS.forEach(([nom], i) => {
      const ry = top + (i - off) * rh, sel = m.col === 1 && m.sel === i;
      if (i < off || i >= off + vis) return;
      rows.push([sx0, ry - 1, cw, rh, 1, i]);
      if (sel) { g.fillStyle = 'rgba(255,62,200,0.16)'; g.fillRect(sx0, ry - 1, cw, rh); }
      T(g, '> ' + nom, sx0 + 4, ry, sel ? '#ffffff' : '#c7a0c0');
    });
    g.fillStyle = '#2a3a14'; g.fillRect(x + 8 + cw, top - 2, 1, h - 46);
    // description de la ligne choisie, ou résultat de la dernière commande
    const desc = m.col === 0 ? MODS[m.sel][2] : SCRIPTS[m.sel][1];
    if (m.msgT > 0) T(g, m.msg, x + w / 2, y + h - 20, m.msgCol, { align: 'center' });
    else if (desc) T(g, desc, x + w / 2, y + h - 20, '#8f98a0', { align: 'center' });
    T(g, '[HAUT/BAS] CHOISIR  [GAUCHE/DROITE] COLONNE  [E] EXÉCUTER  [ÉCHAP] FERMER', x + w / 2, y + h - 10, '#6a7a4a', { align: 'center' });
    const mx = Math.round(C.input.mx), my = Math.round(C.input.my);
    g.fillStyle = '#05050a'; g.fillRect(mx - 1, my - 1, 3, 3);
    g.fillStyle = '#ffffff'; g.fillRect(mx, my, 1, 1);
  };
})();
