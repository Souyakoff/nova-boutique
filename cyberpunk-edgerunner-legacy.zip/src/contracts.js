'use strict';
// Nouveaux contrats : braquage discret, extraction, sabotage, vol de voiture.
//
// Chaque type a :
//   setup(k, def)    à la première entrée dans le bâtiment (ou le quartier) du contrat : place l'objectif
//   update(k, dt)    à chaque image : règles, échec, réussite
//   acts(k, acts)    actions sur E (ramasser le colis, libérer l'otage, poser la bombe...)
//   goal(k)          point à rejoindre (flèche) quand on est sur place
//   status(k)        texte du HUD
// Les contrats classiques (élimination, vol de données, nettoyage) restent dans game.js.
(function () {
  const C = CEL, D = C.DEF, M = C.map;
  const CT = (C.contracts = {});
  const G = () => C.game;
  const at = t => ({ x: t[0] * 8 + 4, y: t[1] * 8 + 4 });
  const near = (a, b, r) => C.dist(a.x, a.y, b.x, b.y) < r;
  function fail(k, why) {
    if (k.done || k.failed) return;
    const g = G(), p = g.player;
    k.failed = true;
    C.music.event('fail');
    g.fx.addFloat(p.x, p.y - 16, 'CONTRAT RATÉ : ' + why, '#ff2040');
    g.fx.addFloat(p.x, p.y - 9, 'RETOURNE À LA PLANQUE', '#c7d5e0');
    C.sfx('over');
  }
  function win(k) { k.objDone = true; }

  // ---------- braquage discret ----------
  // Voler le colis dans le coffre et ressortir sans que personne ne donne l'alerte.
  // Un ennemi mis à terre d'un seul coup ne crie pas ; un ennemi qui te voit et reste debout 2,5 s, si.
  const heist = {
    setup(k, def) { k.pkg = Object.assign(at(def.cadre), { taken: false }); k.heat = 0; },
    update(k, dt) {
      const g = G();
      if (M.id !== k.site) { if (k.pkg && k.pkg.taken) win(k); return; }
      if (g.net && g.net.alarm) return fail(k, "L'ALARME A SONNÉ");
      const loud = g.enemies.some(e => g.ALIVE(e) && e.state === 'alert');
      k.heat = loud ? k.heat + dt : Math.max(0, k.heat - dt * 0.5);
      if (k.heat > 2.5) fail(k, "ILS ONT DONNÉ L'ALERTE");
    },
    acts(k, acts) {
      const g = G();
      if (M.id === k.site && k.pkg && !k.pkg.taken && near(g.player, k.pkg, 14)) acts.unshift(['VOLER LE COLIS', () => { k.pkg.taken = true; g.fx.addFloat(k.pkg.x, k.pkg.y - 10, 'COLIS VOLÉ · SORS DISCRÈTEMENT', '#ffd23e'); C.sfx('reload'); }]);
    },
    goal(k) { return M.id === k.site && k.pkg && !k.pkg.taken ? { x: k.pkg.x, y: k.pkg.y, label: 'COLIS' } : null; },
    status(k) {
      if (k.pkg && k.pkg.taken) return 'SORS AVEC LE COLIS';
      return k.heat > 0 ? 'ON TE CHERCHE ' + Math.ceil(2.5 - k.heat) + ' S' : 'DISCRÉTION';
    },
  };

  // ---------- extraction ----------
  // Libérer l'otage (assis, mains liées), puis le ramener dehors vivant. Les ennemis lui tirent dessus.
  const extract = {
    setup(k, def) {
      const o = at(def.cadre);
      k.hostage = { x: o.x, y: o.y, r: 3.5, hp: 60, maxHp: 60, aim: Math.PI / 2, walk: 0, free: false, dead: false, nom: C.legacy.thugName(), outfit: C.sprites.randomLook(), hurtT: 0 };
    },
    update(k, dt) {
      const g = G(), h = k.hostage, p = g.player;
      if (!h) return;
      if (h.dead) return fail(k, "L'OTAGE EST MORT");
      h.hurtT -= dt;
      if (h.free && h.map === M.id) {
        // il te suit, à 14 px derrière, sans te coller
        const d = C.dist(h.x, h.y, p.x, p.y);
        if (d > 16) {
          const a = Math.atan2(p.y - h.y, p.x - h.x), sp = Math.min(78, d * 3);
          M.move(h, Math.cos(a) * sp * dt, Math.sin(a) * sp * dt);
          h.aim = a; h.walk += dt * 10; h.moving = true;
        } else h.moving = false;
      }
      if (h.free && h.out) win(k);
    },
    acts(k, acts) {
      const g = G(), h = k.hostage;
      if (h && !h.free && M.id === k.site && near(g.player, h, 14)) acts.unshift(['LIBÉRER ' + h.nom, () => { h.free = true; h.map = M.id; g.fx.addFloat(h.x, h.y - 12, 'MERCI ! SORS-MOI DE LÀ', '#ffffff'); C.sfx('spare'); }]);
    },
    // On change de carte : l'otage suit s'il est assez près ; sorti du bâtiment, c'est gagné.
    travel(k, from, to, before) {
      const h = k.hostage, g = G();
      if (!h || !h.free || h.dead || h.map !== from || !before || !near(h, before, 60)) return;
      h.map = to;
      if (from === k.site) h.out = true;
      h.x = g.player.x; h.y = g.player.y + 6;
    },
    goal(k) { const h = k.hostage; return M.id === k.site && h && !h.free ? { x: h.x, y: h.y, label: 'OTAGE' } : null; },
    status(k) { const h = k.hostage; return !h ? 'TROUVE L\'OTAGE' : h.free ? 'SORS ' + h.nom + ' DE LÀ · ' + Math.ceil(h.hp) + ' PV' : 'LIBÈRE L\'OTAGE'; },
  };

  // ---------- sabotage ----------
  // Poser la bombe sur le générateur (E maintenu 2 s), puis s'éloigner : elle saute 20 s plus tard.
  const sabotage = {
    setup(k, def) { k.bomb = Object.assign(at(def.psycho), { plant: 0, armed: false, t: 20, boom: false }); },
    update(k, dt) {
      const b = k.bomb, g = G();
      if (!b || !b.armed || b.boom) return;
      b.t -= dt;
      if (b.t > 0) { if (Math.floor(b.t * 2) !== Math.floor((b.t + dt) * 2) && b.t < 6) C.sfx('empty'); return; }
      b.boom = true;
      if (M.id === k.site) explode(b);
      else { g.shake = Math.max(g.shake, 3); g.fx.addFloat(g.player.x, g.player.y - 16, 'BOUM. AU LOIN, UN BÂTIMENT FLAMBE.', '#ff7a1a'); }
      // le bâtiment est rasé : plus personne à l'intérieur
      const site = g.sites[k.site];
      if (site) for (const e of site.enemies) if (g.ALIVE(e)) { e.state = 'dead'; e.gibbed = true; }
      win(k);
    },
    acts(k, acts) {
      const g = G(), b = k.bomb;
      if (!b || b.armed || M.id !== k.site || !near(g.player, b, 14)) return;
      g.prompt = null;
      acts.unshift(['MAINTIENS E : BOMBE ' + Math.floor(b.plant / 2 * 100) + ' %', () => {}]);
      if (C.key('KeyE')) {
        b.plant += C.STEP;
        if (b.plant >= 2) { b.armed = true; g.fx.addFloat(b.x, b.y - 12, 'BOMBE ARMÉE · 20 S · DÉGAGE !', '#ff2040'); C.sfx('alarm'); }
      }
    },
    goal(k) { const b = k.bomb; return M.id === k.site && b && !b.armed ? { x: b.x, y: b.y, label: 'GÉNÉRATEUR' } : null; },
    status(k) { const b = k.bomb; return b && b.armed ? (b.boom ? 'BOUM' : 'EXPLOSION DANS ' + Math.ceil(b.t) + ' S') : 'POSE LA BOMBE'; },
  };
  function explode(b) {
    const g = G(), p = g.player, R = 120;
    g.flash = 0.5; g.shake = 9; g.redFlash = 0.3; g.hitstop = 0.12;
    C.sfx('gib'); C.sfx('over');
    for (let i = 0; i < 80; i++) { const a = Math.random() * 6.28, s = 40 + Math.random() * 260; g.fx.part(b.x, b.y, Math.cos(a) * s, Math.sin(a) * s, 0.3 + Math.random() * 0.6, ['#fff2a0', '#ffb02a', '#ff5a1a', '#5a5a62'][(Math.random() * 4) | 0], 'spark'); }
    if (C.render) for (let i = 0; i < 6; i++) C.render.splat(b.x + (Math.random() - 0.5) * 50, b.y + (Math.random() - 0.5) * 50, 8);
    for (const e of g.enemies) if (g.ALIVE(e) && C.dist(e.x, e.y, b.x, b.y) < R) g.fx.hitEnemy(e, 999, Math.atan2(e.y - b.y, e.x - b.x));
    const d = C.dist(p.x, p.y, b.x, b.y);
    if (d < R) g.fx.hurtPlayer(Math.round(90 * (1 - d / R)) + 10, Math.atan2(p.y - b.y, p.x - b.x));
  }

  // ---------- vol de voiture ----------
  // Une voiture de luxe dorée attend dans un quartier : la voler et la livrer au point de dépôt du même quartier.
  const carsteal = {
    street: true,   // le contrat se joue dans la rue d'un quartier, pas dans un bâtiment
    setup(k) {
      const g = G(), p = g.player;
      const parked = g.cars.filter(c => !c.ai && !c.own && !c.police && C.dist(c.x, c.y, p.x, p.y) > 160);
      const car = parked.length ? parked[(Math.random() * parked.length) | 0] : null;
      if (!car) return;
      Object.assign(car, { model: 'turbo', color: '#c9a227', target: true, parked: true });
      k.car = car;
      // point de dépôt : un bout de trottoir loin de la voiture
      let best = null;
      for (let i = 0; i < 300; i++) {
        const tx = (Math.random() * M.MW) | 0, ty = (Math.random() * M.MH) | 0;
        if (M.tile(tx, ty) !== 's' || M.blocked(tx, ty)) continue;
        const x = tx * 8 + 4, y = ty * 8 + 4, d = C.dist(x, y, car.x, car.y);
        if (d > 280 && (!best || Math.abs(d - 380) < Math.abs(best.d - 380))) best = { x, y, d };
      }
      k.drop = best || { x: p.x, y: p.y };
    },
    update(k) {
      const g = G(), car = k.car;
      if (!car || M.id !== k.site) return;
      if (near(car, k.drop, 30) && Math.abs(car.speed || 0) < 20) {
        if (g.drive === car) g.fx.addFloat(car.x, car.y - 14, 'LIVRÉE. SORS ET VA-T\'EN.', '#5dff9a');
        car.target = false; car.delivered = true;
        win(k);
      }
    },
    goal(k) {
      if (!k.car || M.id !== k.site) return null;
      return G().drive === k.car ? { x: k.drop.x, y: k.drop.y, label: 'DÉPÔT' } : { x: k.car.x, y: k.car.y, label: 'VOITURE' };
    },
    status(k) { return !k.car ? 'VA DANS LE QUARTIER' : G().drive === k.car ? 'LIVRE-LA AU DÉPÔT' : 'VOLE LA VOITURE DORÉE'; },
  };

  CT.TYPES = { heist, extract, sabotage, carsteal };
  CT.is = k => !!(k && CT.TYPES[k.type]);
  CT.isStreet = type => !!(CT.TYPES[type] && CT.TYPES[type].street);

  // Appelé à l'entrée sur une carte : les contrats de bâtiment se préparent dans spawnSite,
  // le vol de voiture à la première visite du quartier.
  CT.setupSite = (k, def) => { if (CT.is(k) && !CT.TYPES[k.type].street && !k.ready) { k.ready = true; CT.TYPES[k.type].setup(k, def); } };
  CT.onEnter = function (from, to, before) {
    const k = G().contract;
    if (!CT.is(k) || k.done || k.failed) return;
    const T = CT.TYPES[k.type];
    if (T.travel) T.travel(k, from, to, before);
    if (T.street && to === k.site && !k.ready) { k.ready = true; T.setup(k, M.def); }
  };
  CT.update = function (dt) { const k = G().contract; if (CT.is(k) && !k.done && !k.failed) CT.TYPES[k.type].update(k, dt); };
  CT.acts = function (acts) { const k = G().contract; if (CT.is(k) && !k.done && !k.failed && CT.TYPES[k.type].acts) CT.TYPES[k.type].acts(k, acts); };
  CT.goal = function () { const k = G().contract; return CT.is(k) && !k.done && !k.failed ? CT.TYPES[k.type].goal(k) : null; };
  CT.status = k => CT.TYPES[k.type].status(k);
  CT.hostage = () => { const k = G().contract; return k && k.hostage && k.hostage.free && !k.hostage.dead && k.hostage.map === M.id ? k.hostage : null; };
  CT.hurtHostage = function (h, dmg, ang) {
    const g = G();
    h.hp -= dmg; h.hurtT = 0.12;
    g.fx.blood(h.x, h.y, ang, 6);
    if (h.hp <= 0) { h.dead = true; h.downAng = ang; g.fx.blood(h.x, h.y, ang, 14); C.sfx('down'); }
    else C.sfx('hurt');
  };

  // ---------- dessin ----------
  CT.drawFloor = function (g, t, drawChar) {
    const k = G().contract;
    if (!CT.is(k)) return;
    if (k.pkg && !k.pkg.taken && M.id === k.site) {
      // le colis : une mallette dans un coffre ouvert
      const x = Math.round(k.pkg.x), y = Math.round(k.pkg.y);
      g.fillStyle = '#05050a'; g.fillRect(x - 5, y - 3, 10, 7);
      g.fillStyle = '#2a2d36'; g.fillRect(x - 4, y - 2, 8, 5);
      g.fillStyle = '#c9a227'; g.fillRect(x - 2, y - 1, 4, 3); g.fillStyle = '#f2d43a'; g.fillRect(x - 1, y - 2, 2, 1);
    }
    const h = k.hostage;
    if (h && h.dead && h.map === M.id) drawChar(g, h.x, h.y, h.downAng || 0, Object.assign({}, h.outfit, { jacket: '#6a6a6a', pose: 'down', shadow: false }));
    if (k.bomb && M.id === k.site && !k.bomb.boom) {
      // générateur, puis la bombe posée dessus
      const x = Math.round(k.bomb.x), y = Math.round(k.bomb.y);
      g.fillStyle = '#05050a'; g.fillRect(x - 6, y - 5, 12, 10);
      g.fillStyle = '#3a4250'; g.fillRect(x - 5, y - 4, 10, 8);
      g.fillStyle = '#ffd23e'; g.fillRect(x - 5, y - 4, 10, 1);
      if (k.bomb.armed) { g.fillStyle = '#1a1a1e'; g.fillRect(x - 3, y - 2, 6, 4); g.fillStyle = Math.sin(t * (k.bomb.t < 5 ? 30 : 10)) > 0 ? '#ff2040' : '#5a1020'; g.fillRect(x - 1, y - 1, 2, 2); }
    }
  };
  CT.drawActors = function (g, t, drawChar) {
    const k = G().contract, h = k && k.hostage;
    if (!h || h.dead || h.map === undefined && M.id !== k.site) return;
    if ((h.map || k.site) !== M.id) return;
    drawChar(g, h.x, h.y, h.aim, Object.assign({}, h.outfit, { jacket: '#c7c7c7', pose: h.free ? 'bare' : 'sit', flash: h.hurtT > 0, frame: C.sprites.walkFrame(h.walk, h.moving) }));
  };
  CT.drawTags = function (g, t, tag) {
    const k = G().contract;
    if (!CT.is(k) || k.done || k.failed) return;
    const gl = CT.goal();
    if (gl) {
      // losange jaune au-dessus de l'objectif
      const x = Math.round(gl.x), y = Math.round(gl.y) - 18 + Math.round(Math.sin(t * 5) * 1.5);
      g.fillStyle = '#ffd23e';
      g.fillRect(x, y - 2, 1, 1); g.fillRect(x - 1, y - 1, 3, 1); g.fillRect(x - 2, y, 5, 1); g.fillRect(x - 1, y + 1, 3, 1); g.fillRect(x, y + 2, 1, 1);
    }
    const h = k.hostage;
    if (h && !h.dead && (h.map || k.site) === M.id) tag(h.x, h.y, h.nom + ' · OTAGE', '#ffffff');
    if (k.car && M.id === k.site && G().drive !== k.car) tag(k.car.x, k.car.y - 4, 'CIBLE', '#ffd23e');
    if (k.drop && M.id === k.site) {
      // zone de dépôt : cadre jaune au sol
      const x = Math.round(k.drop.x), y = Math.round(k.drop.y), s = 14 + Math.round(Math.sin(t * 4) * 2);
      g.fillStyle = 'rgba(255,210,62,0.5)';
      g.fillRect(x - s, y - s, s * 2, 1); g.fillRect(x - s, y + s, s * 2, 1); g.fillRect(x - s, y - s, 1, s * 2); g.fillRect(x + s, y - s, 1, s * 2 + 1);
      tag(k.drop.x, k.drop.y, 'DÉPÔT', '#ffd23e');
    }
  };
})();
