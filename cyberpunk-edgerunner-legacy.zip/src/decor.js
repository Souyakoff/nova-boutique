'use strict';
// Décor des quartiers : arbres, étals, toris, fontaine, épaves, bidons en feu, hologrammes...
//
// Un élément de décor est {k, x, y, ...} en tuiles (listé dans props d'une carte, voir districts.js).
//   foot(p)              cases qu'il occupe (bloquent persos, balles et voitures ; le reste du dessin déborde)
//   drawStatic(g, p)     dessiné une fois dans l'image de la carte (sous l'éclairage)
//   drawDynamic(g, p, t) dessiné à chaque image par-dessus l'éclairage : flammes, hologrammes, jets d'eau...
(function () {
  const C = CEL;
  const D = (C.decor = {});
  const hash = (x, y, i = 0) => { let h = (x * 374761393 + y * 668265263 + i * 2147483647) | 0; h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; };
  const rect = (g, c, x, y, w, h) => { g.fillStyle = c; g.fillRect(Math.round(x), Math.round(y), w, h); };
  const disc = (g, c, cx, cy, r, sy = 1) => {
    g.fillStyle = c;
    for (let dy = -Math.ceil(r * sy); dy <= Math.ceil(r * sy); dy++) {
      const w = Math.round(Math.sqrt(Math.max(0, r * r - (dy / sy) ** 2)));
      if (w > 0 || Math.abs(dy) < r * sy) g.fillRect(Math.round(cx - w), Math.round(cy + dy), w * 2 + 1, 1);
    }
  };
  const shadow = (g, x, y, w, h) => rect(g, 'rgba(0,0,0,0.35)', x + 2, y + 2, w, h);

  D.foot = function (p) {
    const { x, y } = p;
    switch (p.k) {
      case 'stall': case 'bench': return [[x, y], [x + 1, y]];
      case 'tent': return [[x, y], [x + 1, y], [x, y + 1], [x + 1, y + 1]];
      case 'shrine': { const f = []; for (let i = 0; i < 3; i++) for (let j = 0; j < 2; j++) f.push([x + i, y + j]); return f; }
      case 'torii': return p.dir === 'v' ? [[x, y], [x, y + p.len - 1]] : [[x, y], [x + p.len - 1, y]];
      case 'bus': { const f = [], w = p.dir === 'v' ? 2 : 5, h = p.dir === 'v' ? 5 : 2; for (let i = 0; i < w; i++) for (let j = 0; j < h; j++) f.push([x + i, y + j]); return f; }
      case 'holo': return p.solid ? [[x, y]] : [];
      case 'lantern': case 'fountain': return [];
      default: return [[x, y]];   // vending, junk, barrel, planter, tree, sakura, palm
    }
  };

  // ---------- dessin fixe ----------
  D.drawStatic = function (g, p) {
    const X = p.x * 8, Y = p.y * 8, cx = X + 4, cy = Y + 4;
    switch (p.k) {
      case 'vending': {
        const red = hash(p.x, p.y) < 0.6;
        shadow(g, X, Y + 1, 8, 7);
        rect(g, red ? '#8a1020' : '#1a3a8a', X, Y, 8, 7);
        rect(g, red ? '#c4142b' : '#2a6fdb', X, Y, 8, 2);
        rect(g, '#0a0a12', X + 1, Y + 3, 4, 3);
        rect(g, '#bfe9ff', X + 6, Y + 3, 1, 2);
        rect(g, '#05050a', X, Y + 7, 8, 1);
        break;
      }
      case 'junk': {
        disc(g, 'rgba(0,0,0,0.35)', cx + 1, cy + 2, 4, 0.6);
        disc(g, '#1a1e1a', cx - 1, cy + 1, 3);
        disc(g, '#222a22', cx + 2, cy, 3);
        rect(g, '#3a443a', cx + 1, cy - 2, 2, 1);
        if (hash(p.x, p.y, 3) < 0.5) rect(g, '#6a5a3a', cx - 3, cy + 3, 2, 1);
        break;
      }
      case 'barrel': {
        disc(g, 'rgba(0,0,0,0.4)', cx + 1, cy + 2, 4, 0.6);
        disc(g, '#3a2414', cx, cy, 3.5);
        disc(g, '#5a3a22', cx, cy, 2.5);
        disc(g, '#1a0a04', cx, cy, 1.5);
        rect(g, '#7a5a3a', cx - 3, cy - 1, 1, 2);
        break;
      }
      case 'holo': {
        disc(g, '#0a0a12', cx, cy + 2, 3, 0.6);
        rect(g, '#2d3150', cx - 2, cy + 1, 5, 2);
        rect(g, p.c, cx, cy + 1, 1, 1);
        break;
      }
      case 'planter': {
        shadow(g, X, Y, 8, 8);
        rect(g, '#4a4e5a', X, Y, 8, 8);
        rect(g, '#5e6272', X, Y, 8, 1);
        rect(g, '#1e3a24', X + 1, Y + 1, 6, 6);
        disc(g, '#2a6a3a', cx, cy, 2.5);
        rect(g, '#3a8a4a', cx - 1, cy - 2, 2, 1);
        break;
      }
      case 'tree': {
        disc(g, 'rgba(0,0,0,0.35)', cx + 3, cy + 3, 7, 0.7);
        disc(g, '#1a1414', cx, cy, 3);   // grille au pied
        disc(g, '#1e4a2a', cx + 1, cy + 1, 7);
        disc(g, '#2a6a3a', cx, cy, 6);
        disc(g, '#3a8a4a', cx - 2, cy - 2, 3);
        for (let i = 0; i < 6; i++) rect(g, '#4aa05a', cx - 5 + ((hash(p.x, p.y, i) * 10) | 0), cy - 5 + ((hash(p.x, p.y, i + 7) * 10) | 0), 1, 1);
        break;
      }
      case 'sakura': {
        // pétales tombés au sol autour de l'arbre
        for (let i = 0; i < 26; i++) {
          const a = hash(p.x, p.y, i) * 6.28, r = 6 + hash(p.x, p.y, i + 40) * 9;
          rect(g, hash(p.x, p.y, i + 80) < 0.5 ? '#ff9ad8' : '#d66aa8', cx + Math.cos(a) * r, cy + Math.sin(a) * r * 0.8, 1, 1);
        }
        disc(g, 'rgba(0,0,0,0.35)', cx + 3, cy + 3, 9, 0.7);
        rect(g, '#3a2018', cx - 1, cy, 3, 4);
        disc(g, '#b04a88', cx + 1, cy + 1, 9);
        disc(g, '#e070b0', cx, cy - 1, 8);
        disc(g, '#ff9ad8', cx - 2, cy - 3, 5);
        disc(g, '#ffc8e8', cx - 3, cy - 4, 2);
        for (let i = 0; i < 10; i++) rect(g, '#ffe0f0', cx - 7 + ((hash(p.x, p.y, i + 3) * 14) | 0), cy - 7 + ((hash(p.x, p.y, i + 13) * 13) | 0), 1, 1);
        break;
      }
      case 'palm': {
        disc(g, 'rgba(0,0,0,0.3)', cx + 7, cy + 5, 9, 0.5);
        // tronc courbé, du pied vers la couronne
        for (let i = 0; i <= 10; i++) rect(g, i % 2 ? '#7a5a34' : '#5a3a20', cx + Math.round(i * 0.45), cy + 3 - i, 2, 1);
        const kx = cx + 4, ky = cy - 8;
        // palmes : deux tons, épaisses près du cœur, qui retombent vers le bout
        for (let f = 0; f < 7; f++) {
          const a = f * 0.9 + 0.2 + hash(p.x, p.y, f) * 0.3;
          for (let r = 1; r <= 11; r++) {
            const droop = r * r * 0.05, x = kx + Math.cos(a) * r, y = ky + Math.sin(a) * r * 0.75 + droop;
            rect(g, r > 8 ? '#2e5a20' : '#4a8a32', x, y, r < 7 ? 2 : 1, 1);
            if (r % 3 === 0) rect(g, '#6aa844', x - Math.sin(a), y + Math.cos(a), 1, 1);   // folioles
          }
        }
        rect(g, '#5a3a20', kx - 1, ky, 3, 2); rect(g, '#7a5a34', kx, ky, 1, 1);   // noix de coco
        break;
      }
      case 'bench': {
        shadow(g, X, Y + 2, 16, 4);
        rect(g, '#2a2d36', X + 1, Y + 6, 1, 2); rect(g, '#2a2d36', X + 14, Y + 6, 1, 2);
        rect(g, '#5a4030', X, Y + 2, 16, 2);
        rect(g, '#6e5038', X, Y + 4, 16, 2);
        rect(g, '#3a2a1e', X, Y + 6, 16, 1);
        break;
      }
      case 'stall': {
        // étal de rue : auvent rayé, comptoir et marchandises
        shadow(g, X, Y, 16, 8);
        rect(g, '#2a1a14', X, Y + 5, 16, 3);
        for (let i = 0; i < 4; i++) rect(g, ['#ff3ec8', '#f2d43a', '#5dff9a', '#3ef0ff', '#ff7a1a'][(hash(p.x, p.y, i) * 5) | 0], X + 2 + i * 3, Y + 6, 2, 1);
        for (let i = 0; i < 8; i++) rect(g, i % 2 ? p.c : '#e8e8f0', X + i * 2, Y, 2, 5);
        rect(g, 'rgba(0,0,0,0.25)', X, Y + 3, 16, 2);
        rect(g, '#05050a', X, Y + 5, 16, 1);
        break;
      }
      case 'lantern': {
        // le fil tendu en travers de la rue commerçante
        for (let yy = Y - 14; yy < Y + 22; yy += 1) if (yy % 3) rect(g, '#14101a', cx, yy, 1, 1);
        break;
      }
      case 'torii': {
        const v = p.dir === 'v', L = (p.len - 1) * 8;
        const ax = cx, ay = cy, bx = v ? cx : cx + L, by = v ? cy + L : cy;
        // poutres : le kasagi noir déborde, le nuki rouge en dessous
        if (v) { rect(g, 'rgba(0,0,0,0.35)', ax + 1, ay - 4, 5, L + 10); rect(g, '#1a0808', ax - 3, ay - 5, 5, L + 10); rect(g, '#c4142b', ax + 2, ay - 2, 2, L + 4); rect(g, '#e8303a', ax - 2, ay - 5, 1, L + 10); }
        else { rect(g, 'rgba(0,0,0,0.35)', ax - 4, ay + 1, L + 10, 5); rect(g, '#1a0808', ax - 5, ay - 3, L + 10, 5); rect(g, '#c4142b', ax - 2, ay + 2, L + 4, 2); rect(g, '#e8303a', ax - 5, ay - 3, L + 10, 1); }
        for (const [x, y] of [[ax, ay], [bx, by]]) { rect(g, '#05050a', x - 3, y - 3, 6, 6); rect(g, '#a01020', x - 2, y - 2, 4, 4); rect(g, '#e8303a', x - 2, y - 2, 4, 1); }
        break;
      }
      case 'shrine': {
        shadow(g, X - 2, Y - 2, 28, 20);
        rect(g, '#05050a', X - 3, Y - 3, 30, 22);
        rect(g, '#2a1416', X - 2, Y - 2, 28, 20);
        // toit à deux pans : tuiles en rangées, faîtage doré
        for (let yy = 0; yy < 20; yy += 2) rect(g, yy < 9 ? '#3a1c1e' : '#2a1416', X - 2, Y - 2 + yy, 28, 1);
        rect(g, '#c9a227', X - 2, Y + 7, 28, 2);
        rect(g, '#f2d43a', X + 10, Y + 6, 4, 4);
        for (const [x, y] of [[X - 2, Y - 2], [X + 24, Y - 2], [X - 2, Y + 16], [X + 24, Y + 16]]) rect(g, '#c4142b', x, y, 2, 2);
        break;
      }
      case 'fountain': {
        // margelle de pierre autour du bassin, colonne au centre
        for (let a = 0; a < 6.28; a += 0.04) {
          const x = cx + Math.cos(a) * 30, y = cy + Math.sin(a) * 21;
          rect(g, '#6a6e7c', x, y, 2, 2);
          rect(g, '#8a8e9c', x, y, 1, 1);
        }
        disc(g, '#4a4e5c', cx, cy, 4);
        disc(g, '#7a7e8c', cx, cy, 2);
        break;
      }
      case 'bus': {
        const v = p.dir === 'v', w = v ? 16 : 40, h = v ? 40 : 16;
        shadow(g, X, Y, w, h);
        rect(g, '#05050a', X - 1, Y - 1, w + 2, h + 2);
        rect(g, '#6a5a24', X, Y, w, h);
        rect(g, '#4a3e18', X + (v ? 0 : 0), Y + (v ? h - 4 : 0), v ? w : 4, v ? 4 : h);
        // vitres brisées le long du toit, taches de rouille et de brûlé
        for (let i = 0; i < 6; i++) {
          const k = hash(p.x, p.y, i);
          if (v) rect(g, k < 0.4 ? '#0a0a10' : '#26344e', X + 2, Y + 3 + i * 6, 12, 3);
          else rect(g, k < 0.4 ? '#0a0a10' : '#26344e', X + 3 + i * 6, Y + 2, 3, 12);
        }
        for (let i = 0; i < 9; i++) rect(g, hash(p.x, p.y, i + 20) < 0.5 ? '#3a2a14' : '#1a1410', X + hash(p.x, p.y, i + 30) * (w - 4), Y + hash(p.x, p.y, i + 40) * (h - 4), 3, 2);
        break;
      }
      case 'tent': {
        shadow(g, X, Y, 16, 16);
        rect(g, '#05050a', X - 1, Y, 18, 16);
        rect(g, '#2a4a6a', X, Y + 1, 8, 14);
        rect(g, '#1e3a56', X + 8, Y + 1, 8, 14);
        rect(g, '#3a5a7a', X + 7, Y + 1, 2, 14);   // arête
        rect(g, '#6a5a3a', X + 3, Y + 5, 3, 3);    // rapiéçage
        rect(g, '#0a0a10', X + 6, Y + 13, 4, 3);   // entrée
        break;
      }
    }
  };

  // ---------- éléments animés (par-dessus l'éclairage : ils brillent dans le noir) ----------
  D.drawDynamic = function (g, p, t) {
    const X = p.x * 8, Y = p.y * 8, cx = X + 4, cy = Y + 4, ph = hash(p.x, p.y, 9) * 10;
    switch (p.k) {
      case 'barrel': {
        // flammes qui dansent au-dessus du bidon
        for (let i = 0; i < 7; i++) {
          const k = (t * 3 + i * 0.37 + ph) % 1, x = cx - 2 + ((i * 5) % 5) + Math.sin(t * 9 + i) * 0.8, y = cy - 1 - k * 7;
          rect(g, k < 0.3 ? '#fff2a0' : k < 0.65 ? '#ffb02a' : '#ff5a1a', x, y, 1, k < 0.5 ? 2 : 1);
        }
        if (Math.sin(t * 2 + ph) > 0.6) rect(g, '#5a5a62', cx + Math.sin(t * 3) * 2, cy - 10 - ((t * 6) % 6), 1, 1);   // fumée
        break;
      }
      case 'holo': {
        // hologramme publicitaire : un carpe koï ou un anneau qui tourne, en lignes de balayage
        if (p.broken && Math.sin(t * 13 + ph) > 0.3) break;
        g.globalAlpha = 0.55 + 0.2 * Math.sin(t * 7 + ph);
        const by = cy - 12 + Math.sin(t * 1.5 + ph) * 1.5;
        if (hash(p.x, p.y, 2) < 0.5) {
          // koï : corps qui ondule
          for (let i = 0; i < 12; i++) {
            const x = cx - 6 + i, w = Math.round(3 - Math.abs(i - 4) * 0.4);
            const y = by + Math.sin(t * 4 + i * 0.6) * 1.2;
            if (w > 0 && ((Math.round(y) + Math.floor(t * 20)) % 3)) rect(g, i < 3 ? '#ffffff' : p.c, x, y - w / 2, 1, Math.max(1, w));
          }
        } else {
          // anneau en rotation
          for (let a = 0; a < 6.28; a += 0.3) {
            const x = cx + Math.cos(a + t * 2) * 6, y = by + Math.sin(a) * 2.5;
            rect(g, Math.cos(a + t * 2) > 0 ? '#ffffff' : p.c, x, y, 1, 1);
          }
          rect(g, p.c, cx - 1, by - 1, 3, 3);
        }
        g.globalAlpha = 0.25;
        rect(g, p.c, cx, by + 2, 1, 10);   // faisceau du projecteur
        g.globalAlpha = 1;
        break;
      }
      case 'lantern': {
        const sw = Math.round(Math.sin(t * 1.7 + ph) * 1);
        rect(g, '#05050a', cx - 2 + sw, cy - 3, 5, 7);
        rect(g, '#c4142b', cx - 1 + sw, cy - 2, 3, 5);
        rect(g, Math.sin(t * 5 + ph) > -0.8 ? '#ffb02a' : '#ff5a1a', cx + sw, cy - 1, 1, 3);
        rect(g, '#1a0808', cx - 1 + sw, cy - 3, 3, 1);
        break;
      }
      case 'fountain': {
        // jets et gouttes, cercles concentriques
        for (let i = 0; i < 14; i++) {
          const k = (t * 1.2 + i / 14) % 1, a = i * 0.45 + ph, r = k * 16;
          rect(g, k < 0.5 ? '#e8faff' : '#7ff6ff', cx + Math.cos(a) * r, cy + Math.sin(a) * r * 0.7 - Math.sin(k * Math.PI) * 6, 1, 1);
        }
        const r = (t * 8) % 18;
        g.globalAlpha = 1 - r / 18;
        for (let a = 0; a < 6.28; a += 0.25) rect(g, '#7ff6ff', cx + Math.cos(a) * r, cy + Math.sin(a) * r * 0.7, 1, 1);
        g.globalAlpha = 1;
        break;
      }
      case 'sakura': {
        // quelques pétales qui tombent
        for (let i = 0; i < 3; i++) {
          const k = (t * 0.25 + i / 3 + ph) % 1;
          rect(g, '#ffc8e8', cx - 6 + i * 6 + Math.sin(t * 2 + i) * 3, cy - 6 + k * 16, 1, 1);
        }
        break;
      }
      case 'vending': {
        if (Math.sin(t * 3 + ph) > -0.9) rect(g, hash(p.x, p.y) < 0.6 ? '#ff4d6d' : '#7ff6ff', X + 1, Y, 6, 1);
        break;
      }
    }
  };
})();
