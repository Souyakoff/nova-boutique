'use strict';
// Héritage : la ville se souvient des leaders passés. Sauvegarde dans le navigateur (localStorage, clé « cel-ville »).
//
// city = {
//   v, gen,                       // version du format, nombre de leaders terminés
//   leaders: [{nom, origine, lien, fin, gigs, acheves, epargnes, temps}],   // mur des légendes
//   spared:  [{slot, site, type, nom, by, attitude: 'allie'|'rival', used}], // ennemis épargnés qui reviendront
//   corpse:  {site, nom, inj, eddies, taken} | null,     // corps du dernier leader mort, jeté devant le bâtiment (site)
//   psycho:  {site, nom, defeated, implants} | null,      // il rôde dans le bâtiment du prochain contrat                                  // dernier leader passé en cyberpsychose
//   companions: [{nom, origine, loyalty, by, used}],                         // compagnons qui ont survécu à leur leader
//   fixer:   {nom, stars, faction} | null,                                    // dernier leader devenu fixer (il donne les contrats)
//   rep:     {gang: -100..100},                                               // les gangs se souviennent de ce que tu leur as fait
// }
(function () {
  const C = CEL;
  const KEY = 'cel-ville';
  const HANDLES = ['KIRO', 'VEXA', 'NYX', 'KAZ', 'DEX', 'MIRA', 'TAK', 'JUNO', 'REX', 'SABLE', 'LUX', 'VALE', 'ZED', 'KODA', 'RAINE', 'OSKO', 'PIX', 'TESS', 'BRIX', 'NOVA', 'KANE', 'IZZY'];
  const THUGS = ['GROS TONY', 'LE BIGLE', 'MARCO', 'SKID', 'LA FOUINE', 'DUKE', 'PETIT LOU', 'RAZ', 'FENTO', 'BOLT', 'MOUSSE', 'ZAZA', 'TIC', 'GRIMM', 'NACHO', 'BEBEL'];
  // Les choix d'héritage utilisent Math.random : C.rand est rejoué à l'identique à chaque gig.
  const pick = list => list[(Math.random() * list.length) | 0];

  const L = (C.legacy = {});

  L.ORIGINS = [
    { id: 'rue', nom: 'GOSSE DES RUES', perk: '+15% VITESSE', apply: p => { p.speedMul = 1.15; } },
    { id: 'nomade', nom: 'NOMADE', perk: '+25 PV', apply: p => { p.maxHp += 25; p.hp += 25; } },
    { id: 'corpo', nom: 'CORPO DÉCHU', perk: '+1 INJECTEUR', apply: p => { p.maxInj += 1; p.inj += 1; } },
  ];
  L.origin = id => L.ORIGINS.find(o => o.id === id) || L.ORIGINS[0];

  L.blank = () => ({ v: 1, gen: 0, leaders: [], spared: [], corpse: null, psycho: null, companions: [], fixer: null, rep: {} });
  L.load = () => {
    try {
      const d = JSON.parse(localStorage.getItem(KEY) || 'null');
      if (d && d.v === 1) return Object.assign(L.blank(), d);
    } catch (e) { /* sauvegarde illisible : on repart d'une ville vierge */ }
    return L.blank();
  };
  L.save = () => { try { localStorage.setItem(KEY, JSON.stringify(L.city)); } catch (e) { /* pas de stockage */ } };
  L.wipe = () => { L.city = L.blank(); L.save(); };
  L.city = L.load();

  L.thugName = () => pick(THUGS);

  // Trois profils au choix, un par origine. Avec un leader précédent, certains ont un lien avec lui.
  L.profiles = () => {
    const used = new Set(L.city.leaders.map(l => l.nom));
    const name = () => {
      for (let i = 0; i < 60; i++) { const n = pick(HANDLES); if (!used.has(n)) { used.add(n); return n; } }
      return 'ANON-' + ((Math.random() * 99) | 0);
    };
    const prev = L.city.leaders[L.city.leaders.length - 1];
    const links = prev ? ['FRÈRE DE ' + prev.nom, 'ANCIEN RIVAL DE ' + prev.nom, 'A GRANDI AVEC ' + prev.nom] : [];
    const cards = L.ORIGINS.map((o, i) => ({ nom: name(), origine: o.id, lien: prev && Math.random() < 0.6 ? links[i] : null }));
    // un ancien compagnon peut prendre la tête : il remplace la carte de son origine
    const ex = L.city.companions.find(c => !c.used);
    if (ex) {
      const i = Math.max(0, L.ORIGINS.findIndex(o => o.id === ex.origine));
      cards[i] = { nom: ex.nom, origine: ex.origine, lien: 'EX-ÉQUIPIER DE ' + ex.by, companion: true };
    }
    return cards;
  };

  // Recrue qui attend dans la planque : un ancien compagnon de la ville s'il y en a un, sinon un mercenaire.
  L.recruitCandidate = (leader) => {
    const ex = L.city.companions.find(c => !c.used && c.nom !== leader.nom);
    if (ex) return { nom: ex.nom, origine: ex.origine, loyalty: Math.min(100, ex.loyalty + 15), lien: 'EX-ÉQUIPIER DE ' + ex.by, record: ex };
    const used = new Set(L.city.leaders.map(l => l.nom).concat([leader.nom]));
    let nom = pick(HANDLES);
    for (let i = 0; i < 60 && used.has(nom); i++) nom = pick(HANDLES);
    return { nom, origine: pick(L.ORIGINS).id, loyalty: null, lien: 'MERCENAIRE', record: null };
  };
  L.useCompanion = nom => {
    const ex = L.city.companions.find(c => !c.used && c.nom === nom);
    if (ex) { ex.used = true; L.save(); }
  };

  // Un ennemi épargné par ce leader : il reviendra au prochain leader, en allié (70 %) ou en rival (30 %).
  // site = bâtiment où il a été épargné : un rival y reviendra ; un allié attendra devant la planque.
  L.spareRecord = (slot, e, leader, site) => ({
    slot, site, type: e.type, nom: e.nom, by: leader.nom, attitude: Math.random() < 0.7 ? 'allie' : 'rival', used: false,
  });

  // Fin d'un leader : on l'inscrit au mur, on transmet ses épargnés, et il laisse son corps ou devient un cyberpsycho.
  L.endLeader = (G, reason) => {
    const c = L.city, ld = G.leader, p = G.player;
    c.gen++;
    c.leaders.push({
      nom: ld.nom, origine: ld.origine, lien: ld.lien, fin: reason, gigs: ld.gigs,
      acheves: G.reg.acheves, epargnes: G.reg.epargnes, temps: Math.round(G.reg.temps),
    });
    if (c.leaders.length > 20) c.leaders.shift();
    c.spared = c.spared.filter(s => !s.used).concat(ld.spared).slice(-6);
    // le compagnon survit à son leader s'il est debout ; à terre, il ne s'en relève pas
    if (G.comp && G.comp.state === 'up') {
      c.companions = (c.companions || []).filter(x => !x.used);
      c.companions.push({ nom: G.comp.nom, origine: G.comp.origine, loyalty: Math.round(G.comp.loyalty), by: ld.nom, used: false });
      c.companions = c.companions.slice(-4);
    }
    const chrome = Object.keys(ld.implants || {}).filter(s => !(C.DEF.implants[ld.implants[s]] || {}).base).length;
    const site = C.map.id;
    if (reason === 'psycho') c.psycho = { site, nom: ld.nom, defeated: false, implants: chrome };
    else if (reason === 'fixer') c.fixer = { nom: ld.nom, stars: G.fixerStars, faction: ld.grandFaction };
    else if (reason !== 'disparu') c.corpse = { site, nom: ld.nom, inj: p.inj, eddies: Math.floor((ld.eddies || 0) / 2), taken: false };
    L.save();
  };
})();
