'use strict';
// Compétences : chaque leader gagne de l'expérience (mises à terre, exécutions, contrats, piratages),
// monte de niveau et dépense ses points dans un arbre à 4 branches de 4 compétences.
// Dans une branche, il faut la compétence du dessus pour prendre celle du dessous.
// K ouvre l'arbre (le jeu se met en pause). Les effets passent par G.mods (refreshMods) ou par quelques
// crochets dans game.js et netrun.js (soin sur mise à terre, second souffle, contagion).
(function () {
  const C = CEL, D = C.DEF;
  const SK = (C.skills = {});
  const G = () => C.game;

  SK.BRANCHES = [
    { id: 'gun', nom: 'FLINGUE', color: '#ffd23e', perks: [
      { id: 'gun1', nom: 'MAIN SÛRE', desc: 'DISPERSION -30 %.', mods: m => { m.spreadMul *= 0.7; } },
      { id: 'gun2', nom: 'RECHARGE ÉCLAIR', desc: 'RECHARGEMENT 40 % PLUS RAPIDE.', mods: m => { m.reloadMul *= 0.6; } },
      { id: 'gun3', nom: 'BALLES LOURDES', desc: '+25 % DE DÉGÂTS AUX ARMES À FEU.', mods: m => { m.gunDmg *= 1.25; } },
      { id: 'gun4', nom: 'TIR RAPIDE', desc: 'CADENCE DE TIR +30 %.', mods: m => { m.rateMul *= 0.77; } },
    ] },
    { id: 'blade', nom: 'LAME', color: '#ff3ec8', perks: [
      { id: 'blade1', nom: 'TRANCHANT', desc: '+30 % DE DÉGÂTS AU CORPS À CORPS.', mods: m => { m.blade *= 1.3; } },
      { id: 'blade2', nom: 'ALLONGE', desc: 'PORTÉE ET ARC DE LA LAME AUGMENTÉS.', mods: m => { m.bladeRange += 5; m.bladeArc += 0.3; } },
      { id: 'blade3', nom: 'DANSE DES LAMES', desc: 'COUPS 35 % PLUS RAPPROCHÉS.', mods: m => { m.meleeCd *= 0.65; } },
      { id: 'blade4', nom: 'LAME VAMPIRE', desc: 'CHAQUE COUP DE LAME QUI TOUCHE RENDRA 4 PV.', mods: m => { m.bladeHeal = 4; } },
    ] },
    { id: 'net', nom: 'NETRUNNER', color: '#d4f542', perks: [
      { id: 'net1', nom: 'MÉMOIRE VIVE', desc: '+2 RAM.', mods: m => { m.ramMax += 2; } },
      { id: 'net2', nom: 'COMPILATEUR', desc: 'QUICKHACKS ENVOYÉS 25 % PLUS VITE.', mods: m => { m.upload *= 0.75; } },
      { id: 'net3', nom: 'REFROIDISSEMENT', desc: 'LA RAM SE RECHARGE 50 % PLUS VITE.', mods: m => { m.ramRegen *= 1.5; } },
      { id: 'net4', nom: 'CONTAGION', desc: 'COURT-CIRCUIT ET SURCHAUFFE SAUTENT SUR UN 2E ENNEMI.', mods: m => { m.contagion = true; } },
    ] },
    { id: 'surv', nom: 'SURVIE', color: '#5dff9a', perks: [
      { id: 'surv1', nom: 'PEAU DURE', desc: '+20 PV MAX.', once: p => { p.maxHp += 20; p.hp += 20; } },
      { id: 'surv2', nom: 'RÉFLEXES', desc: 'DASH DISPONIBLE 30 % PLUS SOUVENT.', mods: m => { m.dashCd *= 0.7; } },
      { id: 'surv3', nom: 'ADRÉNALINE', desc: 'CHAQUE ENNEMI MIS À TERRE REND 6 PV.', mods: m => { m.killHeal = 6; } },
      { id: 'surv4', nom: 'SECOND SOUFFLE', desc: 'UNE FOIS PAR GIG, UN COUP MORTEL TE LAISSE À 1 PV.', mods: m => { m.secondWind = true; } },
    ] },
  ];
  const ALL = {};
  for (const b of SK.BRANCHES) b.perks.forEach((p, i) => { ALL[p.id] = Object.assign(p, { branch: b, tier: i }); });
  SK.ALL = ALL;

  // ---------- expérience ----------
  SK.need = lvl => 120 + 80 * (lvl - 1);   // XP pour passer au niveau suivant
  SK.init = leader => { if (!leader.xp && leader.xp !== 0) Object.assign(leader, { xp: 0, lvl: 1, points: 0, skills: [] }); };
  SK.gain = function (n, x, y) {
    const g = G(), L0 = g.leader;
    if (!L0 || g.mode !== 'play') return;
    SK.init(L0);
    L0.xp += n;
    g.xpFlash = 0.6;
    while (L0.xp >= SK.need(L0.lvl)) {
      L0.xp -= SK.need(L0.lvl); L0.lvl++; L0.points++;
      C.music.event('level');
      g.fx.addFloat(x == null ? g.player.x : x, (y == null ? g.player.y : y) - 18, 'NIVEAU ' + L0.lvl + ' · ' + C.keyLabel('KeyK') + ' COMPÉTENCES', '#ffd23e');
      C.sfx('clear');
    }
  };
  SK.has = id => { const L0 = G().leader; return !!(L0 && L0.skills && L0.skills.includes(id)); };
  // Effets des compétences sur les mods (appelé à la fin de refreshMods).
  SK.apply = function (m) {
    const L0 = G().leader;
    for (const id of (L0 && L0.skills) || []) if (ALL[id].mods) ALL[id].mods(m);
  };
  SK.can = function (id) {
    const L0 = G().leader, p = ALL[id];
    if (SK.has(id)) return 'ACQUISE';
    if (L0.points <= 0) return 'PAS DE POINT';
    if (p.tier > 0 && !SK.has(p.branch.perks[p.tier - 1].id)) return 'PRENDS CELLE DU DESSUS';
    return null;
  };
  SK.take = function (id) {
    const g = G(), L0 = g.leader;
    if (SK.can(id)) return false;
    L0.points--; L0.skills.push(id);
    if (ALL[id].once) ALL[id].once(g.player);
    g.refreshMods();
    C.sfx('hack');
    return true;
  };

  // ---------- écran ----------
  SK.open = function () { SK.init(G().leader); G().skillMenu = { col: 0, row: 0, lmx: C.input.mx, lmy: C.input.my, msg: '', msgT: 0 }; C.sfx('spare'); };
  SK.update = function (dt) {
    const g = G(), s = g.skillMenu, I = C.input;
    s.msgT -= dt;
    if (C.keyHit('Escape') || C.keyHit('KeyK') || I.mhit[2]) { g.skillMenu = null; return; }
    if (C.keyHit('ArrowLeft') || C.keyHit('KeyA')) s.col = (s.col + 3) % 4;
    if (C.keyHit('ArrowRight') || C.keyHit('KeyD')) s.col = (s.col + 1) % 4;
    if (C.keyHit('ArrowUp') || C.keyHit('KeyW')) s.row = (s.row + 3) % 4;
    if (C.keyHit('ArrowDown') || C.keyHit('KeyS')) s.row = (s.row + 1) % 4;
    const hit = SK.cellUnderMouse();
    if (hit && (I.mx !== s.lmx || I.my !== s.lmy)) { s.col = hit[0]; s.row = hit[1]; }
    s.lmx = I.mx; s.lmy = I.my;
    if (C.keyHit('KeyE') || C.keyHit('Enter') || (I.mhit[0] && hit)) {
      const p = SK.BRANCHES[s.col].perks[s.row], why = SK.can(p.id);
      if (why) { s.msg = why; s.msgCol = '#ff5a7a'; s.msgT = 2; C.sfx('empty'); }
      else { SK.take(p.id); s.msg = p.nom + ' ACQUISE.'; s.msgCol = p.branch.color; s.msgT = 2.5; }
    }
  };
  let cells = [];
  SK.cellUnderMouse = () => {
    const { mx, my } = C.input;
    const c = cells.find(([x, y, w, h]) => mx >= x && mx < x + w && my >= y && my < y + h);
    return c ? [c[4], c[5]] : null;
  };
  const T = (g, s, x, y, c, o = {}) => C.text(g, s, x, y, c, Object.assign({ shadow: '#05050a' }, o));
  SK.draw = function (g, time) {
    const gm = G(), s = gm.skillMenu, L0 = gm.leader;
    g.fillStyle = 'rgba(4,3,10,0.85)'; g.fillRect(0, 0, C.W, C.H);
    const w = 304, h = 172, x = Math.round((C.W - w) / 2), y = Math.round((C.H - h) / 2);
    g.fillStyle = '#0b0a16'; g.fillRect(x, y, w, h);
    g.fillStyle = '#ffd23e'; g.fillRect(x, y, w, 1);
    g.fillStyle = '#2d3150'; g.fillRect(x, y + h - 1, w, 1); g.fillRect(x, y, 1, h); g.fillRect(x + w - 1, y, 1, h);
    T(g, L0.nom + ' · NIVEAU ' + L0.lvl, x + 6, y + 6, '#ffffff');
    T(g, L0.points + ' POINT' + (L0.points > 1 ? 'S' : ''), x + w - 6, y + 6, L0.points ? '#ffd23e' : '#6f7c8a', { align: 'right' });
    // barre d'expérience
    const k = L0.xp / SK.need(L0.lvl);
    g.fillStyle = '#05050a'; g.fillRect(x + 6, y + 15, w - 12, 4);
    g.fillStyle = '#3a3010'; g.fillRect(x + 7, y + 16, w - 14, 2);
    g.fillStyle = '#ffd23e'; g.fillRect(x + 7, y + 16, Math.round((w - 14) * k), 2);
    T(g, L0.xp + ' / ' + SK.need(L0.lvl) + ' XP', x + w / 2, y + 22, '#8f98a0', { align: 'center' });
    cells = [];
    const cw = 72, ch = 22, gap = 2, top = y + 40;
    SK.BRANCHES.forEach((b, i) => {
      const cx = x + 6 + i * (cw + 2);
      T(g, b.nom, cx + cw / 2, top - 9, b.color, { align: 'center' });
      b.perks.forEach((p, j) => {
        const cy = top + j * (ch + gap), got = SK.has(p.id), sel = s.col === i && s.row === j, why = SK.can(p.id);
        cells.push([cx, cy, cw, ch, i, j]);
        // lien vers la compétence du dessus
        if (j > 0) { g.fillStyle = SK.has(b.perks[j - 1].id) ? b.color : '#2d3150'; g.fillRect(cx + cw / 2, cy - gap, 1, gap); }
        g.fillStyle = got ? 'rgba(255,255,255,0.08)' : '#0f0e1c'; g.fillRect(cx, cy, cw, ch);
        g.fillStyle = got ? b.color : why ? '#2d3150' : '#6f7c8a';
        g.fillRect(cx, cy, cw, 1); g.fillRect(cx, cy + ch - 1, cw, 1); g.fillRect(cx, cy, 1, ch); g.fillRect(cx + cw - 1, cy, 1, ch);
        if (sel) { g.fillStyle = '#ffffff'; g.fillRect(cx - 1, cy - 1, cw + 2, 1); g.fillRect(cx - 1, cy + ch, cw + 2, 1); g.fillRect(cx - 1, cy - 1, 1, ch + 2); g.fillRect(cx + cw, cy - 1, 1, ch + 2); }
        T(g, p.nom, cx + cw / 2, cy + 5, got ? b.color : why && why !== 'PAS DE POINT' ? '#4a4e62' : '#d8dde6', { align: 'center' });
        T(g, got ? 'ACQUISE' : 'RANG ' + (j + 1), cx + cw / 2, cy + 13, got ? '#5dff9a' : '#6f7c8a', { align: 'center' });
      });
    });
    const p = SK.BRANCHES[s.col].perks[s.row];
    if (s.msgT > 0) T(g, s.msg, x + w / 2, y + h - 20, s.msgCol, { align: 'center' });
    else T(g, p.desc, x + w / 2, y + h - 20, '#c7d5e0', { align: 'center' });
    T(g, '[FLÈCHES/SOURIS] CHOISIR   [E] PRENDRE   [K/ÉCHAP] FERMER', x + w / 2, y + h - 10, '#6f7c8a', { align: 'center' });
    const mx = Math.round(C.input.mx), my = Math.round(C.input.my);
    g.fillStyle = '#05050a'; g.fillRect(mx - 1, my - 1, 3, 3);
    g.fillStyle = '#ffffff'; g.fillRect(mx, my, 1, 1);
  };
  // Barre d'XP fine sous la barre de PV.
  SK.drawHUD = function (g) {
    const gm = G(), L0 = gm.leader;
    if (!L0 || L0.xp == null) return;
    const k = L0.xp / SK.need(L0.lvl);
    g.fillStyle = '#05050a'; g.fillRect(77, 10, 26, 3);
    g.fillStyle = gm.xpFlash > 0 ? '#fff2a0' : '#c9a227'; g.fillRect(78, 11, Math.round(24 * k), 1);
    C.text(g, 'NV ' + L0.lvl + (L0.points ? ' +' + L0.points : ''), 78, 4, L0.points && Math.sin(gm.time * 5) > 0 ? '#ffd23e' : '#8f98a0', { shadow: '#05050a' });
  };
})();
