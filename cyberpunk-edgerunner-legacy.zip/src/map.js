'use strict';
// Moteur de carte : tuiles 8x8, collisions, ligne de vue, carte de distances pour la poursuite.
// Les cartes elles-mêmes (planque, rue, bâtiments) sont décrites dans maps.js ; M.load(id) en charge une.
(function () {
  const C = CEL;
  const N4 = [[1, 0], [-1, 0], [0, 1], [0, -1]];
  const N8 = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];
  const SOLID = new Set(['#', 'c', 'B', 'D', 'w']);   // bloquent les déplacements et les balles ('w' = eau)
  const OPAQUE = new Set(['#', 'B', 'D']);            // bloquent aussi la vue (pas les caisses ni les voitures)

  const M = (C.map = {
    id: null, def: null, MW: 0, MH: 0, grid: null, lights: [], flow: null, flowFrom: -1, block: new Set(),

    load(id) {
      const def = C.MAPS[id];
      this.id = id; this.def = def;
      this.MW = def.w; this.MH = def.h;
      this.grid = C.buildMap(def);
      this.lights = def.lights;
      this.flow = null; this.flowFrom = -1;
      // le décor (arbres, étals, épaves...) n'est pas une tuile : ses cases occupées sont listées à part
      this.block = new Set();
      for (const p of def.props || []) for (const [x, y] of C.decor.foot(p)) this.block.add(y * def.w + x);
    },
    blocked(tx, ty) { return this.block.has(ty * this.MW + tx); },
    door(id) { return this.def.doors.find(d => d.id === id); },
    tile(tx, ty) { return tx < 0 || ty < 0 || tx >= this.MW || ty >= this.MH ? '#' : this.grid[ty][tx]; },
    solid(tx, ty) { return SOLID.has(this.tile(tx, ty)) || this.blocked(tx, ty); },
    wall(tx, ty) { return OPAQUE.has(this.tile(tx, ty)); },
    solidAt(px, py) { return this.solid(Math.floor(px / 8), Math.floor(py / 8)); },

    // Déplace un cercle (x, y, r) le long d'un axe et le recolle au bord de la tuile touchée.
    moveAxis(e, d, axis) {
      if (!d) return false;
      if (axis === 0) e.x += d; else e.y += d;
      const r = e.r;
      const x0 = Math.floor((e.x - r) / 8), x1 = Math.floor((e.x + r - 0.001) / 8);
      const y0 = Math.floor((e.y - r) / 8), y1 = Math.floor((e.y + r - 0.001) / 8);
      let hit = false;
      for (let ty = y0; ty <= y1; ty++) {
        for (let tx = x0; tx <= x1; tx++) {
          if (!this.solid(tx, ty)) continue;
          hit = true;
          if (axis === 0) e.x = d > 0 ? tx * 8 - r : (tx + 1) * 8 + r;
          else e.y = d > 0 ? ty * 8 - r : (ty + 1) * 8 + r;
        }
      }
      return hit;
    },
    // Déplacement en petits pas pour ne jamais traverser un mur, même pendant un dash.
    move(e, dx, dy) {
      const n = Math.max(1, Math.ceil(Math.max(Math.abs(dx), Math.abs(dy)) / 3));
      let hit = false;
      for (let i = 0; i < n; i++) {
        hit = this.moveAxis(e, dx / n, 0) || hit;
        hit = this.moveAxis(e, dy / n, 1) || hit;
      }
      return hit;
    },

    // Ligne de vue : seuls les murs bloquent (on voit par-dessus les caisses).
    los(ax, ay, bx, by) {
      const dx = bx - ax, dy = by - ay;
      const steps = Math.ceil(Math.hypot(dx, dy) / 2);
      for (let i = 1; i < steps; i++) {
        const t = i / steps;
        if (this.wall(Math.floor((ax + dx * t) / 8), Math.floor((ay + dy * t) / 8))) return false;
      }
      return true;
    },

    // Carte de distances (parcours en largeur) depuis la tuile du joueur, refaite seulement quand il change de tuile.
    // Un ennemi qui ne voit pas le joueur descend cette carte : il contourne les murs sans vrai pathfinding.
    updateFlow(px, py) {
      const MW = this.MW, MH = this.MH;
      const tx = Math.floor(px / 8), ty = Math.floor(py / 8), key = ty * MW + tx;
      if (key === this.flowFrom) return;
      this.flowFrom = key;
      const d = this.flow || (this.flow = new Int16Array(MW * MH));
      d.fill(-1);
      const q = new Int32Array(MW * MH);
      let h = 0, t = 0;
      d[key] = 0;
      q[t++] = key;
      while (h < t) {
        const k = q[h++], x = k % MW, y = (k / MW) | 0;
        for (const [ox, oy] of N4) {
          const nx = x + ox, ny = y + oy;
          if (nx < 0 || ny < 0 || nx >= MW || ny >= MH) continue;
          const nk = ny * MW + nx;
          if (d[nk] !== -1 || this.solid(nx, ny)) continue;
          d[nk] = d[k] + 1;
          q[t++] = nk;
        }
      }
    },
    // Renvoie le centre de la tuile voisine la plus proche du joueur (ou null).
    flowStep(px, py) {
      if (!this.flow) return null;
      const tx = Math.floor(px / 8), ty = Math.floor(py / 8);
      let best = null, bv = 1e9;
      for (const [ox, oy] of N8) {
        const nx = tx + ox, ny = ty + oy;
        if (this.solid(nx, ny)) continue;
        if (ox && oy && (this.solid(tx + ox, ty) || this.solid(tx, ty + oy))) continue;  // pas de coin coupé
        const v = this.flow[ny * this.MW + nx];
        if (v >= 0 && v < bv) { bv = v; best = [nx * 8 + 4, ny * 8 + 4]; }
      }
      return best;
    },
    // Tuile de sol au hasard (pour les hallucinations).
    randomFloorNear(px, py, rmin, rmax) {
      for (let i = 0; i < 40; i++) {
        const a = C.rand() * Math.PI * 2, r = C.rr(rmin, rmax);
        const x = px + Math.cos(a) * r, y = py + Math.sin(a) * r;
        if (!this.solidAt(x, y) && this.los(px, py, x, y)) return [x, y];
      }
      return null;
    },
  });
})();
