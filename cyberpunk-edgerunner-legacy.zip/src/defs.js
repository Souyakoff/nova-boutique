'use strict';
// Toutes les valeurs de réglage du combat, au même endroit (vitesses en pixels/s, durées en secondes).
CEL.DEF = {
  player: {
    hp: 100,
    radius: 3.5,
    speed: 74,
    dashSpeed: 250, dashTime: 0.16, dashCd: 0.55,   // dash : invulnérable pendant dashTime
    injectors: 3, injectHeal: 40, injectTime: 0.6,  // pas de régénération : seulement les injecteurs
  },
  // Armes du joueur. Armes à feu : une seule à la fois (on échange en ramassant). Corps à corps : la lame de base ou le katana.
  //   pellets : plombs par tir ; gibContact : à bout portant, le corps éclate ; pierce : traverse les corps ;
  //   homing : balles guidées vers la cible la plus proche devant elles ; parry : le katana renvoie les balles pendant le coup.
  weapons: {
    pistol: { name: 'PISTOLET', kind: 'gun', dmg: 26, rate: 0.2, mag: 12, reload: 1.1, speed: 340, spread: 0.035, range: 260, len: 8.7, prix: 300 },
    smg: { name: 'SMG', kind: 'gun', dmg: 13, rate: 0.075, mag: 30, reload: 1.4, speed: 330, spread: 0.13, range: 220, len: 9.6, prix: 900 },
    shotgun: { name: 'FUSIL À POMPE', kind: 'gun', dmg: 17, pellets: 7, rate: 0.75, mag: 5, reload: 1.9, speed: 300, spread: 0.32, range: 140, len: 11, gibContact: 34, shake: 4, prix: 1200 },
    sniper: { name: 'FUSIL DE PRÉCISION', kind: 'gun', dmg: 110, rate: 1.1, mag: 4, reload: 2.2, speed: 720, spread: 0.004, range: 520, len: 12.5, pierce: 3, shake: 5, prix: 2200 },
    smart: { name: 'PISTOLET SMART', kind: 'gun', dmg: 20, rate: 0.16, mag: 16, reload: 1.3, speed: 230, spread: 0.3, range: 320, len: 9, homing: 7, color: '#2a5a6a', prix: 1800 },
    blade: { name: 'LAME', kind: 'melee', dmg: 48, range: 15, arc: 1.2, rate: 0.38, knock: 90 },
    katana: { name: 'KATANA', kind: 'melee', dmg: 75, range: 21, arc: 1.8, rate: 0.45, knock: 120, bladeLen: 15, parry: true, prix: 1500 },
  },
  // Armes des ennemis (plus faibles que celles du joueur, sinon on ne tient pas trois secondes).
  enemyArms: {
    pistol: { dmg: 14, rate: 0.8, speed: 230, spread: 0.12 },
    smg: { dmg: 8, rate: 0.17, speed: 240, spread: 0.2 },
    shotgun: { dmg: 9, pellets: 5, rate: 1.3, speed: 230, spread: 0.35 },
    smart: { dmg: 10, rate: 0.6, speed: 190, spread: 0.3, homing: 3 },
  },
  enemies: {
    thug: {
      name: 'RACAILLE', hp: 45, radius: 3.5, speed: 46, sight: 150, reaction: 0.45,
      weapon: { dmg: 14, rate: 0.8, speed: 230, spread: 0.12 },
      jacket: '#c23b5a', hair: '#1a1414',
    },
    brute: {
      name: 'BRUTE', hp: 95, radius: 4.5, speed: 56, sight: 130, reaction: 0.3,
      melee: { dmg: 26, range: 11, rate: 0.95, windup: 0.32 },
      jacket: '#d9822b', hair: '#7a4a2a',   // crâne rasé
    },
    // cadre d'une corpo, cible du grand contrat : résistant, tire en rafale
    cadre: {
      name: 'CADRE', hp: 220, radius: 4.5, speed: 40, sight: 170, reaction: 0.3,
      weapon: { dmg: 16, rate: 0.35, speed: 250, spread: 0.1 },
      jacket: '#e8e8f0', hair: '#111118',
    },
    // un ancien leader passé en cyberpsychose : rapide, résistant, avec des dashs façon Sandevistan
    psycho: {
      name: 'CYBERPSYCHO', hp: 240, radius: 3.5, speed: 66, sight: 200, reaction: 0.15,
      melee: { dmg: 28, range: 11, rate: 0.7, windup: 0.2 },
      dash: { speed: 230, time: 0.22, cd: 2.2 },
      jacket: '#b89a22', hair: '#3b1f63',
    },
  },
  // NCPD : patrouilleurs, puis SWAT (3 étoiles), puis MaxTac (5 étoiles, chrome militaire et dashs).
  police: {
    cop: { name: 'NCPD', hp: 60, radius: 3.5, speed: 54, sight: 170, reaction: 0.4, weapon: { dmg: 11, rate: 0.75, speed: 240, spread: 0.1 }, jacket: '#1f3a7a', hair: '#0e1630' },
    swat: { name: 'SWAT NCPD', hp: 110, radius: 4.5, speed: 50, sight: 190, reaction: 0.3, weapon: { dmg: 9, rate: 0.22, speed: 260, spread: 0.12 }, jacket: '#232a36', hair: '#101318' },
    maxtac: { name: 'MAXTAC', hp: 200, radius: 3.5, speed: 70, sight: 220, reaction: 0.15, weapon: { dmg: 16, rate: 0.3, speed: 300, spread: 0.06 }, dash: { speed: 230, time: 0.2, cd: 2.5 }, jacket: '#141418', hair: '#2a2a30', eye: '#ff2040', chrome: '#b8c4d6' },
  },
  // Étoiles de recherche (façon GTA). squads[n] : nombre max de flics à n étoiles ; lose : secondes sans être vu
  // pour semer la police (+ par étoile) ; metroBlock : étoiles à partir desquelles le métro est bouclé.
  wanted: { max: 5, squads: [0, 2, 4, 6, 8, 8], spawnEvery: 5, lose: 8, losePerStar: 3, witness: 160, metroBlock: 3, panicRadius: 140 },
  civilian: { hp: 30, panicSpeed: 64, panicTime: 6, runOver: 70 },
  // Gangs : un par quartier, dans la rue. rep (sauvegardée dans la ville) : sous hostile, ils attaquent à vue.
  // keep : distance de combat [min, max] ; groups : bandes dans le quartier ; types : membres possibles.
  gangs: {
    maelstrom: { nom: 'MAELSTROM', color: '#ff2040', district: 'rue', groups: 4, types: ['maelstrom'] },
    tyger: { nom: 'TYGER CLAWS', color: '#3ef0ff', district: 'japantown', groups: 5, types: ['tyger', 'tygerBlade', 'tygerBlade'] },
    valentinos: { nom: 'VALENTINOS', color: '#e8c040', district: 'centre', groups: 3, types: ['valentino'] },
    voodoo: { nom: 'VOODOO BOYS', color: '#5dff9a', district: 'pacifica', groups: 4, types: ['voodoo', 'voodoo', 'voodooGun'] },
  },
  gangRep: { hostile: -30, hurt: -15, kill: -25, rival: 6, shotsNear: -8, recover: 10 },
  gangMembers: {
    maelstrom: { name: 'MAELSTROM', hp: 80, radius: 4, speed: 42, sight: 150, reaction: 0.4, arms: ['shotgun', 'shotgun', 'pistol'], keep: [22, 55], jacket: '#2a1c1c', hair: '#141414', chrome: '#8a8f9a', eye: '#ff2040' },
    tyger: { name: 'TYGER CLAW', hp: 50, radius: 3.5, speed: 60, sight: 160, reaction: 0.35, arms: ['smg'], keep: [50, 90], strafe: 1, jacket: '#1e1e2a', hair: '#ff3ec8' },
    tygerBlade: { name: 'TYGER CLAW', hp: 55, radius: 3.5, speed: 74, sight: 160, reaction: 0.3, drop: 'katana', melee: { dmg: 30, range: 13, rate: 0.7, windup: 0.2 }, dash: { speed: 220, time: 0.18, cd: 2.6 }, blade: '#e8f6ff', jacket: '#e8e8f0', hair: '#3ef0ff' },
    valentino: { name: 'VALENTINO', hp: 55, radius: 3.5, speed: 54, sight: 160, reaction: 0.35, arms: ['pistol', 'pistol', 'smg'], keep: [60, 110], strafe: 1.2, jacket: '#c9a227', hair: '#1a1414' },
    voodoo: { name: 'VOODOO BOY', hp: 45, radius: 3.5, speed: 50, sight: 170, reaction: 0.4, arms: ['smart'], keep: [100, 150], hacker: true, jacket: '#2a4a2a', hair: '#1a1414', eye: '#5dff9a' },
    voodooGun: { name: 'VOODOO BOY', hp: 60, radius: 3.5, speed: 52, sight: 150, reaction: 0.35, arms: ['shotgun', 'pistol'], keep: [40, 80], jacket: '#1e3a24', hair: '#1a1414' },
  },
  // Piratage des Voodoo Boys sur le joueur : temps d'envoi, délai entre deux, effets.
  voodooHack: { up: 1.4, cd: [6, 9], range: 170, jam: 3.5, burn: 3, burnDmg: 4, shock: 14, stun: 0.7 },
  // compagnon : il suit le leader, couvre (ne tire que sur les ennemis déjà en alerte) et peut tomber à terre
  companion: {
    hp: 80, radius: 3.5, speed: 70, sight: 150, reaction: 0.35, followDist: 22, reviveHp: 0.4,
    weapon: { dmg: 18, rate: 0.45, speed: 320, spread: 0.07 },
    jacket: '#3ec8ff', hair: '#16263a',
    loyalty: { start: 55, clear: 8, spare: 3, execute: -8, revive: 5, scared: -4 },
  },
  // Implants posés par le ripperdoc. hum = humanité retirée. mods = ce qu'ils changent au combat (voir G.mods).
  // Un emplacement = un implant. Le Sandevistan Mk.1 est posé d'office (d'où l'humanité de départ à 80).
  implants: {
    sandy1: { slot: 'SYSTÈME', nom: 'SANDEVISTAN MK.1', prix: 0, hum: 20, base: true, desc: 'RALENTIT LE MONDE PENDANT 2,6 S.', mods: m => {} },
    sandy2: { slot: 'SYSTÈME', nom: 'SANDEVISTAN MK.2', prix: 1600, hum: 32, desc: '3,4 S DE RALENTI, LE MONDE ENCORE PLUS LENT.', mods: m => { m.sandyDur = 3.4 / 2.6; m.sandySlow = 0.15; } },
    gorilla: { slot: 'BRAS', nom: 'BRAS GORILLA', prix: 900, hum: 8, desc: 'LAME +80 % DE DÉGÂTS, RECUL DOUBLÉ.', mods: m => { m.blade = 1.8; m.knock = 2; } },
    mantis: { slot: 'BRAS', nom: 'LAMES MANTIS', prix: 1300, hum: 14, desc: 'LAME +40 %, PLUS LONGUE ET PLUS LARGE.', mods: m => { m.blade = 1.4; m.bladeRange = 8; m.bladeArc = 0.7; m.mantis = true; } },
    kiroshi: { slot: 'YEUX', nom: 'OPTIQUE KIROSHI', prix: 700, hum: 6, desc: 'TIR PLUS PRÉCIS. AFFICHE PV ET REGARDS ENNEMIS.', mods: m => { m.spreadMul = 0.4; m.scan = true; } },
    peau: { slot: 'PEAU', nom: 'PEAU SOUS-DERMIQUE', prix: 1000, hum: 10, desc: '-25 % DE DÉGÂTS REÇUS.', mods: m => { m.dmgTaken = 0.75; } },
    jambes: { slot: 'JAMBES', nom: 'JAMBES RENFORCÉES', prix: 800, hum: 8, desc: '+8 % DE VITESSE, DASH PLUS LONG ET PLUS SOUVENT.', mods: m => { m.speed = 1.08; m.dashCd = 0.6; m.dashSpeed = 1.2; } },
    bio: { slot: 'ORGANES', nom: 'BIOMONITEUR', prix: 600, hum: 4, desc: 'INJECTION AUTO SOUS 30 % DE PV, 1 FOIS PAR GIG.', mods: m => { m.bio = true; } },
    // Cyberdecks (emplacement DECK) : RAM, recharge, vitesse d'envoi, taille du tampon du breach, quickhacks débloqués.
    // Le Paraline est posé d'office, comme le Sandevistan Mk.1.
    deck1: { slot: 'DECK', nom: 'MILITECH PARALINE', prix: 0, hum: 0, base: true, desc: 'CYBERDECK DE BASE. 6 RAM.', mods: m => {} },
    deck2: { slot: 'DECK', nom: 'TETRATRONIC RIPPLER', prix: 1400, hum: 8, desc: '9 RAM, RECHARGE ET ENVOI PLUS RAPIDES. DÉBLOQUE SURCHAUFFE.', mods: m => { m.ramMax = 9; m.ramRegen = 0.7; m.upload = 0.8; m.buffer = 6; m.tier = 2; } },
    deck3: { slot: 'DECK', nom: 'NETWATCH NETDRIVER', prix: 3200, hum: 14, desc: '12 RAM, ENVOI ÉCLAIR. DÉBLOQUE SYNAPSE BRÛLÉE.', mods: m => { m.ramMax = 12; m.ramRegen = 0.9; m.upload = 0.6; m.buffer = 7; m.tier = 3; } },
  },
  immuno: { nom: 'IMMUNOSUPPRESSEURS', prix: 400, hum: 10, desc: 'RENDENT 10 POINTS D\'HUMANITÉ.' },
  removeRefund: 0.75,    // retirer un implant rend 75 % de l'humanité qu'il a coûté
  docMinHumanity: 10,    // le ripperdoc refuse de poser un implant qui te ferait passer sous 10
  eddies: { start: 200, thug: 60, brute: 120, psycho: 500, rival: 80, clear: 250, cop: 0, swat: 0, maxtac: 0 },
  // Contrats du fixer. Chaque contrat vise une faction ; Arasaka et Militech ont un arc qui mène au grand contrat.
  factions: {
    arasaka: { nom: 'ARASAKA', jacket: '#3c3c4c', hair: '#c4142b', color: '#ff2040', pay: 1, arc: true },
    militech: { nom: 'MILITECH', jacket: '#6b7d42', hair: '#22261a', color: '#9ccf5a', pay: 1, arc: true },
    kangtao: { nom: 'KANG TAO', jacket: '#1d5c55', hair: '#c9a227', color: '#3fd0b0', pay: 1.3, arc: false },   // jade : pas de jaune, réservé au leader
  },
  contracts: {
    elim: { nom: 'ÉLIMINATION', desc: 'METTRE LA CIBLE À TERRE.', pay: 500, targetHp: 1.8 },
    data: { nom: 'VOL DE DONNÉES', desc: 'PIRATER LE TERMINAL DU BUREAU (BREACH PROTOCOL).', pay: 600, hack: 1 },
    clean: { nom: 'NETTOYAGE', desc: 'METTRE TOUT LE MONDE À TERRE.', pay: 400 },
    // contracts.js
    heist: { nom: 'BRAQUAGE DISCRET', desc: "VOLER LE COLIS SANS QU'ILS DONNENT L'ALERTE.", pay: 750 },
    extract: { nom: 'EXTRACTION', desc: "LIBÉRER L'OTAGE ET LE SORTIR VIVANT.", pay: 700 },
    sabotage: { nom: 'SABOTAGE', desc: 'BOMBE SUR LE GÉNÉRATEUR, PUIS DÉGAGER.', pay: 650 },
    carsteal: { nom: 'VOL DE VOITURE', desc: 'VOLER LA VOITURE DORÉE, LA LIVRER AU DÉPÔT.', pay: 550 },
  },
  arcLength: 3,     // contrats remplis contre une faction avant son grand contrat
  grand: { pay: 5000, hpMul: 1.3, timer: 90, desc: 'ABATTRE LE CADRE AVANT QU\'IL NE S\'ENFUIE.' },
  fixerBonus: 0.1,  // un ancien leader devenu fixer paie +10 % par étoile de réputation
  burnedPay: 0.5,   // un leader grillé (grand contrat raté) ne touche plus que la moitié
  dealer: { nom: 'VIC TROIS-DOIGTS' },   // concessionnaire de la rue
  rivalHp: 1.6,      // un rival (épargné rancunier) a 60 % de PV en plus
  revealTime: 20,    // un allié te montre les ennemis pendant 20 s
  // Netrunning. RAM de base (deck1) ; les autres decks la changent via leurs mods.
  // scanSlow : le monde ralentit pendant le scan (TAB maintenu) ; range : portée des quickhacks en pixels.
  net: { ramMax: 6, ramRegen: 0.5, upload: 1, buffer: 5, scanSlow: 0.3, range: 180, breachTime: 20, breachEddies: 250 },
  // Quickhacks. on : type de cible. tier : deck minimum. up : temps d'envoi (s). loud : la cible sait qu'on l'attaque.
  quickhacks: {
    distraction: { on: 'enemy', tier: 1, nom: 'DISTRACTION', ram: 1, up: 0.5, dur: 6, desc: 'IL VA VOIR AILLEURS (CIBLE CALME).' },
    aveugle: { on: 'enemy', tier: 1, nom: 'OPTIQUE BROUILLÉE', ram: 2, up: 0.7, dur: 6, desc: 'IL NE VOIT PLUS RIEN PENDANT 6 S.' },
    court: { on: 'enemy', tier: 1, nom: 'COURT-CIRCUIT', ram: 3, up: 0.6, dmg: 38, stun: 0.8, loud: true, desc: '38 DÉGÂTS, SONNÉ.' },
    surchauffe: { on: 'enemy', tier: 2, nom: 'SURCHAUFFE', ram: 4, up: 0.8, dmg: 60, dur: 4, loud: true, desc: '60 DÉGÂTS DE BRÛLURE EN 4 S.' },
    synapse: { on: 'enemy', tier: 3, nom: 'SYNAPSE BRÛLÉE', ram: 7, up: 1.2, dmg: 120, loud: true, desc: '120 DÉGÂTS. LE CERVEAU GRILLE.' },
    camOff: { on: 'camera', tier: 1, nom: 'DÉSACTIVER', ram: 1, up: 0.5, desc: 'LA CAMÉRA S\'ÉTEINT.' },
    camMark: { on: 'camera', tier: 1, nom: 'MARQUER LES CIBLES', ram: 2, up: 0.6, dur: 15, desc: 'RÉVÈLE LES ENNEMIS 15 S.' },
    turOff: { on: 'turret', tier: 1, nom: 'DÉSACTIVER', ram: 2, up: 0.7, desc: 'LA TOURELLE S\'ÉTEINT.' },
    turAlly: { on: 'turret', tier: 1, nom: 'RETOURNER', ram: 4, up: 1, desc: 'ELLE TIRE SUR LES ENNEMIS.' },
  },
  // Sécurité des bâtiments.
  camera: { range: 100, fov: 0.42, sweep: 0.7, detect: 0.9, hp: 20, alarmRadius: 230 },
  turret: { hp: 120, range: 140, turn: 3, rate: 0.22, dmg: 8, speed: 280, spread: 0.06 },
  // Sandevistan : ralentit le monde, pas le joueur. Chaque activation coûte de l'humanité.
  sandy: { duration: 2.6, recharge: 7, slow: 0.22, humanityCost: 5, minCharge: 0.25 },
  // Humanité : 100 - 20 pour le Sandevistan implanté. Sous 50 : hallucinations. À 0 : cyberpsychose.
  humanity: { start: 80, hallucinate: 50, glitch: 30 },
};
// Les flics sont des ennemis comme les autres pour l'IA (makeEnemy les trouve dans enemies).
Object.assign(CEL.DEF.enemies, CEL.DEF.police, CEL.DEF.gangMembers);
