'use strict';
// Sprites des personnages, vus de dessus.
//
// Un personnage est décrit par des formes simples (ellipses, segments, rectangles) dans son repère local :
// u = vers l'avant (là où il regarde), v = vers sa droite, en pixels. Pour chacune des 16 directions,
// on « pixellise » ces formes : chaque pixel de l'image est ramené dans le repère local et on regarde quelle
// forme le couvre. Résultat : des pixels nets dans toutes les directions (une rotation de canvas les floute).
// Puis on ajoute un contour sombre et un léger ombrage (lumière venant du haut à gauche).
// Chaque image est gardée en cache : couleurs + pose + image d'animation + direction.
(function () {
  const C = CEL;
  const SP = (C.sprites = {});
  const DIRS = 16, SIZE = 31, MID = SIZE / 2;
  const OUTLINE = '#07070c';
  const cache = new Map();

  // ---------- outils de couleur ----------
  const hex2 = h => { const n = parseInt(h.slice(1), 16); return [n >> 16, (n >> 8) & 255, n & 255]; };
  const rgb = (r, g, b) => '#' + ((1 << 24) | (Math.max(0, Math.min(255, r | 0)) << 16) | (Math.max(0, Math.min(255, g | 0)) << 8) | Math.max(0, Math.min(255, b | 0))).toString(16).slice(1);
  const mul = (h, k) => { const [r, g, b] = hex2(h); return rgb(r * k, g * k, b * k); };
  SP.shade = mul;

  // ---------- formes ----------
  const ell = (cu, cv, ru, rv) => (u, v) => ((u - cu) / ru) ** 2 + ((v - cv) / rv) ** 2 <= 1;
  const seg = (au, av, bu, bv, r) => (u, v) => {
    const du = bu - au, dv = bv - av, L = du * du + dv * dv;
    const t = L ? Math.max(0, Math.min(1, ((u - au) * du + (v - av) * dv) / L)) : 0;
    const x = au + du * t - u, y = av + dv * t - v;
    return x * x + y * y <= r * r;
  };
  const rect = (u0, u1, v0, v1) => (u, v) => u >= u0 && u <= u1 && v >= v0 && v <= v1;
  const and = (a, b) => (u, v) => a(u, v) && b(u, v);

  // Tête vue de dessus selon la coiffure (p.style) : courte (défaut), rasée, crête, longue, casquette, casque.
  // cu = position de la tête sur l'axe avant ; renvoie les parties, de la plus haute à la plus basse.
  function headParts(p, cu = 0.5) {
    const head = ell(cu, 0, 2.2, 2.1), face = [and(head, ell(cu + 1.5, 0, 1.0, 1.35)), p.skin, null];
    switch (p.style) {
      case 'bald': return [face, [head, mul(p.skin, 0.88), [cu, 0]]];
      case 'mohawk': return [[and(head, rect(cu - 2.4, cu + 1.6, -0.55, 0.55)), p.hair, null], face, [head, mul(p.skin, 0.85), [cu, 0]]];
      case 'long': return [face, [ell(cu - 0.7, 0, 2.7, 2.35), p.hair, [cu, 0]]];
      case 'cap': return [[rect(cu + 1.2, cu + 3.4, -1.5, 1.5), mul(p.cap, 0.8), null], [and(head, ell(cu - 0.3, 0, 2.0, 2.0)), p.cap, [cu, 0]], face, [head, p.hair, [cu, 0]]];
      case 'helmet': return [[and(ell(cu + 0.2, 0, 2.6, 2.5), rect(cu + 1.3, cu + 3, -1.6, 1.6)), mul(p.cap, 1.6), null], [ell(cu, 0, 2.6, 2.5), p.cap, [cu, 0]]];
      default: return [face, [head, p.hair, [cu, 0]]];
    }
  }

  // Les poses : liste de parties, de la plus haute (dessinée par-dessus) à la plus basse.
  // p = palette ; f = image d'animation (0..3) ; chaque partie : [test, couleur, centre de l'ombrage ou null]
  const STRIDE = [-1.5, 0, 1.5, 0];
  const POSES = {
    // arme de poing tenue à deux mains devant soi
    gun(p, f, recoil = 0) {
      const s = STRIDE[f], r = recoil, head = ell(0.5, 0, 2.2, 2.1);
      return [
        p.eye ? [ell(2.2, 0.7, 0.55, 0.55), p.eye, null] : null,
        ...headParts(p),
        [ell(4.5 - r, 0.25, 1.05, 1.05), p.skin, null],
        [rect(4.7 - r, p.gunLen - r, -0.6, -0.05), mul(p.gun, 1.8), null],
        [rect(4.4 - r, p.gunLen - r, -0.6, 0.6), p.gun, null],
        [seg(0.4, 3.1, 4.3 - r, 0.7, 1.1), p.sleeve, null],
        [seg(0.4, -3.1, 4.3 - r, -0.3, 1.1), p.sleeve, null],
        p.chrome ? [ell(0.1, 3.7, 1.3, 1.3), p.chrome, [0.1, 3.7]] : null,
        p.chrome ? [ell(0.1, -3.7, 1.3, 1.3), p.chrome, [0.1, -3.7]] : null,
        [ell(-0.4, 0, 2.8, 4.6), p.jacket, [-0.3, 0]],
        [ell(s, 1.7, 1.8, 1.25), p.pants, null],
        [ell(-s, -1.7, 1.8, 1.25), p.pants, null],
      ];
    },
    fire(p, f) { return POSES.gun(p, f, 1); },
    // mains nues : les bras se balancent en marchant
    bare(p, f) {
      const s = STRIDE[f], w = s * 0.8, head = ell(0.5, 0, 2.2, 2.1);
      return [
        p.eye ? [ell(2.2, 0.7, 0.55, 0.55), p.eye, null] : null,
        ...headParts(p),
        [ell(1.2 - w, 4.5, 1.0, 1.0), p.chrome || p.skin, null],
        [ell(1.2 + w, -4.5, 1.0, 1.0), p.chrome || p.skin, null],
        [seg(0.2, 3.4, 1.0 - w, 4.5, 1.05), p.sleeve, null],
        [seg(0.2, -3.4, 1.0 + w, -4.5, 1.05), p.sleeve, null],
        [ell(-0.4, 0, 2.8, 4.6), p.jacket, [-0.3, 0]],
        [ell(s, 1.7, 1.8, 1.25), p.pants, null],
        [ell(-s, -1.7, 1.8, 1.25), p.pants, null],
      ];
    },
    // poings levés devant (brutes)
    fists(p, f) {
      const s = STRIDE[f], head = ell(0.5, 0, 2.2, 2.1), fist = p.chrome || p.skin;
      return [
        ...headParts(p),
        [ell(4.0, 2.3, 1.35, 1.35), fist, [4, 2.3]],
        [ell(4.0, -2.3, 1.35, 1.35), fist, [4, -2.3]],
        [seg(0.4, 3.3, 3.6, 2.4, 1.15), p.sleeve, null],
        [seg(0.4, -3.3, 3.6, -2.4, 1.15), p.sleeve, null],
        [ell(-0.3, 0, 2.7, 4.5), p.jacket, [-0.3, 0]],
        [ell(s, 1.8, 1.8, 1.3), p.pants, null],
        [ell(-s, -1.8, 1.8, 1.3), p.pants, null],
      ];
    },
    // coup de lame : bras droit tendu, lame dans le prolongement
    slash(p, f) {
      const head = ell(0.5, 0, 2.2, 2.1);
      return [
        p.eye ? [ell(2.2, 0.7, 0.55, 0.55), p.eye, null] : null,
        ...headParts(p),
        [rect(6.5, p.bladeLen, 1.1, 1.8), p.blade, null],
        [ell(6.0, 1.5, 1.05, 1.05), p.chrome || p.skin, null],
        [seg(0.6, 3.0, 5.6, 1.6, 1.1), p.sleeve, null],
        [ell(1.0, -4.4, 1.0, 1.0), p.skin, null],
        [seg(0.2, -3.4, 0.9, -4.4, 1.05), p.sleeve, null],
        [ell(-0.1, 0, 2.6, 4.3), p.jacket, [-0.1, 0]],
        [ell(1.4, 1.7, 1.8, 1.25), p.pants, null],
        [ell(-1.4, -1.7, 1.8, 1.25), p.pants, null],
      ];
    },
    // à terre : allongé dans la direction donnée (la tête vers l'avant)
    down(p) {
      return [
        ...headParts(p, 5.6).filter(x => x[1] !== p.skin),   // face contre le sol : on voit l'arrière du crâne
        [seg(1.2, 2.8, 4.0, 5.3, 1.05), p.sleeve, null],
        [seg(1.2, -2.8, 3.2, -5.5, 1.05), p.sleeve, null],
        [ell(4.3, 5.6, 1.0, 1.0), p.skin, null],
        [ell(3.4, -5.8, 1.0, 1.0), p.skin, null],
        [ell(0.6, 0, 4.4, 2.8), p.jacket, [0.6, 0]],
        [seg(-3, 1.3, -7.5, 2.4, 1.3), p.pants, null],
        [seg(-3, -1.3, -7.6, -1.0, 1.3), p.pants, null],
      ];
    },
    // en train de tomber (animation de mort) : f = 0 il plie, f = 1 il bascule
    fall(p, f) {
      const k = f ? 0.75 : 0.4;   // avancement de la chute
      return [
        ...headParts(p, 0.5 + 5 * k).filter(x => f === 0 || x[1] !== p.skin),
        [seg(0.6, 3.0, 1.5 + 2.5 * k, 3.6 + 2 * k, 1.05), p.sleeve, null],
        [seg(0.6, -3.0, 1.2 + 2 * k, -3.8 - 2 * k, 1.05), p.sleeve, null],
        [ell(1.8 + 2.5 * k, 3.8 + 2 * k, 1.0, 1.0), p.skin, null],
        [ell(1.4 + 2 * k, -4.0 - 2 * k, 1.0, 1.0), p.skin, null],
        [ell(0.6 * k, 0, 2.8 + 1.6 * k, 4.4 - 1.6 * k), p.jacket, [0.6 * k, 0]],
        [seg(-1, 1.5, -1 - 6 * k, 1.8 + k, 1.3), p.pants, null],
        [seg(-1, -1.5, -1 - 6 * k, -1.2, 1.3), p.pants, null],
      ];
    },
    // assis, mains levées (ennemi épargné)
    sit(p) {
      return [
        ...headParts(p, 0.2),
        [ell(0.6, 4.9, 1.0, 1.0), p.skin, null],
        [ell(0.6, -4.9, 1.0, 1.0), p.skin, null],
        [seg(-0.2, 3.3, 0.5, 4.8, 1.05), p.sleeve, null],
        [seg(-0.2, -3.3, 0.5, -4.8, 1.05), p.sleeve, null],
        [ell(-0.6, 0, 2.5, 4.1), p.jacket, [-0.6, 0]],
        [seg(1, 1.6, 4.6, 2.0, 1.25), p.pants, null],
        [seg(1, -1.6, 4.6, -2.0, 1.25), p.pants, null],
      ];
    },
  };

  // Palette complète à partir des couleurs données (les manches sont la veste assombrie).
  function palette(o) {
    const p = {
      jacket: o.jacket, hair: o.hair || '#1a1414', skin: o.skin || '#c9926c', pants: o.pants || mul(o.jacket, 0.32),
      gun: o.gunColor || '#1b1b24', sleeve: o.sleeve || mul(o.jacket, 0.78), chrome: o.chrome || null, eye: o.eye || null,
      blade: o.blade || '#e8f6ff', style: o.style || 'short', cap: o.cap || '#1a1a22',
      gunLen: o.gunLen || 8.7, bladeLen: o.bladeLen || 11.5,   // longueur du canon (fusils plus longs) et de la lame (katana)
    };
    if (o.solid) for (const k of Object.keys(p)) if (p[k] && typeof p[k] === 'string' && p[k][0] === '#') p[k] = o.solid;   // silhouette d'une seule couleur
    return p;
  }

  function build(o, pose, frame, dir) {
    const p = palette(o), sc = o.scale || 1;
    const parts = POSES[pose](p, frame).filter(Boolean);
    const a = (dir / DIRS) * Math.PI * 2, ca = Math.cos(a), sa = Math.sin(a);
    const c = document.createElement('canvas');
    c.width = c.height = SIZE;
    const g = c.getContext('2d');
    const filled = new Uint8Array(SIZE * SIZE);
    for (let py = 0; py < SIZE; py++) {
      for (let px = 0; px < SIZE; px++) {
        const dx = px + 0.5 - MID, dy = py + 0.5 - MID;
        // pixel ramené dans le repère du personnage
        const u = (dx * ca + dy * sa) / sc, v = (-dx * sa + dy * ca) / sc;
        for (const [test, col, ctr] of parts) {
          if (!test(u, v)) continue;
          let k = 1;
          if (ctr && !o.solid) {
            // ombrage : plus clair vers le haut à gauche de l'écran, plus sombre vers le bas à droite
            const cx = (ctr[0] * ca - ctr[1] * sa) * sc, cy = (ctr[0] * sa + ctr[1] * ca) * sc;
            const t = (dx - cx) + (dy - cy);
            k = t < -1.6 ? 1.22 : t > 1.6 ? 0.8 : 1;
          }
          g.fillStyle = k === 1 ? col : mul(col, k);
          g.fillRect(px, py, 1, 1);
          filled[py * SIZE + px] = 1;
          break;
        }
      }
    }
    // contour : tout pixel vide qui touche un pixel plein
    if (!o.noOutline) {
      g.fillStyle = o.solid ? o.solid : OUTLINE;
      for (let py = 0; py < SIZE; py++) for (let px = 0; px < SIZE; px++) {
        if (filled[py * SIZE + px]) continue;
        const f = (x, y) => x >= 0 && y >= 0 && x < SIZE && y < SIZE && filled[y * SIZE + x];
        if (f(px - 1, py) || f(px + 1, py) || f(px, py - 1) || f(px, py + 1)) g.fillRect(px, py, 1, 1);
      }
    }
    return c;
  }

  // Dessine un personnage centré en (x, y), tourné vers aim.
  // o : {jacket, hair, skin, pants, chrome, eye, blade, scale, solid, pose, frame, flash, alpha}
  SP.draw = function (g, x, y, aim, o) {
    const pose = o.pose || 'gun', frame = o.frame || 0;
    let dir = Math.round((aim / (Math.PI * 2)) * DIRS) % DIRS;
    if (dir < 0) dir += DIRS;
    const key = [o.jacket, o.hair, o.skin, o.pants, o.chrome, o.eye, o.blade, o.scale, o.solid, o.style, o.cap, o.gunLen, o.bladeLen, o.gunColor, pose, frame, dir].join('|');
    let img = cache.get(key);
    if (!img) { img = build(o, pose, frame, dir); cache.set(key, img); }
    const ix = Math.round(x - MID), iy = Math.round(y - MID);
    if (o.shadow !== false && !o.solid && pose !== 'down' && pose !== 'fall') {
      // ombre portée, décalée vers le bas à droite
      g.fillStyle = 'rgba(0,0,0,0.35)';
      g.fillRect(Math.round(x) - 3, Math.round(y) + 2, 7, 3);
      g.fillRect(Math.round(x) - 4, Math.round(y) + 3, 9, 1);
    }
    if (o.alpha != null) g.globalAlpha = o.alpha;
    g.drawImage(img, ix, iy);
    if (o.flash) {
      // touché : silhouette blanche par-dessus
      const wkey = key + '|white';
      let w = cache.get(wkey);
      if (!w) { w = build(Object.assign({}, o, { solid: '#ffffff', noOutline: true }), pose, frame, dir); cache.set(wkey, w); }
      g.globalAlpha = 0.85;
      g.drawImage(w, ix, iy);
    }
    g.globalAlpha = 1;
  };

  // Image d'animation de marche à partir d'un compteur qui avance quand on bouge.
  SP.walkFrame = (walk, moving) => (moving ? Math.floor(walk / 1.7) % 4 : 1);
  SP.cacheSize = () => cache.size;

  // Tenues au hasard pour les passants et les gangers : peau, coiffure, pantalon, couleur de cheveux.
  SP.SKINS = ['#f2c8a8', '#e8b48f', '#c9926c', '#a8704e', '#7a4e34', '#5a3826'];
  const STYLES = ['short', 'short', 'bald', 'mohawk', 'long', 'cap'];
  const HAIRS = ['#1a1414', '#3b2a1a', '#6a4a2a', '#c9a227', '#e8e8f0', '#ff3ec8', '#3ef0ff', '#7a3cff', '#c4142b'];
  const PANTS = ['#1a1a22', '#2a2a36', '#22303e', '#3a2a22', '#1e2a1e', '#4a4a52'];
  const CAPS = ['#c4142b', '#1a1a22', '#2a6fdb', '#f2d43a', '#e8e8f0'];
  SP.randomLook = (rnd = Math.random) => {
    const pick = a => a[(rnd() * a.length) | 0];
    return { skin: pick(SP.SKINS), style: pick(STYLES), hair: rnd() < 0.7 ? pick(HAIRS.slice(0, 4)) : pick(HAIRS), pants: pick(PANTS), cap: pick(CAPS) };
  };
})();
