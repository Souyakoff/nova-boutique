'use strict';
// Planque vivante et sauvegarde de la partie.
//
// Journal du gig (leader.log) : chaque exploit est noté pendant le gig (ennemis à terre, corps éclatés, civils, flics,
// étoiles NCPD, voitures volées, piratages, guerres de gangs). Quand le gig se termine, le journal devient leader.last :
// au gig suivant, les PNJ de la planque le commentent (bulles), l'écran N54 NEWS en fait ses gros titres,
// et Luna, la barmaid, en parle en servant à boire.
//
// Sauvegarde (localStorage, clé « cel-partie ») : le leader en cours, son équipe, ses PV, son humanité.
// Écrite au début de chaque gig et en sortant de la planque. Sur l'écran titre : CONTINUER.
// On reprend toujours à la planque, au début du gig en cours (le contrat accepté est perdu).
// Mourir efface la sauvegarde : pas de retour en arrière.
(function () {
  const C = CEL, M = C.map;
  const H = (C.home = {});
  const G = () => C.game;
  const pick = a => a[(Math.random() * a.length) | 0];

  // ---------- journal du gig ----------
  H.blankLog = () => ({ kills: 0, gibs: 0, execs: 0, spared: 0, civils: 0, cops: 0, stars: 0, cars: 0, hacks: 0, war: [], gangKills: {} });
  // Noté par game.js, gore.js, ncpd.js, traffic.js, netrun.js et gangs.js.
  H.note = function (kind, arg) {
    const g = G(), l = g.leader && g.leader.log;
    if (!l || g.mode !== 'play') return;
    switch (kind) {
      case 'stars': l.stars = Math.max(l.stars, arg); break;
      case 'war': if (!l.war.includes(arg)) l.war.push(arg); break;
      case 'gangKill': l.gangKills[arg] = (l.gangKills[arg] || 0) + 1; break;
      default: if (kind in l) l[kind]++;
    }
  };
  // Fin du gig : on fige le journal avec le contrat, l'état du leader et sa santé.
  H.closeGig = function () {
    const g = G(), l = g.leader.log || H.blankLog(), k = g.contract, p = g.player;
    l.contract = k ? { type: k.type, faction: k.faction, site: k.site, done: !!k.done, failed: !!k.failed, grand: !!k.grand } : null;
    l.hp = p ? p.hp / p.maxHp : 1;
    l.hum = g.humanity;
    g.leader.last = l;
  };

  // ---------- ce que la planque a retenu ----------
  const GANG = id => (C.DEF.gangs[id] || { nom: id }).nom;
  const SITE = id => (C.MAPS[id] || { nom: id }).nom;
  const FACTION = id => (C.DEF.factions[id] || { nom: id }).nom;
  // Faits marquants du dernier gig, et les mots à glisser dans les répliques.
  H.facts = function () {
    const g = G(), ld = g.leader, l = ld.last, city = C.legacy.city, prev = city.leaders[city.leaders.length - 1];
    const f = new Set(), v = { nom: ld.nom, prev: prev ? prev.nom : '', comp: g.comp ? g.comp.nom : '' };
    if (!l) {
      f.add('first');
      if (prev) f.add('legacy');
    } else {
      const k = l.contract;
      Object.assign(v, { kills: l.kills, gibs: l.gibs, civils: l.civils, cars: l.cars, stars: l.stars, hacks: l.hacks, execs: l.execs, spared: l.spared });
      v.carsN = l.cars + (l.cars > 1 ? ' VOITURES VOLÉES' : ' VOITURE VOLÉE');
      if (k) { v.site = SITE(k.site); v.faction = FACTION(k.faction); }
      if (!k) f.add('noContract');
      else if (k.failed) f.add('fail');
      else if (k.done) { f.add('done'); if (l.kills === 0) f.add('ghost'); }
      else f.add('noContract');
      if (l.gibs >= 4) f.add('gibs');
      if (l.kills >= 12) f.add('massacre');
      if (l.civils >= 2) f.add('civils');
      if (l.stars >= 5) f.add('maxtac');
      if (l.stars >= 3 || l.cops >= 1) f.add('ncpd');
      if (l.execs >= 3 && l.execs > l.spared) f.add('execs');
      if (l.spared >= 2) f.add('spared');
      if (l.cars >= 1) f.add('cars');
      if (l.hacks >= 5) f.add('hacks');
      if (l.war.length) { f.add('war'); v.gang = GANG(l.war[l.war.length - 1]); }
      const gk = Object.keys(l.gangKills).sort((a, b) => l.gangKills[b] - l.gangKills[a])[0];
      if (gk && l.gangKills[gk] >= 3) { f.add('gangKills'); v.gk = GANG(gk); v.gkn = l.gangKills[gk]; }
      if (l.hp < 0.4) f.add('hurt');
      else if (l.hp > 0.9 && l.kills > 0) f.add('clean');
      if (l.hum < 40) f.add('chrome');
    }
    if (city.psycho && !city.psycho.defeated) { f.add('psycho'); v.psycho = city.psycho.nom; v.psite = SITE(city.psycho.site); }
    return { f, v };
  };

  // Répliques des PNJ : pour chacun, les faits dans l'ordre où ils l'intéressent. \n = retour à la ligne.
  const LINES = {
    doc: [
      ['hurt', ['TU SAIGNES SUR MON CARRELAGE,\n{nom}. ASSIEDS-TOI.', 'ENCORE DES TROUS ? JE FACTURE\nAU CENTIMÈTRE.']],
      ['chrome', ['TON HUMANITÉ FOND, {nom}.\nJE LE VOIS DANS TES YEUX.', 'ENCORE DU CHROME ET TU NE\nRECONNAÎTRAS PLUS TA MÈRE.']],
      ['gibs', ['{gibs} CORPS EN MORCEAUX.\nÇA, MÊME MOI JE NE RECOUDS PAS.', 'J\'AI VU LES PHOTOS DE N54.\nTU AS DU MAL À TE CONTENIR.']],
      ['clean', ['PAS UNE ÉGRATIGNURE ?\nTU VAS ME METTRE AU CHÔMAGE.']],
      ['psycho', ['{psycho} RÔDE ENCORE.\nJE L\'AVAIS PRÉVENU POUR LE CHROME.']],
      ['legacy', ['J\'AI RECOUSU {prev} CENT FOIS.\nPAS LA DERNIÈRE.', 'LE FAUTEUIL EST ENCORE TIÈDE\nDE {prev}. ASSIEDS-TOI.']],
      ['first', ['PREMIÈRE FOIS ? DÉTENDS-TOI,\nJE NE MORDS QUE LE CHROME.']],
      ['*', ['DU CHROME, DES PANSEMENTS ?\nJE PRENDS LES EDDIES.', 'LAVE-TOI LES MAINS AVANT DE\nTOUCHER MES INSTRUMENTS.']],
    ],
    fixer: [
      ['fail', ['LE CONTRAT DE {site} ?\nUN FIASCO. ÇA SE PAIE.', '{faction} NE RAPPELLE PLUS.\nMERCI POUR ÇA.']],
      ['ghost', ['{site} SANS UN COUP DE FEU.\nDU TRAVAIL DE FANTÔME.']],
      ['maxtac', ['LE MAX-TAC, {nom} ? VRAIMENT ?\nTU VEUX NOUS FAIRE TUER ?']],
      ['done', ['{faction} EST CONTENT.\nET QUAND ILS SONT CONTENTS, JE LE SUIS.', 'BEAU BOULOT À {site}.\nJ\'AI DÉJÀ D\'AUTRES OFFRES.']],
      ['ncpd', ['LE NCPD A TA TÊTE SUR LEURS\nÉCRANS. FAIS-TOI OUBLIER.']],
      ['noContract', ['TU TE PROMÈNES OU TU BOSSES ?\nJ\'AI DES CONTRATS QUI ATTENDENT.']],
      ['legacy', ['{prev} BOSSAIT POUR MOI.\nVOYONS CE QUE TU VAUX.']],
      ['first', ['C\'EST TOI LE NOUVEAU ?\nVIENS VOIR LES OFFRES.']],
      ['*', ['DE L\'ARGENT FACILE, ÇA N\'EXISTE\nPAS. MAIS J\'AI DE L\'ARGENT.']],
    ],
    gunsmith: [
      ['gibs', ['{gibs} ÉCLATÉS ? T\'AS PAS\nUN FLINGUE, T\'AS UN HACHOIR.']],
      ['massacre', ['{kills} À TERRE. MES BÉBÉS\nONT BIEN TRAVAILLÉ.', 'RAMÈNE-MOI LES DOUILLES,\nJE LES RECYCLE.']],
      ['gangKills', ['{gkn} {gk} AU TAPIS. ILS VONT\nVENIR ACHETER CHEZ MOI.']],
      ['hacks', ['{hacks} PIRATAGES ? T\'AS PLUS\nBESOIN DE MOI, LE NETRUNNER.']],
      ['cars', ['UNE CAISSE VOLÉE ?\nJE CONNAIS UN TYPE POUR LA PLAQUE.']],
      ['first', ['RUSTY. ARMURIER.\nPAYE ET JE TE FAIS UN PRIX.']],
      ['*', ['UN FLINGUE PROPRE EST\nUN FLINGUE QUI TIRE.', 'J\'AI REÇU DU NEUF.\nVIENS VOIR.']],
    ],
    luna: [
      ['civils', ['{civils} PASSANTS ABATTUS...\nTOUT LE BAR NE PARLE QUE DE ÇA.', 'LES CIVILS, {nom}. ILS AVAIENT\nRIEN DEMANDÉ.']],
      ['war', ['LES {gang} TE CHERCHENT.\nILS SONT PASSÉS HIER SOIR.']],
      ['maxtac', ['LE MAX-TAC DANS NOTRE QUARTIER.\nJ\'EN TREMBLE ENCORE.']],
      ['cars', ['{carsN} ?\nLES ASSUREURS T\'ADORENT.']],
      ['spared', ['TU AS ÉPARGNÉ {spared} TYPES ?\nLA RUE DIT QUE T\'ES CORRECT.']],
      ['execs', ['{execs} EXÉCUTIONS. LES GENS\nCHANGENT DE TROTTOIR, MAINTENANT.']],
      ['psycho', ['ON A VU {psycho} À {psite}.\nN\'Y VA PAS SEUL.']],
      ['legacy', ['{prev} BUVAIT ICI, AU BOUT DU BAR.\nUN VERRE POUR LUI ?']],
      ['first', ['BIENVENUE CHEZ LUNA.\nPREMIER VERRE ? IL EST PAYANT.']],
      ['*', ['UN VERRE ? UN TUYAU ?\nTOUT SE MONNAIE ICI.', 'LA PLUIE NE S\'ARRÊTE JAMAIS.\nLE BAR NON PLUS.']],
    ],
    recruit: [
      ['spared', ['TU LAISSES VIVRE TES ENNEMIS.\nJ\'AIME BIEN ÇA.']],
      ['execs', ['ON DIT QUE T\'ACHÈVES TOUT\nLE MONDE. JE SERAI DU BON CÔTÉ.']],
      ['ghost', ['SANS UN COUP DE FEU ?\nJE VEUX APPRENDRE ÇA.']],
      ['massacre', ['{kills} À TERRE EN UN GIG ?\nPRENDS-MOI AVEC TOI.']],
      ['*', ['J\'AI BESOIN DE BOULOT.\nT\'AS BESOIN D\'UN FLINGUE ?']],
    ],
  };
  const fill = (s, v) => s.replace(/\{(\w+)\}/g, (_, k) => v[k] == null ? '' : String(v[k]));
  // Une réplique : un des deux premiers sujets qui concernent ce PNJ.
  H.line = function (who) {
    const { f, v } = H.facts(), list = LINES[who].filter(([k]) => k === '*' || f.has(k));
    const [, lines] = list.length > 1 && list[1][0] !== '*' && Math.random() < 0.35 ? list[1] : list[0];
    return fill(pick(lines), v);
  };

  // ---------- N54 NEWS ----------
  const ADS = [
    'PUB · KIROSHI OPTICS : VOYEZ PLUS LOIN QUE LES AUTRES',
    'BOURSE · ARASAKA +3,2 % · MILITECH -1,1 %',
    'MÉTÉO · PLUIES ACIDES SUR PACIFICA TOUTE LA SEMAINE',
    'PUB · NICOLA : LE GOÛT DU FUTUR',
    'SPORT · LES NIGHT CITY SHARKS EN FINALE',
    'TRAFIC · LE MÉTRO NCART ROULE MALGRÉ LES COUPURES',
  ];
  H.news = function () {
    const { f, v } = H.facts(), n = [];
    const add = (k, s) => { if (f.has(k)) n.push(fill(s, v)); };
    add('massacre', 'CARNAGE À {site} : {kills} VICTIMES, LE NCPD DÉPASSÉ');
    add('gibs', 'SCÈNE DE CRIME INSOUTENABLE : LES LÉGISTES RAMASSENT LES MORCEAUX');
    add('done', '{faction} DÉMENT TOUTE INTRUSION À {site}');
    add('ghost', 'CAMBRIOLAGE FANTÔME À {site} : AUCUN TÉMOIN');
    add('fail', 'OPÉRATION RATÉE À {site} : {faction} FURIEUX');
    add('civils', 'TUERIE EN PLEINE RUE : {civils} PASSANTS ABATTUS');
    add('maxtac', 'LE MAX-TAC DÉPLOYÉ EN PLEINE VILLE');
    if (!f.has('maxtac')) add('ncpd', 'TRAQUE DU NCPD : LE SUSPECT TOUJOURS EN FUITE');
    add('cars', 'VAGUE DE VOLS DE VOITURES : {carsN} CETTE NUIT');
    add('war', 'GUERRE DE GANGS : LES {gang} PROMETTENT VENGEANCE');
    add('hacks', 'CYBERATTAQUES EN SÉRIE : {hacks} SYSTÈMES PIRATÉS');
    add('psycho', 'ALERTE CYBERPSYCHO : {psycho} SIGNALÉ À {psite}');
    add('legacy', 'LA RUE PLEURE {prev}. UN NOUVEAU VISAGE À LA PLANQUE ?');
    const ads = ADS.slice().sort(() => Math.random() - 0.5);
    while (n.length < 4) n.push(ads.pop());
    n.splice(2, 0, ads.pop());
    return n;
  };

  // ---------- au début de chaque gig ----------
  H.startGig = function () {
    const g = G();
    g.luna = { nom: 'LUNA' };
    g.newsList = H.news();
    g.newsT = 0;
    g.bubble = null; g.barked = {}; g.barMenu = null; g.angelUsed = false;
  };
  // En arrivant à la planque, tout le monde a de nouveau quelque chose à dire.
  H.onEnter = function (def) {
    const g = G();
    g.barked = {}; g.bubble = null;
    if (def.npcs && def.npcs.luna) Object.assign(g.luna, { x: def.npcs.luna[0] * 8 + 4, y: def.npcs.luna[1] * 8 + 4, aim: -Math.PI / 2 });
  };
  function speakers() {
    const g = G(), s = [['doc', g.doc], ['fixer', g.fixer], ['gunsmith', g.gunsmith], ['luna', g.luna]];
    if (g.recruit) s.push(['recruit', g.recruit]);
    return s;
  }
  H.update = function (dt) {
    const g = G();
    g.newsT += dt;
    if (g.bubble) { g.bubble.t -= dt; if (g.bubble.t <= 0) g.bubble = null; }
    if (M.id !== 'planque' || g.bubble) return;
    const p = g.player;
    for (const [who, o] of speakers()) {
      if (!o || g.barked[who] || C.dist(p.x, p.y, o.x, o.y) > 36) continue;
      g.barked[who] = true;
      g.bubble = { o, text: H.line(who), t: 4.5 };
      C.sfx('empty');
      break;
    }
  };

  // ---------- le bar de Luna ----------
  const BAR = [
    { id: 'sake', nom: 'SYNTHÉ-SAKÉ', prix: 20, desc: '+30 PV' },
    { id: 'ange', nom: 'LARME D\'ANGE', prix: 80, desc: '+10 HUMANITÉ · UNE PAR GIG' },
    { id: 'tuyau', nom: 'TUYAU DE LUNA', prix: 50, desc: 'ENNEMIS RÉVÉLÉS DANS LE PROCHAIN BÂTIMENT' },
    { id: 'tournee', nom: 'TOURNÉE POUR L\'ÉQUIPE', prix: 60, desc: '+15 LOYAUTÉ DU COMPAGNON' },
  ];
  H.barItems = () => BAR;
  H.acts = function (acts, close) {
    const g = G();
    if (M.id === 'planque' && g.luna && g.luna.x != null && close(g.luna, 22)) acts.push(['PARLER À LUNA (BAR)', H.openBar]);
  };
  H.openBar = function () {
    const g = G();
    g.barMenu = { sel: 0, msg: H.line('luna'), msgCol: '#c7d5e0', msgT: 99, lmx: C.input.mx, lmy: C.input.my };
    C.sfx('spare');
  };
  function serve(it) {
    const g = G(), s = g.barMenu, p = g.player, L0 = g.leader;
    const set = (t, c) => { s.msg = t; s.msgCol = c; s.msgT = 3; };
    if (it.id === 'sake' && p.hp >= p.maxHp) return set('T\'ES EN PLEINE FORME. GARDE TES EDDIES.', '#8f98a0');
    if (it.id === 'ange' && g.angelUsed) return set('UNE SEULE PAR NUIT. ORDRE DU DOC.', '#8f98a0');
    if (it.id === 'ange' && g.humanity >= 100) return set('T\'ES DÉJÀ PLUS HUMAIN QUE MOI.', '#8f98a0');
    if (it.id === 'tuyau' && g.revealPending) return set('TU SAIS DÉJÀ TOUT CE QUE JE SAIS.', '#8f98a0');
    if (it.id === 'tournee' && !(g.comp && g.comp.state === 'up')) return set('UNE TOURNÉE POUR QUI ? T\'ES SEUL.', '#8f98a0');
    if (L0.eddies < it.prix) return set('PAS D\'EDDIES, PAS DE VERRE.', '#ff5a7a');
    L0.eddies -= it.prix;
    C.sfx('reload');
    switch (it.id) {
      case 'sake': p.hp = Math.min(p.maxHp, p.hp + 30); return set('CUL SEC. ÇA RÉCHAUFFE, HEIN ?', '#5dff9a');
      case 'ange': g.angelUsed = true; g.humanity = Math.min(100, g.humanity + 10); return set('TU TE SENS UN PEU PLUS TOI-MÊME.', '#ff9ad8');
      case 'tuyau': g.revealPending = true; return set('UN AMI M\'A FILÉ LES PLANS DU BÂTIMENT. CHUT.', '#5dff9a');
      case 'tournee': g.comp.loyalty = Math.min(100, g.comp.loyalty + 15); return set(g.comp.nom + ' LÈVE SON VERRE À TA SANTÉ.', '#3ec8ff');
    }
  }
  let rows = [];
  H.rowUnderMouse = () => { const { mx, my } = C.input; return rows.findIndex(([x, y, w, h]) => mx >= x && mx < x + w && my >= y && my < y + h); };
  H.updateBar = function () {
    const g = G(), s = g.barMenu, I = C.input, n = BAR.length;
    s.msgT -= C.STEP;
    if (C.keyHit('ArrowUp') || C.keyHit('KeyW')) s.sel = (s.sel + n - 1) % n;
    if (C.keyHit('ArrowDown') || C.keyHit('KeyS')) s.sel = (s.sel + 1) % n;
    const row = H.rowUnderMouse();
    if (row >= 0 && (I.mx !== s.lmx || I.my !== s.lmy)) s.sel = row;
    s.lmx = I.mx; s.lmy = I.my;
    if (C.keyHit('KeyE') || C.keyHit('Enter') || (I.mhit[0] && row >= 0)) serve(BAR[s.sel]);
    else if (C.keyHit('Escape') || I.mhit[2]) g.barMenu = null;
  };

  // ---------- dessin ----------
  const T = (g, s, x, y, c, o = {}) => C.text(g, s, x, y, c, o);
  const box = (g, x, y, w, h, c) => { g.fillStyle = c; g.fillRect(Math.round(x), Math.round(y), w, h); };
  const TV = { x: 92, y: 9, w: 44, h: 13 };   // écran mural N54, en pixels de la planque
  // Le comptoir, les bouteilles et l'écran N54 (calque du décor, éclairé).
  H.drawFloor = function (g, t) {
    const gm = G();
    if (M.id !== 'planque') return;
    // comptoir de Luna (les tuiles bloquantes 5-7, 12)
    box(g, 39, 95, 26, 10, '#05050a');
    box(g, 40, 96, 24, 8, '#3a1a2a');
    box(g, 40, 96, 24, 2, '#6a2a4a');
    box(g, 40, 103, 24, 1, '#ff3ec8');
    const cols = ['#3ef0ff', '#5dff9a', '#ffd23e', '#ff3ec8', '#ff7a1a'];
    for (let i = 0; i < 6; i++) { box(g, 42 + i * 4, 92, 2, 4, cols[i % 5]); box(g, 42 + i * 4, 91, 2, 1, '#e8f6ff'); }
    // écran N54 : cadre, image qui défile, bandeau rouge
    box(g, TV.x - 1, TV.y - 1, TV.w + 2, TV.h + 2, '#05050a');
    box(g, TV.x, TV.y, TV.w, TV.h, '#0b1830');
    box(g, TV.x, TV.y, 12, 6, '#d01830');
    T(g, 'N54', TV.x + 1, TV.y + 1, '#ffffff');
    for (let i = 0; i < 4; i++) box(g, TV.x + 14 + i * 7, TV.y + 2 + ((Math.sin(t * 2 + i) + 1) * 1.5 | 0), 5, 3, i % 2 ? '#3ef0ff' : '#2a5a8a');
    g.save();
    g.beginPath(); g.rect(TV.x, TV.y + 7, TV.w, 6); g.clip();
    box(g, TV.x, TV.y + 7, TV.w, 6, '#d01830');
    const s = (gm.newsList || []).join('  //  ');
    const w = C.textWidth(s) + 40, off = (t * 22) % w;
    T(g, s, TV.x + TV.w - off, TV.y + 8, '#ffffff');
    T(g, s, TV.x + TV.w - off + w, TV.y + 8, '#ffffff');
    g.restore();
  };
  // Luna derrière son comptoir.
  H.drawActors = function (a, t, drawChar) {
    const gm = G();
    if (M.id !== 'planque' || !gm.luna || gm.luna.x == null) return;
    drawChar(a, gm.luna.x + Math.sin(t * 0.7) * 6, gm.luna.y, gm.luna.aim, { jacket: '#1a1a2a', hair: '#e8e8ff', skin: '#e0b090', pose: 'bare' });
  };
  // Noms et bulles de dialogue (coordonnées du monde).
  H.drawTags = function (g, t, tag) {
    const gm = G();
    if (M.id !== 'planque') return;
    if (gm.luna && gm.luna.x != null) tag(gm.luna.x, gm.luna.y - 14, 'LUNA · BAR', '#ff9ad8');
    const b = gm.bubble;
    if (!b || !b.o) return;
    const lines = b.text.split('\n'), w = Math.max(...lines.map(s => C.textWidth(s))) + 8, h = lines.length * 7 + 5;
    const x = Math.round(C.clamp(b.o.x - w / 2, gm.cam.x + 2, gm.cam.x + C.W - w - 2)), above = b.o.y - 22 - h, y = Math.round(above < gm.cam.y + 42 ? b.o.y + 12 : above);   // pas de place au-dessus (HUD) : la bulle passe dessous
    g.globalAlpha = Math.min(1, b.t * 3);
    box(g, x - 1, y - 1, w + 2, h + 2, '#05050a');
    box(g, x, y, w, h, '#14182a');
    box(g, x, y, w, 1, '#ffd23e');
    const tx = C.clamp(Math.round(b.o.x), x + 3, x + w - 4);
    if (y > b.o.y) { box(g, tx - 1, y - 1, 3, 1, '#14182a'); box(g, tx, y - 3, 1, 2, '#14182a'); }
    else { box(g, tx - 1, y + h, 3, 1, '#14182a'); box(g, tx, y + h + 1, 1, 2, '#14182a'); }
    lines.forEach((s, i) => T(g, s, x + 4, y + 3 + i * 7, '#e8eef6'));
    g.globalAlpha = 1;
  };
  // Bandeau N54 en haut de l'écran quand on regarde la télé.
  H.drawHUD = function (g) {
    const gm = G();
    if (M.id !== 'planque' || !gm.newsList) return;
    const p = gm.player;
    if (C.dist(p.x, p.y, TV.x + TV.w / 2, TV.y + TV.h) > 44) return;
    const y = C.H - 40;
    box(g, 0, y - 2, C.W, 10, 'rgba(120,8,24,0.9)');
    box(g, 0, y - 2, 30, 10, '#05050a');
    T(g, 'N54 NEWS', 2, y, '#ff3e5a');
    g.save(); g.beginPath(); g.rect(31, y - 2, C.W - 31, 10); g.clip();
    const s = gm.newsList.join('   //   ');
    const w = C.textWidth(s) + 60, off = (gm.newsT * 34) % w;
    T(g, s, C.W - off, y, '#ffffff');
    T(g, s, C.W - off + w, y, '#ffffff');
    g.restore();
  };
  H.drawBar = function (g) {
    const gm = G(), s = gm.barMenu, L0 = gm.leader;
    g.fillStyle = 'rgba(4,3,10,0.7)'; g.fillRect(0, 0, C.W, C.H);
    const w = 280, h = 140, x = Math.round((C.W - w) / 2), y = Math.round((C.H - h) / 2);
    box(g, x, y, w, h, '#0b0a16');
    box(g, x, y, w, 1, '#ff9ad8');
    g.fillStyle = '#2d3150'; g.fillRect(x, y + h - 1, w, 1); g.fillRect(x, y, 1, h); g.fillRect(x + w - 1, y, 1, h);
    T(g, 'LUNA · BAR DE LA PLANQUE', x + 6, y + 6, '#d8dde6');
    T(g, L0.eddies + ' €$', x + w - 6, y + 6, '#ffd23e', { align: 'right' });
    rows = [];
    BAR.forEach((it, i) => {
      const ry = y + 20 + i * 18, sel = i === s.sel;
      rows.push([x + 3, ry - 2, w - 6, 17]);
      box(g, x + 3, ry - 2, w - 6, 17, sel ? 'rgba(255,154,216,0.16)' : 'rgba(255,255,255,0.03)');
      box(g, x + 10, ry + 1, 3, 9, ['#3ef0ff', '#ff9ad8', '#5dff9a', '#ffd23e'][i]); box(g, x + 11, ry - 1, 1, 2, '#e8f6ff');
      T(g, it.nom, x + 20, ry, '#ffffff');
      T(g, it.desc, x + 20, ry + 8, '#8f98a0');
      T(g, it.prix + ' €$', x + w - 8, ry, L0.eddies >= it.prix ? '#ffd23e' : '#6f7c8a', { align: 'right' });
    });
    const msg = s.msg.split('\n');
    msg.forEach((m, i) => T(g, m, C.W / 2, y + h - 28 + i * 7 - (msg.length - 1) * 3, s.msgCol, { align: 'center' }));
    T(g, '[HAUT/BAS] CHOISIR   [E] COMMANDER   [ÉCHAP] SORTIR', C.W / 2, y + h - 10, '#6f7c8a', { align: 'center' });
    const mx = Math.round(C.input.mx), my = Math.round(C.input.my);
    box(g, mx - 1, my - 1, 3, 3, '#05050a'); box(g, mx, my, 1, 1, '#ffffff');
  };

  // ---------- sauvegarde de la partie ----------
  const KEY = 'cel-partie';
  const RUN = (C.run = {});
  RUN.save = function () {
    const g = G();
    if (!g.leader || !g.player) return;
    const p = g.player, player = {};
    for (const k of ['hp', 'maxHp', 'inj', 'maxInj', 'speedMul', 'mag', 'weapon', 'melee']) player[k] = p[k];
    const data = { v: 1, leader: g.leader, reg: g.reg, humanity: g.humanity, player, reveal: !!g.revealPending, angel: !!g.angelUsed, when: Date.now() };
    // les cibles du compagnon et autres liens vers des ennemis ne se sauvegardent pas
    try { localStorage.setItem(KEY, JSON.stringify(data, (k, val) => (k === 'target' ? null : val))); } catch (e) { /* pas de stockage */ }
  };
  RUN.load = function () {
    try { const d = JSON.parse(localStorage.getItem(KEY) || 'null'); return d && d.v === 1 && d.leader ? d : null; } catch (e) { return null; }
  };
  RUN.clear = () => { try { localStorage.removeItem(KEY); } catch (e) { /* rien */ } };
  // Résumé pour l'écran titre.
  RUN.info = function () {
    const d = RUN.load();
    return d ? { nom: d.leader.nom, gigs: d.leader.gigs, eddies: d.leader.eddies, lvl: d.leader.lvl || 1 } : null;
  };
  // Abandonner le leader sauvegardé : il disparaît (inscrit au mur des légendes), son compagnon reste dans la ville.
  RUN.abandon = function () {
    const d = RUN.load();
    if (d) C.legacy.endLeader({ leader: d.leader, reg: d.reg, comp: d.leader.comp, player: d.player }, 'disparu');
    RUN.clear();
  };
})();
