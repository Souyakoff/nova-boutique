'use strict';
// Trafic : des voitures qui roulent vraiment dans les rues, et les voitures du NCPD qui te prennent en chasse.
//
// Réseau routier : construit depuis les bandes de chaussée de la carte (H et V de districts.js). On suit la ligne
// centrale de chaque bande : chaque portion de route continue devient une suite d'arêtes entre carrefours
// (une voiture garée ou un bus en travers ne coupent pas la route, un bloc de décor oui).
// Une voiture roule sur la voie de droite (9 px à droite de l'axe), vise un point 18 px devant elle, ralentit
// avant de tourner, freine devant un piéton ou toi, klaxonne si tu restes planté. Bloquée trop longtemps, elle
// tente de doubler par la gauche. Arrivée au bout d'une route hors de l'écran, elle réapparaît ailleurs.
// La police roule plus vite, choisit à chaque carrefour la route qui la rapproche de toi, fonce droit sur toi
// quand elle te voit, et ses agents débarquent quand elle est assez près.
(function () {
  const C = CEL, D = C.DEF, M = C.map;
  const TR = (C.traffic = {});
  const G = () => C.game;
  const ROAD = t => t === 'r' || t === '=';
  const LANE = 7;   // demi-largeur d'une voie : les deux sens se croisent sans se toucher
  const graphs = {};

  // ---------- réseau routier ----------
  function build() {
    const def = M.def, nodes = new Map(), edges = [];
    const node = (x, y) => { const k = Math.round(x) + ',' + Math.round(y); if (!nodes.has(k)) nodes.set(k, { x, y, out: [] }); return nodes.get(k); };
    const link = (a, b) => {
      if (a === b) return;
      for (const [p, q] of [[a, b], [b, a]]) {
        const dx = q.x - p.x, dy = q.y - p.y, len = Math.hypot(dx, dy);
        const e = { a: p, b: q, len, dx: dx / len, dy: dy / len, nx: -dy / len, ny: dx / len };
        p.out.push(e); edges.push(e);
      }
    };
    const okTile = (tx, ty) => ROAD(M.tile(tx, ty)) && !M.blocked(tx, ty);
    const runs = (n, at) => { const R = []; let s = -1; for (let i = 0; i <= n; i++) { const ok = i < n && at(i); if (ok && s < 0) s = i; if (!ok && s >= 0) { R.push([s, i - 1]); s = -1; } } return R; };
    const H = def.H || [], V = def.V || [];
    for (const [a, b] of H) {
      const cy = (a + b + 1) * 4, ty = Math.floor(cy / 8);
      for (const [x0, x1] of runs(M.MW, tx => okTile(tx, ty))) {
        const xs = [x0 * 8 + 4, x1 * 8 + 4];
        for (const [va, vb] of V) { const cx = (va + vb + 1) * 4; if (cx > xs[0] && cx < xs[1]) xs.push(cx); }
        xs.sort((p, q) => p - q);
        for (let i = 0; i + 1 < xs.length; i++) link(node(xs[i], cy), node(xs[i + 1], cy));
      }
    }
    for (const [a, b] of V) {
      const cx = (a + b + 1) * 4, tx = Math.floor(cx / 8);
      for (const [y0, y1] of runs(M.MH, ty => okTile(tx, ty))) {
        const ys = [y0 * 8 + 4, y1 * 8 + 4];
        for (const [ha, hb] of H) { const cy = (ha + hb + 1) * 4; if (cy > ys[0] && cy < ys[1]) ys.push(cy); }
        ys.sort((p, q) => p - q);
        for (let i = 0; i + 1 < ys.length; i++) link(node(cx, ys[i]), node(cx, ys[i + 1]));
      }
    }
    return { nodes: [...nodes.values()], edges: edges.filter(e => e.len > 12) };
  }
  TR.graph = () => graphs[M.id] || (graphs[M.id] = build());

  // ---------- voitures ----------
  const MODELS = ['makigai', 'makigai', 'galena', 'galena', 'galena', 'turbo'];
  const COLORS = ['#5a1a2a', '#1a3a5a', '#3a3a3a', '#5a4a1a', '#2a4a3a', '#4a4a5c', '#c4142b', '#2a6fdb', '#e8e8f0', '#1a1a22', '#7a3cff', '#f2d43a'];
  const lanePoint = (e, s, off) => [e.a.x + e.dx * s + e.nx * off, e.a.y + e.dy * s + e.ny * off];
  const onScreen = (x, y, m = 30) => { const g = G(); return x > g.cam.x - m && x < g.cam.x + C.W + m && y > g.cam.y - m && y < g.cam.y + C.H + m; };
  // Place une voiture sur une arête hors de l'écran (ou n'importe où au début).
  function place(car, anywhere) {
    const gr = TR.graph(), g = G();
    for (let k = 0; k < 40; k++) {
      const e = gr.edges[(Math.random() * gr.edges.length) | 0];
      if (!e || e.len < 30) continue;
      const s = 12 + Math.random() * (e.len - 24), [x, y] = lanePoint(e, s, LANE);
      if (!anywhere && onScreen(x, y, 50)) continue;
      if (C.dist(x, y, g.player.x, g.player.y) < 60) continue;
      Object.assign(car, { x, y, ang: Math.atan2(e.dy, e.dx), speed: 0 });
      car.ai.edge = e; car.ai.stuckT = 0; car.ai.passT = 0;
      if (!C.cars.blocked(car, g.cars)) return true;
    }
    return false;
  }
  TR.spawn = function () {
    const def = M.def, g = G(), list = [];
    if (!def.outdoor || !TR.graph().edges.length) return list;
    const n = def.traffic == null ? 8 : def.traffic;
    for (let i = 0; i < n; i++) {
      const model = MODELS[(Math.random() * MODELS.length) | 0];
      const car = { model, color: COLORS[(Math.random() * COLORS.length) | 0], own: false, ai: { cruise: C.cars.MODELS[model].speed * 0.42 } };
      g.cars.push(car);
      if (place(car, true)) list.push(car); else g.cars.pop();
    }
    return list;
  };
  // Voiture de patrouille qui arrive en roulant avec deux agents à bord.
  TR.spawnPolice = function (type) {
    const g = G();
    if (!M.def.outdoor || !TR.graph().edges.length) return false;
    const car = { model: 'galena', color: '#e8e8f0', police: true, own: false, ai: { cruise: 95, police: true, crew: [type, type] } };
    g.cars.push(car);
    if (place(car, false)) return true;
    g.cars.pop();
    return false;
  };
  TR.pendingCops = () => (G().cars || []).reduce((n, c) => n + (c.ai && c.ai.crew ? c.ai.crew.length : 0), 0);

  // Prochaine arête au bout de e : tout droit ou on tourne, rarement demi-tour ; la police va vers toi.
  function nextEdge(car, e) {
    const opts = e.b.out.filter(o => o.b !== e.a);
    if (!opts.length) return null;   // cul-de-sac
    if (car.ai.police) {
      const p = G().player;
      return opts.reduce((best, o) => (C.dist(o.b.x, o.b.y, p.x, p.y) < C.dist(best.b.x, best.b.y, p.x, p.y) ? o : best));
    }
    const straight = opts.find(o => Math.abs(o.dx - e.dx) < 0.1 && Math.abs(o.dy - e.dy) < 0.1);
    if (straight && Math.random() < 0.55) return straight;
    return opts[(Math.random() * opts.length) | 0];
  }
  // Quelqu'un (ou quelque chose) juste devant ?
  // On regarde dans sa voie : devant (jusqu'à dist) et dans sa largeur (half), pas sur le trottoir d'à côté.
  function blockedAhead(car, dist, half = 7) {
    const g = G(), ca = Math.cos(car.ang), sa = Math.sin(car.ang), m = C.cars.MODELS[car.model];
    const ahead = (o, w) => { const dx = o.x - car.x, dy = o.y - car.y, f = dx * ca + dy * sa, l = Math.abs(-dx * sa + dy * ca); return f > m.len / 2 - 2 && f < dist + m.len / 2 && l < w; };
    if (!g.drive && ahead(g.player, half + 3)) return 'player';
    for (const q of g.peds) if (!q.dead && ahead(q, half + 3)) return 'ped';
    for (const e of g.enemies) if (g.ALIVE(e) && ahead(e, half + 3)) return 'ped';
    for (const o of g.cars) {
      if (o === car || !ahead(o, half + 7)) continue;
      if (o === g.drive) return 'player';
      if (o.ai && Math.abs(C.angDiff(o.ang, car.ang)) > 2.3) return 'face';   // face à face
      // garée, ou plantée là depuis un moment : on pourra la doubler ; sinon c'est juste la file
      return Math.abs(o.speed || 0) < 3 && (!o.ai || o.ai.stuckT > 3) ? 'still' : 'car';
    }
    return null;
  }

  TR.update = function (dt) {
    const g = G();
    if (!M.def.outdoor || !g.cars) return;
    const p = g.player;
    for (const car of g.cars) {
      const ai = car.ai;
      if (!ai || car === g.drive) continue;
      let e = ai.edge;
      if (!e) continue;
      // où en est-on sur l'arête ?
      const s = (car.x - e.a.x) * e.dx + (car.y - e.a.y) * e.dy;
      if (s > e.len - 28 && !ai.next) ai.next = nextEdge(car, e) || 'end';
      if (s > e.len - 6) {
        if (ai.next === 'end') {
          // au bord de la carte, elle sort du quartier ; ailleurs, hors de l'écran, elle réapparaît plus loin
          const border = e.b.x < 14 || e.b.y < 14 || e.b.x > M.MW * 8 - 14 || e.b.y > M.MH * 8 - 14;
          if (border || !onScreen(car.x, car.y)) { if (!place(car, false)) car.speed = 0; ai.next = null; continue; }
          ai.next = e.b.out.find(o => o.b === e.a) || null;   // demi-tour à l'écran
        }
        if (ai.next) { ai.edge = e = ai.next; ai.next = null; }
      }
      // cible : un point sur la voie, un peu devant ; ou droit sur toi pour la police qui te voit
      const s2 = Math.max(0, (car.x - e.a.x) * e.dx + (car.y - e.a.y) * e.dy) + 18;
      const off = ai.passT > 0 ? -2 : LANE;
      let [tx, ty] = s2 <= e.len || !ai.next || ai.next === 'end' ? lanePoint(e, Math.min(s2, e.len), off) : lanePoint(ai.next, s2 - e.len, off);
      let want = ai.cruise * (ai.panicT > 0 ? 1.7 : 1);
      const dp = C.dist(car.x, car.y, p.x, p.y), sees = ai.police && dp < 140 && M.los(car.x, car.y, p.x, p.y);
      if (sees) { tx = p.x; ty = p.y; }
      // virage serré : on ralentit
      const turn = Math.abs(C.angDiff(car.ang, Math.atan2(ty - car.y, tx - car.x)));
      if (!sees && turn > 0.5) want = Math.min(want, 30);
      // police : arrivée sur toi, les agents descendent
      if (ai.police && (dp < (g.drive ? 46 : 60) && (!g.drive || Math.abs(g.drive.speed) < 25) || ai.stuckT > 2.5) && dp < 160) { deploy(car); continue; }
      // obstacles : on freine (sauf la police lancée sur toi, et les chauffards paniqués)
      const block = blockedAhead(car, 14 + Math.abs(car.speed) * 0.3, ai.passT > 0 ? 5 : 7);
      if (block && !(sees && block === 'player') && !(ai.panicT > 0 && block === 'ped')) {
        want = 0;
        // derrière une voiture immobile : on patiente, puis on double
        if (block === 'still') { ai.stuckT += dt; if (ai.stuckT > 1.2 && ai.passT <= 0) ai.passT = 2; }
        // nez à nez : celui qui doublait (ou le second arrivé) recule et rentre dans sa voie
        if (block === 'face') { ai.stuckT += dt; if (ai.passT > 0 || ai.stuckT > 0.8) { ai.passT = 0; ai.backT = 0.7; ai.stuckT = 0; } }
        if (block === 'player') { ai.honkT = (ai.honkT || 0) + dt; if (ai.honkT > 1.2) { ai.honkT = -1.5; g.fx.addFloat(car.x, car.y - 14, 'TUUUT !', '#ffd23e'); C.sfx('honk'); } }
      }
      ai.panicT = (ai.panicT || 0) - dt; ai.passT -= dt; ai.backT = (ai.backT || 0) - dt;
      if (ai.backT > 0) want = -22;
      // conduite : on tourne vers la cible, on accélère ou on freine
      const oa = car.ang;
      car.ang = C.turn(car.ang, Math.atan2(ty - car.y, tx - car.x), dt * (ai.police ? 4.5 : 3.2) * Math.min(1, Math.abs(car.speed) / 20 + 0.3));
      if (C.cars.blocked(car, g.cars)) car.ang = oa;   // on ne braque pas dans un mur
      car.speed += C.clamp(want - car.speed, -160 * dt, (ai.police ? 140 : 70) * dt);
      const ox = car.x, oy = car.y;
      car.x += Math.cos(car.ang) * car.speed * dt; car.y += Math.sin(car.ang) * car.speed * dt;
      if (C.cars.blocked(car, g.cars)) {
        car.x = ox; car.y = oy;
        if (ai.police && g.drive && C.cars.circles(car).some(([x, y, r]) => C.cars.hitCircle(x, y, r + 2, [g.drive])) && Math.abs(car.speed) > 50) { G().shake = Math.max(G().shake, 4); C.sfx('hit'); }   // il te percute
        car.speed = 0;
        ai.stuckT += dt;
        if (ai.stuckT > 1.2 && ai.passT <= 0) ai.passT = 2;   // on tente de doubler
        if (ai.stuckT > 3) { car.ang += (Math.random() - 0.5) * 0.4; car.x -= Math.cos(car.ang) * 2; car.y -= Math.sin(car.ang) * 2; if (C.cars.blocked(car, g.cars)) { car.x += Math.cos(car.ang) * 2; car.y += Math.sin(car.ang) * 2; } }   // on recule un peu
        if (ai.stuckT > 6 && !onScreen(car.x, car.y)) place(car, false);
      } else if (Math.abs(car.speed) > 5) ai.stuckT = Math.max(0, ai.stuckT - dt);
      // filet de sécurité : moins de 10 px parcourus en 4 s hors de l'écran, on la replace ailleurs
      if (!ai.chk) ai.chk = { x: car.x, y: car.y, t: 0 };
      ai.chk.t += dt;
      if (ai.chk.t > 4) {
        if (C.dist(car.x, car.y, ai.chk.x, ai.chk.y) < 10 && !onScreen(car.x, car.y)) place(car, false);
        ai.chk = { x: car.x, y: car.y, t: 0 };
      }
    }
  };
  // Les agents descendent de la voiture, qui reste garée gyrophares allumés.
  function deploy(car) {
    const g = G(), p = g.player, ca = Math.cos(car.ang), sa = Math.sin(car.ang);
    for (const [i, type] of car.ai.crew.entries()) {
      const side = i ? -1 : 1, ex = car.x - sa * 14 * side, ey = car.y + ca * 14 * side;
      const e = g.fx.makeEnemy(type, 0, 0, {}, -1);
      Object.assign(e, { x: ex, y: ey, cop: true, nom: D.enemies[type].name, state: 'alert', react: 0.5, aim: Math.atan2(p.y - ey, p.x - ex) });
      if (M.solidAt(ex, ey)) { e.x = car.x - ca * 20; e.y = car.y - sa * 20; }
      g.enemies.push(e);
    }
    car.ai = null; car.speed = 0; car.parked = true;
    C.sfx('dash');
  }

  // ---------- voler une voiture ----------
  // Une voiture du trafic arrêtée (ou garée) : on éjecte le conducteur, il s'enfuit en criant.
  TR.stealable = function () {
    const g = G(), p = g.player;
    if (!M.def.outdoor || g.drive) return null;
    for (const car of g.cars) {
      if (car.own || car.police || car === g.leader.car) continue;
      if (Math.abs(car.speed || 0) > 20) continue;
      if (C.cars.hitCircle(p.x, p.y, p.r + 6, [car])) return car;
    }
    return null;
  };
  TR.steal = function (car) {
    const g = G(), p = g.player;
    if (car.ai) {
      // le conducteur est jeté dehors
      const spot = M.randomFloorNear(car.x, car.y, 14, 30);
      if (spot) {
        const look = C.sprites.randomLook();
        g.peds.push({ x: spot[0], y: spot[1], r: 3, aim: 0, walk: 0, tx: null, ty: null, wait: 0, speed: 24, jacket: '#4a6fa5', hp: D.civilian.hp, dead: false, outfit: look, panicT: 6, fromX: p.x, fromY: p.y });
        g.fx.addFloat(spot[0], spot[1] - 10, 'MA VOITURE !', '#ffffff');
      }
    }
    car.ai = null; car.parked = false; car.stolen = true;
    C.ncpd.crime('carjack', car.x, car.y);
    C.home.note('cars');
    C.music.event('carjack');
    g.fx.enterCar(car);
  };
  // Une balle dans la carrosserie : le conducteur panique et file.
  TR.shot = function (car) { if (car.ai && !car.ai.police) car.ai.panicT = 5; };
})();
