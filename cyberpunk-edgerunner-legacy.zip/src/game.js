'use strict';
// Règles du combat : joueur, ennemis, balles, Sandevistan, humanité, registre de la partie.
(function () {
  const C = CEL, D = C.DEF, M = C.map;
  const G = (C.game = { mode: 'title' });   // title | create | play | over
  const L = () => C.legacy;
  const ALIVE = e => e.state === 'idle' || e.state === 'alert';

  // ---------- mise en place ----------
  // Nouveau leader (choisi sur l'écran de création) : premier gig, avec l'héritage des leaders passés.
  G.start = function (profile) {
    G.leader = {
      nom: profile.nom, origine: profile.origine, lien: profile.lien || null, gigs: 0, spared: [], comp: null,
      eddies: D.eddies.start, implants: { 'SYSTÈME': 'sandy1', DECK: 'deck1' },   // emplacement -> implant posé
      arcs: { arasaka: 0, militech: 0 }, burned: false,             // contrats remplis par faction ; grillé après un grand contrat raté
    };
    if (profile.companion) L().useCompanion(profile.nom);   // un ancien compagnon prend la tête
    C.skills.init(G.leader);   // expérience, niveau, compétences (skills.js)
    G.reg = { acheves: 0, epargnes: 0, tirs: 0, touches: 0, temps: 0 };
    G.newGig(true);
    G.mode = 'play';
  };
  // Pour les tests et le premier lancement : un leader quelconque.
  G.reset = function () { G.start(L().profiles()[0]); };

  // Un gig commence toujours à la planque. Le même leader garde ses PV, injecteurs, munitions et son humanité.
  // Les bâtiments sont remis à neuf à chaque gig (G.sites).
  // resume : reprise d'une partie sauvegardée (même numéro de gig, même graine).
  G.newGig = function (fresh, resume) {
    if (!fresh && !resume) C.home.closeGig();   // le gig qui se termine : la planque s'en souviendra (planque.js)
    if (fresh) G.leader.last = null;
    if (!resume) G.leader.log = C.home.blankLog();
    C.reseed(20771 + ((G.leader.gigs - (resume ? 1 : 0)) * 7919));
    const old = G.player;
    G.player = {
      x: 0, y: 0, r: D.player.radius, vx: 0, vy: 0, aim: 0, walk: 0,
      hp: D.player.hp, maxHp: D.player.hp, inj: D.player.injectors, maxInj: D.player.injectors, injT: 0, speedMul: 1,
      dashT: 0, dashCd: 0, dashX: 0, dashY: 0, invT: 0,
      fireCd: 0, mag: D.weapons.pistol.mag, reloadT: 0, meleeCd: 0, slashT: 0, slashA: 0, hurtT: 0,
      weapon: 'pistol', melee: 'blade',   // arme à feu en main et arme de corps à corps (arsenal.js)
    };
    if (fresh) {
      L().origin(G.leader.origine).apply(G.player);
      G.humanity = D.humanity.start;
    } else {
      for (const k of ['hp', 'maxHp', 'inj', 'maxInj', 'speedMul', 'mag', 'weapon', 'melee']) G.player[k] = old[k];
    }
    if (!resume) G.leader.gigs++;
    G.weather = C.amb.rollWeather(G.leader);   // pluie ou pas, pour tout le gig
    refreshMods();
    G.ram = G.mods.ramMax;   // la RAM du cyberdeck repart pleine à chaque gig
    G.uploads = []; G.breach = null; G.scanOn = false; G.scanT = null;
    C.ncpd.reset();   // on se fait oublier entre deux gigs
    if (!fresh && !resume) C.gangs.cool();   // et les gangs digèrent un peu
    G.dropsByMap = {}; G.gunMenu = null; G.pHack = null;
    G.gunsmith = { nom: 'RUSTY' };
    G.sites = {};
    G.sandy = { on: false, charge: D.sandy.duration * G.mods.sandyDur, trailT: 0 };
    G.time = 0; G.shake = 0; G.hitstop = 0; G.flash = 0; G.redFlash = 0; G.muzzle = 0; G.revealT = 0;
    G.hallT = 4; G.glitchT = 0; G.overReason = null; G.overT = 0;
    G.shop = null; G.bioUsed = false; G.ride = null; G.secondUsed = false; G.skillMenu = null;
    G.contract = null; G.board = null; G.offers = null; G.endT = 0;
    // le fixer de la planque : Mama Reyes, ou le dernier leader devenu fixer
    const fx = L().city.fixer;
    G.fixer = fx ? { nom: fx.nom, stars: fx.stars, former: true } : { nom: 'MAMA REYES', stars: 0, former: false };
    G.doc = { nom: 'DOC ZHAO' };
    // le compagnon suit le leader d'un gig à l'autre ; sinon une recrue attend dans la planque
    G.comp = G.leader.comp;
    G.recruit = G.comp ? null : L().recruitCandidate(G.leader);
    C.home.startGig();   // Luna, N54 NEWS, bulles des PNJ
    if (C.render) C.render.clearWorlds();
    G.enterMap('planque', null);
    C.run.save();   // point de sauvegarde : début du gig, à la planque
  };
  // CONTINUER sur l'écran titre : on reprend le leader sauvegardé, au début de son gig, à la planque.
  G.resume = function () {
    const d = C.run.load();
    if (!d) return false;
    G.leader = d.leader;
    C.skills.init(G.leader);
    if (!G.leader.log) G.leader.log = C.home.blankLog();
    G.reg = d.reg; G.humanity = d.humanity;
    G.player = Object.assign({}, d.player);
    G.newGig(false, true);
    G.revealPending = !!d.reveal; G.angelUsed = !!d.angel;   // le tuyau de Luna et la larme d'ange déjà payés
    G.mode = 'play';
    return true;
  };

  // Changer de carte : la planque, la rue, ou un bâtiment (son état est gardé jusqu'à la fin du gig).
  G.enterMap = function (id, doorId) {
    const from = M.id, before = G.player ? { x: G.player.x, y: G.player.y } : null;   // où on était, pour l'otage qui suit
    M.load(id);
    const def = M.def, p = G.player;
    const d = doorId ? M.door(doorId) : null;
    const [sx, sy] = d ? [d.sx, d.sy] : def.start;
    p.x = sx * 8 + 4; p.y = sy * 8 + 4; p.vx = p.vy = 0; p.dashT = 0;
    G.bullets = []; G.parts = []; G.trail = []; G.ghosts = []; G.floats = []; G.peds = []; G.uploads = []; G.scanOn = false; G.scanT = null;
    G.corpse = null; G.near = null; G.nearCorpse = null; G.prompt = null; G.alertedOnce = false;
    G.sandy.on = false;
    const at = (t, aim) => ({ x: t[0] * 8 + 4, y: t[1] * 8 + 4, aim });
    if (id === 'planque') {
      Object.assign(G.doc, at(def.npcs.doc, 0.6));
      Object.assign(G.fixer, at(def.npcs.fixer, Math.PI));
      if (G.recruit) Object.assign(G.recruit, at(def.npcs.recruit, 0));
      Object.assign(G.gunsmith, at(def.npcs.gunsmith, -Math.PI / 2));
      C.home.onEnter(def);
    }
    if (from === 'planque' && G.mode === 'play') C.run.save();   // en sortant de la planque
    if (def.site) {
      if (!G.sites[id]) G.sites[id] = { enemies: spawnSite(id), cleared: false, net: C.net.spawn(def) };
      G.enemies = G.sites[id].enemies;
      G.net = G.sites[id].net;
      if (G.contract && G.contract.site === id) C.contracts.setupSite(G.contract, def);   // objectif prêt même si on était déjà passé
      G.cleared = G.sites[id].cleared;
      if (G.revealPending) { G.revealPending = false; G.revealT = D.revealTime; }
    } else {
      G.enemies = def.outdoor ? streetLegacy() : [];
      G.cleared = false;
      G.net = null;
    }
    if (def.outdoor) { spawnPeds(def.peds || 0); C.gangs.spawn(); }
    G.gunMenu = null;
    // voitures : garées dans la rue, plus celle du leader si elle est sur cette carte
    G.drive = null;
    C.engine(0);
    if (G.comp) G.comp.inCar = false;
    G.cars = def.outdoor ? C.cars.spawnParked(def) : [];
    const own = G.leader.car;
    if (own && own.map === id) G.cars.push(own);
    if (def.outdoor) C.traffic.spawn();   // la circulation (traffic.js)
    G.dealer = def.npcs && def.npcs.dealer ? { x: def.npcs.dealer[0] * 8 + 4, y: def.npcs.dealer[1] * 8 + 4, aim: Math.PI / 2, nom: D.dealer.nom } : null;
    G.dealerMenu = null; G.metroMenu = null;
    // le compagnon arrive avec le leader ; à terre, il a été porté et se relève à 30 %
    if (G.comp) {
      const c = G.comp;
      c.x = p.x; c.y = p.y; c.vx = c.vy = 0; c.target = null;
      if (c.state === 'down') { c.state = 'up'; c.hp = Math.max(c.hp, Math.round(c.maxHp * 0.3)); }
    }
    C.contracts.onEnter(from, id, before);   // l'otage suit, le vol de voiture se prépare
    G.cam = { x: p.x - C.W / 2, y: p.y - C.H / 2 };
    G.fade = 0.35;
    C.amb.resetSky();
    if (C.render) C.render.useWorld(id);
  };

  // Les ennemis d'un bâtiment, avec le contrat et l'héritage qui s'y appliquent.
  function spawnSite(id) {
    const def = C.MAPS[id], k = G.contract, city = L().city;
    const list = def.enemies.map(([type, tx, ty, o], i) => makeEnemy(type, tx, ty, o || {}, i));
    // un épargné rancunier revient au même endroit du même bâtiment
    for (const s of city.spared) {
      if (s.used || s.attitude !== 'rival' || (s.site || 'entrepot') !== id) continue;
      const e = list[s.slot];
      if (!e || e.type !== s.type) continue;
      e.nom = s.nom; e.memory = s; e.rival = true;
      e.hp = e.maxHp = Math.round(e.d.hp * D.rivalHp);
    }
    if (k && k.site === id) {
      for (const e of list) if (!e.memory) {
        e.faction = k.faction;
        if (k.grand) e.hp = e.maxHp = Math.round(e.hp * D.grand.hpMul);
      }
      if (k.grand) {
        const c = makeEnemy('cadre', def.cadre[0], def.cadre[1], {}, -1);
        c.faction = k.faction; c.nom = 'CADRE ' + D.factions[k.faction].nom;
        list.push(c);
        k.target = c;
      } else if (k.type === 'elim') {
        const t = k.target = pick(list.filter(e => e.faction === k.faction));
        t.hp = t.maxHp = Math.round(t.d.hp * D.contracts.elim.targetHp);
      } else if (k.type === 'data') {
        k.term = { x: def.term[0] * 8 + 4, y: def.term[1] * 8 + 4 };
      }
      if (k.target) k.target.mark = true;
      k.enemies = list;
      C.contracts.setupSite(k, def);   // colis, otage, générateur (contracts.js)
      // un ancien leader passé en cyberpsychose rôde dans le bâtiment du contrat
      if (city.psycho && !city.psycho.defeated) {
        const e = makeEnemy('psycho', def.psycho[0], def.psycho[1], {}, -1);
        e.nom = city.psycho.nom; e.psycho = true;
        // son chrome le rend plus dur à abattre : +40 PV par implant en plus du Sandevistan
        e.hp = e.maxHp = e.d.hp + 40 * (city.psycho.implants || 0);
        list.push(e);
      }
    }
    return list;
  }

  // Dans la rue : les épargnés reconnaissants attendent devant la planque, et le corps du dernier leader
  // a été jeté devant le bâtiment où il est tombé.
  function streetLegacy() {
    const city = L().city, out = [], home = M.door('planque');
    let i = 0;
    for (const s of city.spared) {
      if (!home) break;   // ils attendent devant la planque, à Watson
      if (s.used || s.attitude !== 'allie' || i >= 2) continue;
      const e = makeEnemy(s.type, home.sx + 2 + i * 2, home.sy, {}, -1);
      e.nom = s.nom; e.memory = s; e.state = 'friend';
      out.push(e);
      i++;
    }
    const c = city.corpse;
    if (c && !c.taken && C.districtOf(c.site || 'planque') === M.id) {
      const door = M.door(c.site || 'planque') || home || M.door('metro');
      G.corpse = Object.assign({}, c, { x: door.sx * 8 + 4 - 14, y: door.sy * 8 + 4 });
    }
    return out;
  }

  // Passants : ils flânent sur les trottoirs.
  // Tuiles où un passant peut marcher dans ce quartier (trottoirs, pavés, place...).
  const pedOk = (tx, ty) => (M.def.pedTiles || ['s']).includes(M.tile(tx, ty)) && !M.blocked(tx, ty);
  function spawnPeds(n) {
    const cols = M.def.pedCols || ['#4a6fa5', '#a54a6f', '#6fa54a', '#a58f4a', '#7a5cff', '#c7d5e0', '#3a8f8f', '#8f3a3a'];
    for (let i = 0; i < n; i++) {
      for (let t = 0; t < 50; t++) {
        const tx = (C.rand() * M.MW) | 0, ty = (C.rand() * M.MH) | 0;
        if (!pedOk(tx, ty)) continue;
        G.peds.push({ x: tx * 8 + 4, y: ty * 8 + 4, r: 3, aim: C.rand() * 6.28, walk: 0, tx: null, ty: null, wait: C.rr(0, 2),
          speed: C.rr(18, 30), jacket: cols[(C.rand() * cols.length) | 0], hp: D.civilian.hp, dead: false, outfit: C.sprites.randomLook() });
        break;
      }
    }
  }
  function updatePeds(dt) {
    const p = G.player;
    for (const q of G.peds) {
      if (C.ncpd.updatePed(q, dt)) continue;   // mort, aveuglé ou en fuite (ncpd.js)
      if (q.wait > 0) { q.wait -= dt; continue; }
      if (q.tx === null) {
        // nouvelle destination : un bout de trottoir pas trop loin
        for (let t = 0; t < 20; t++) {
          const x = q.x + C.rr(-70, 70), y = q.y + C.rr(-70, 70);
          if (pedOk(Math.floor(x / 8), Math.floor(y / 8))) { q.tx = x; q.ty = y; break; }
        }
        if (q.tx === null) { q.wait = 1; continue; }
      }
      const d = C.dist(q.x, q.y, q.tx, q.ty);
      if (d < 3) { q.tx = null; q.wait = C.rr(0.5, 3); continue; }
      q.aim = C.turn(q.aim, Math.atan2(q.ty - q.y, q.tx - q.x), dt * 5);
      const hit = M.move(q, Math.cos(q.aim) * q.speed * dt, Math.sin(q.aim) * q.speed * dt);
      if (hit || pushOutOfCars(q)) q.tx = null;
      q.walk += dt * 8;
      // ils s'écartent du leader
      const dp = C.dist(q.x, q.y, p.x, p.y);
      if (dp < 7 && dp > 0) M.move(q, (q.x - p.x) / dp * (7 - dp), (q.y - p.y) / dp * (7 - dp));
    }
  }

  // Portes : entrer, sortir, ou trouver porte close. Rentrer à la planque après le contrat lance le gig suivant.
  function useDoor(d) {
    if (d.metro) {
      if (C.ncpd.metroBlocked()) { addFloat(d.x * 8 + 4, d.y * 8 - 6, 'MÉTRO BOUCLÉ PAR LE NCPD', '#4d8aff'); C.sfx('empty'); return; }
      openMetro();
      return;
    }
    const k = G.contract;
    if (C.MAPS[d.to].site && !(k && k.site === d.to && !k.done && !k.failed)) {
      addFloat(d.x * 8 + 4, d.y * 8 - 6, 'FERMÉ', '#8f98a0');
      C.sfx('empty');
      return;
    }
    C.sfx('dash');
    if (d.to === 'planque' && G.gigOver()) { G.newGig(false); return; }
    G.enterMap(d.to, d.toDoor);
  }

  // Tenues fixes : uniformes du NCPD, crâne rasé des brutes, cadres en costume.
  const OUTFITS = {
    cop: { style: 'cap', cap: '#0e1630', pants: '#141c30' }, swat: { style: 'helmet', cap: '#1a1e26', pants: '#141418' },
    maxtac: { style: 'helmet', cap: '#0c0c10', pants: '#0c0c10' }, brute: { style: 'bald' }, cadre: { style: 'short', pants: '#1a1a22' },
    psycho: { style: 'mohawk' },
    maelstrom: { style: 'bald', skin: '#a8704e', pants: '#141414' }, tygerBlade: { style: 'mohawk', pants: '#1a1a22' }, tyger: { style: 'long', pants: '#22303e' },
    valentino: { style: 'short', pants: '#1a1a22', skin: '#c9926c' }, voodoo: { style: 'long', skin: '#5a3826', pants: '#1e2a1e' }, voodooGun: { style: 'bald', skin: '#7a4e34', pants: '#1e2a1e' },
  };
  function makeEnemy(type, tx, ty, o, slot) {
    const d = D.enemies[type];
    return {
      type, d, slot, nom: L().thugName(), x: tx * 8 + 4, y: ty * 8 + 4, r: d.radius, hp: d.hp, maxHp: d.hp, state: 'idle',
      dashT: 0, dashCd: 0.5, dashX: 0, dashY: 0, taunted: false,
      aim: C.rand() * Math.PI * 2, look: C.rand() * 10, react: 0, fireCd: C.rr(0.3, 0.8),
      strafe: C.rand() < 0.5 ? 1 : -1, strafeT: C.rr(0.8, 1.6),
      patrol: o.patrol ? o.patrol.map(([x, y]) => [x * 8 + 4, y * 8 + 4]) : null, pi: 1,
      vx: 0, vy: 0, hurtT: 0, stun: 0, windT: 0, walk: 0, downAng: 0, muzzle: 0,
      outfit: OUTFITS[type] || C.sprites.randomLook(),
      wpn: d.arms ? d.arms[(Math.random() * d.arms.length) | 0] : null,   // arme du gang (enemyArms), lâchée en tombant   // tenue : peau, coiffure, pantalon (Math.random : ne touche pas au hasard du jeu)
    };
  }

  // ---------- outils ----------
  function part(x, y, vx, vy, life, color, kind) {
    G.parts.push({ x, y, vx, vy, life, max: life, color, kind });
  }
  function sparks(x, y, color, n) {
    for (let i = 0; i < n; i++) { const a = C.rand() * Math.PI * 2, s = C.rr(20, 90); part(x, y, Math.cos(a) * s, Math.sin(a) * s, C.rr(0.1, 0.3), color, 'spark'); }
  }
  function blood(x, y, ang, n) {
    for (let i = 0; i < n; i++) {
      const a = ang + C.rr(-0.7, 0.7), s = C.rr(20, 110);
      part(x, y, Math.cos(a) * s, Math.sin(a) * s, C.rr(0.15, 0.45), C.rand() < 0.5 ? '#8c0f22' : '#b5172e', 'blood');
    }
  }
  function addFloat(x, y, text, color) {
    // les textes qui tombent au même endroit s'empilent au lieu de se chevaucher
    for (let i = 0; i < 6 && G.floats.some(f => Math.abs(f.x - x) < 50 && Math.abs(f.y - y) < 7); i++) y -= 7;
    G.floats.push({ x, y, text, color, t: 1.4 });
  }
  function alive() { return G.enemies.filter(ALIVE).length; }

  function alertEnemy(e, shout = true) {
    if (!ALIVE(e) || e.state === 'alert') return;
    e.state = 'alert';
    e.react = e.d.reaction * C.rr(0.8, 1.25);
    G.alertedOnce = true;
    if (G.contract && M.id === G.contract.site) G.contract.alerted = true;
    if (!e.taunted && (e.rival || e.psycho)) {
      e.taunted = true;
      if (e.rival) addFloat(e.x, e.y - 14, e.memory.by + " M'A ÉPARGNÉ. ERREUR.", '#ff5a7a');
      else { addFloat(e.x, e.y - 14, '...' + G.leader.nom + ' ?', '#ff3ec8'); G.flash = 0.15; }
    }
    // il prévient ceux qui l'entendent crier
    if (shout) for (const o of G.enemies) if (o !== e && o.state === 'idle' && C.dist(o.x, o.y, e.x, e.y) < 70 && M.los(o.x, o.y, e.x, e.y)) alertEnemy(o, false);
  }

  function gameOver(reason) {
    if (G.mode !== 'play') return;
    // mourir en plein grand contrat fait de toi une légende
    if (reason === 'mort' && G.contract && G.contract.grand && !G.contract.failed) { reason = 'legende'; G.leader.grandFaction = G.contract.faction; }
    G.mode = 'over';
    G.overReason = reason;
    G.overT = 0;
    G.sandy.on = false;
    G.floats = [];
    C.engine(0); C.siren(0); C.rainSound(0);
    C.sfx('over');
    C.run.clear();   // un leader tombé ne se recharge pas
    // La ville garde la trace du leader : mur des légendes, épargnés, corps ou cyberpsycho.
    L().endLeader(G, reason);
  }

  // ---------- joueur ----------
  function updatePlayer(dt) {
    const p = G.player, P = D.player, W = D.weapons[p.weapon], I = C.input;
    if (G.drive) { updateDriving(dt); return; }
    // manette (gamepad.js) : le stick droit place le curseur autour du joueur ; sans visée, on garde la dernière direction
    const pad = C.pad;
    if (pad && pad.active) {
      if (pad.aiming) pad.aimA = Math.atan2(pad.ay, pad.ax);
      if (pad.aimA === undefined) pad.aimA = p.aim;
      I.mx = C.clamp(p.x - G.cam.x + Math.cos(pad.aimA) * 40, 0, C.W - 1);
      I.my = C.clamp(p.y - G.cam.y + Math.sin(pad.aimA) * 40, 0, C.H - 1);
    }
    p.aim = Math.atan2(G.cam.y + I.my - p.y, G.cam.x + I.mx - p.x);
    p.dashCd -= dt; p.fireCd -= dt; p.meleeCd -= dt; p.invT -= dt; p.hurtT -= dt; p.slashT -= dt;

    // Déplacement relatif à la souris : Z (W en QWERTY) avance vers le curseur, S recule, Q / D font un pas de côté.
    let fw = (C.key('KeyW') || C.key('ArrowUp') ? 1 : 0) - (C.key('KeyS') || C.key('ArrowDown') ? 1 : 0);
    const st = (C.key('KeyD') || C.key('ArrowRight') ? 1 : 0) - (C.key('KeyA') || C.key('ArrowLeft') ? 1 : 0);
    if (fw > 0 && C.dist(p.x, p.y, G.cam.x + I.mx, G.cam.y + I.my) < 8) fw = 0;   // arrivé sur le curseur : on s'arrête
    let ix = Math.cos(p.aim) * fw - Math.sin(p.aim) * st;
    let iy = Math.sin(p.aim) * fw + Math.cos(p.aim) * st;
    const il = Math.hypot(ix, iy);
    if (il) { ix /= il; iy /= il; }
    // manette : on avance dans la direction du stick gauche (et non relativement au curseur)
    if (pad && pad.active && (pad.mx || pad.my)) {
      const pl = Math.hypot(pad.mx, pad.my);
      ix = pad.mx / Math.max(1, pl); iy = pad.my / Math.max(1, pl);
    }

    // recharge
    if (p.reloadT > 0) {
      p.reloadT -= dt;
      if (p.reloadT <= 0) { p.mag = W.mag; C.sfx('reload'); }
    } else if (C.keyHit('KeyR') && p.mag < W.mag && !G.cleared) {
      p.reloadT = W.reload * G.mods.reloadMul;
    }

    // injecteur : soin différé, on avance au ralenti pendant l'injection
    if (p.injT > 0) {
      p.injT -= dt;
      if (p.injT <= 0) { p.hp = Math.min(p.maxHp, p.hp + P.injectHeal); addFloat(p.x, p.y - 8, '+' + P.injectHeal + ' PV', '#5dff9a'); C.sfx('inject'); }
    } else if (C.keyHit('KeyF')) {
      if (p.inj > 0 && p.hp < p.maxHp) { p.inj--; p.injT = P.injectTime; C.sfx('injectStart'); } else C.sfx('empty');
    }

    // dash : direction du déplacement, ou de la visée à l'arrêt ; invulnérable pendant le dash
    if (p.dashT > 0) {
      p.dashT -= dt;
      M.move(p, p.dashX * P.dashSpeed * G.mods.dashSpeed * dt, p.dashY * P.dashSpeed * G.mods.dashSpeed * dt);
      G.trail.push({ x: p.x, y: p.y, aim: p.aim, t: 0.18, max: 0.18, kind: 'dash' });
    } else {
      if (C.keyHit('Space') && p.dashCd <= 0) {
        let dx = ix, dy = iy;
        if (!dx && !dy) { dx = Math.cos(p.aim); dy = Math.sin(p.aim); }
        p.dashX = dx; p.dashY = dy; p.dashT = P.dashTime; p.dashCd = P.dashCd * G.mods.dashCd; p.invT = P.dashTime + 0.04;
        C.sfx('dash');
      }
      const sp = P.speed * p.speedMul * G.mods.speed * (p.injT > 0 ? 0.5 : 1) * (G.scanOn ? 0.5 : 1) * (G.cheats.speed ? 1.8 : 1) * C.gangs.speedMul();
      const k = Math.min(1, dt * 18);
      p.vx = C.lerp(p.vx, ix * sp, k);
      p.vy = C.lerp(p.vy, iy * sp, k);
      M.move(p, p.vx * dt, p.vy * dt);
      pushOutOfCars(p);
      p.moving = il > 0;
      if (il) p.walk += dt * 10;
    }

    // dans la rue, les armes restent rangées
    // on ne sort pas les armes à la planque ; pendant le scan, la souris sert à viser une cible à pirater
    const armed = M.id !== 'planque' && !G.scanOn;
    p.drawnT = (p.drawnT || 0) - dt;   // dans la rue, l'arme se range quelques secondes après le dernier tir
    // tir (clic gauche maintenu)
    if (armed && I.mb[0] && p.fireCd <= 0 && p.dashT <= 0 && p.injT <= 0 && p.reloadT <= 0) {
      if (p.mag > 0) firePlayer();
      else { if (I.mhit[0]) C.sfx('empty'); p.reloadT = W.reload * G.mods.reloadMul; }
    }
    // lame (clic droit) : silencieuse, n'alerte que la cible
    if (armed && I.mhit[2] && p.meleeCd <= 0 && p.dashT <= 0) melee();

    // achever ou épargner l'ennemi à terre le plus proche
    G.near = null;
    let bd = 16;
    for (const e of G.enemies) {
      if (e.state !== 'down') continue;
      const d = C.dist(p.x, p.y, e.x, e.y);
      if (d < bd) { bd = d; G.near = e; }
    }
    // corps du leader précédent : on peut le fouiller
    G.nearCorpse = G.corpse && !G.corpse.taken && C.dist(p.x, p.y, G.corpse.x, G.corpse.y) < 16 ? G.corpse : null;
    // une seule action sur E à la fois, dans cet ordre de priorité
    G.prompt = null;
    const k = G.contract;
    const drop = C.arsenal.nearest(p.x, p.y);
    const tm = G.net && G.net.term;
    if (tm && !tm.used && C.dist(p.x, p.y, tm.x, tm.y) < 14 && !G.near) {
      // terminal : on se branche au réseau du bâtiment (breach protocol)
      G.prompt = k && k.type === 'data' && k.site === M.id && !k.done ? 'PIRATER LE TERMINAL (DONNÉES)' : 'PIRATER LE TERMINAL';
      if (C.keyHit('KeyE')) C.net.openBreach(tm);
    } else if (G.near) {
      if (C.keyHit('KeyE')) execute(G.near);
      else if (C.keyHit('KeyC')) spare(G.near);
    } else {
      const acts = [], c = G.comp, close = (o, r = 16) => C.dist(p.x, p.y, o.x, o.y) < r;
      if (G.nearCorpse) acts.push(['FOUILLER LE CORPS DE ' + G.nearCorpse.nom, () => searchCorpse(G.nearCorpse)]);
      if (c && c.state === 'down' && close(c)) acts.push(['RELEVER ' + c.nom, reviveComp]);
      if (!c && G.recruit && M.id === 'planque' && close(G.recruit)) acts.push(['RECRUTER ' + G.recruit.nom, () => recruit(G.recruit)]);
      if (!c) for (const e of G.enemies) if (e.state === 'friend' && e.gifted && close(e, 20)) acts.push(['RECRUTER ' + e.nom, () => recruitFriend(e)]);
      C.home.acts(acts, close);   // Luna, au bar
      if (M.id === 'planque' && close(G.fixer, 18)) acts.push(['PARLER À ' + G.fixer.nom, openBoard]);
      const own = G.leader.car;
      if (own && own.map === M.id && C.cars.hitCircle(p.x, p.y, p.r + 6, [own])) acts.push(['MONTER DANS LA ' + C.cars.MODELS[own.model].nom, () => enterCar(own)]);
      if (G.dealer && close(G.dealer, 18)) acts.push(['PARLER À ' + G.dealer.nom, openDealer]);
      if (M.id === 'planque' && close(G.gunsmith, 18)) acts.push(['PARLER À ' + G.gunsmith.nom + ' (ARMURIER)', C.arsenal.openShop]);
      if (drop) acts.unshift([C.arsenal.label(drop), () => C.arsenal.pickup(drop)]);   // ramasser passe avant le reste
      for (const d of M.def.doors) if (close({ x: d.x * 8 + 4, y: d.y * 8 + 4 }, 15)) acts.push([doorLabel(d), () => useDoor(d)]);
      if (M.id === 'planque' && close(G.doc, 18)) acts.push(['PARLER À ' + G.doc.nom, () => { G.shop = { sel: 0, msg: 'QU\'EST-CE QU\'ON TE POSE ?', msgCol: '#c7d5e0', msgT: 99, lmx: C.input.mx, lmy: C.input.my }; C.sfx('spare'); }]);
      C.contracts.acts(acts);   // objectifs des nouveaux contrats (en tête de liste)
      // voler une voiture passe en dernier (on longe souvent des voitures garées)
      const steal = C.traffic.stealable();
      if (steal) acts.push([(steal.ai ? 'VOLER LA ' : 'FORCER LA ') + C.cars.MODELS[steal.model].nom, () => C.traffic.steal(steal)]);
      if (acts.length) {
        G.prompt = acts[0][0];
        if (C.keyHit('KeyE')) acts[0][1]();
      }
    }
    // ordre au compagnon
    if (G.comp && G.comp.state === 'up' && C.keyHit('KeyG')) {
      G.comp.order = G.comp.order === 'suivre' ? 'tenir' : 'suivre';
      addFloat(G.comp.x, G.comp.y - 12, G.comp.order === 'suivre' ? 'JE TE SUIS' : 'JE TIENS LA POSITION', '#3ec8ff');
      C.sfx('empty');
    }
  }

  function firePlayer() {
    const p = G.player, W = D.weapons[p.weapon];
    p.fireCd = W.rate * G.mods.rateMul;
    if (!G.cheats.ammo) p.mag--;
    G.reg.tirs++;
    const spread = W.spread * G.mods.spreadMul * C.gangs.spreadMul();   // brouillage des Voodoo Boys : on tire n'importe où
    let sx = p.x + Math.cos(p.aim) * 6, sy = p.y + Math.sin(p.aim) * 6;
    if (M.solidAt(sx, sy)) { sx = p.x; sy = p.y; }   // canon dans un mur : on tire depuis le corps
    // un tir = une balle, ou une gerbe de plombs (fusil à pompe)
    for (let i = 0; i < (W.pellets || 1); i++) {
      const a = p.aim + C.rr(-spread, spread), v = W.speed * (W.pellets ? C.rr(0.85, 1.1) : 1);
      G.bullets.push({ x: sx, y: sy, vx: Math.cos(a) * v, vy: Math.sin(a) * v, dmg: W.dmg * G.mods.gunDmg, team: 0, life: W.range / W.speed, own: true,
        ox: p.x, oy: p.y, gibContact: W.gibContact || 0, pierce: W.pierce || 0, homing: W.homing || 0, hits: W.pierce ? [] : null, wpn: p.weapon });
    }
    G.muzzle = 0.06; G.muzzleX = sx; G.muzzleY = sy;
    if (M.def.outdoor) {
      // dans la rue : les passants fuient, et quelqu'un appelle le NCPD
      p.drawnT = 4;
      C.ncpd.panic(p.x, p.y, D.wanted.panicRadius);
      C.ncpd.crime('shots', p.x, p.y);
      C.gangs.shotsNear(p.x, p.y);
    }
    G.shake = Math.max(G.shake, W.shake || 1.5);
    const side = p.aim + Math.PI / 2;
    part(p.x, p.y, Math.cos(side) * C.rr(25, 45), Math.sin(side) * C.rr(25, 45), 0.35, '#e8c060', 'shell');
    C.sfx('shot');
    // le bruit du tir alerte tout le monde à portée d'oreille, murs compris
    for (const e of G.enemies) if (e.state === 'idle' && C.dist(e.x, e.y, p.x, p.y) < 150) alertEnemy(e);
  }

  function melee() {
    const p = G.player, B = D.weapons[p.melee];
    p.meleeCd = B.rate * G.mods.meleeCd; p.slashT = B.parry ? 0.22 : 0.15; p.slashA = p.aim;
    C.sfx('slash');
    for (const e of G.enemies) {
      if (!ALIVE(e)) continue;
      const m = G.mods;
      if (C.dist(p.x, p.y, e.x, e.y) > B.range + m.bladeRange + e.r) continue;
      if (Math.abs(C.angDiff(p.aim, Math.atan2(e.y - p.y, e.x - p.x))) > (B.arc + m.bladeArc) / 2 + 0.3) continue;
      e.vx += Math.cos(p.aim) * B.knock * m.knock;
      e.vy += Math.sin(p.aim) * B.knock * m.knock;
      e.stun = 0.35;
      hitEnemy(e, Math.round(B.dmg * G.mods.blade), p.aim);
      if (G.mods.bladeHeal) p.hp = Math.min(p.maxHp, p.hp + G.mods.bladeHeal);   // lame vampire
    }
    for (const q of G.peds) {
      if (q.dead || C.dist(p.x, p.y, q.x, q.y) > B.range + G.mods.bladeRange + q.r) continue;
      if (Math.abs(C.angDiff(p.aim, Math.atan2(q.y - p.y, q.x - p.x))) > (B.arc + G.mods.bladeArc) / 2 + 0.3) continue;
      C.ncpd.hitPed(q, Math.round(B.dmg * G.mods.blade), p.aim);
    }
  }

  function execute(e) {
    const p = G.player;
    e.state = 'dead';
    G.reg.acheves++;
    C.home.note('execs');
    resolveMemory(e);
    if (G.comp && M.los(G.comp.x, G.comp.y, e.x, e.y)) loyalty(D.companion.loyalty.execute, 'ÇA NE LUI PLAÎT PAS');
    p.slashT = 0.15;
    p.slashA = Math.atan2(e.y - p.y, e.x - p.x);
    blood(e.x, e.y, p.slashA, 22);
    C.gore.execute(e.x, e.y, p.slashA);
    G.shake = Math.max(G.shake, 4);
    G.hitstop = 0.08;
    C.sfx('execute');
    addFloat(e.x, e.y - 8, 'ACHEVÉ', '#ff3e5a');
    if (e.cop) C.ncpd.crime('copKill', e.x, e.y);
    C.skills.gain(5, e.x, e.y);
  }

  function spare(e) {
    e.state = 'spared';
    G.reg.epargnes++;
    C.home.note('spared');
    if (G.comp && M.los(G.comp.x, G.comp.y, e.x, e.y)) loyalty(D.companion.loyalty.spare);
    // un ennemi qui revenait déjà est réglé ; un nouveau est noté pour le prochain leader
    if (e.memory || e.psycho) resolveMemory(e);
    else if (e.slot >= 0) G.leader.spared.push(L().spareRecord(e.slot, e, G.leader, M.id));
    C.sfx('spare');
    addFloat(e.x, e.y - 8, 'ÉPARGNÉ', '#5dff9a');
    addFloat(e.x, e.y - 1, "IL S'EN SOUVIENDRA", '#5dff9a');
  }

  // Un ennemi venu de l'héritage est réglé : il ne reviendra plus.
  function resolveMemory(e) {
    if (e.memory) e.memory.used = true;
    if (e.psycho && L().city.psycho) L().city.psycho.defeated = true;
    L().save();
  }

  function searchCorpse(c) {
    const p = G.player, city = L().city;
    c.taken = true;
    if (city.corpse) city.corpse.taken = true;
    L().save();
    const got = Math.min(c.inj, p.maxInj - p.inj);
    p.inj += got;
    p.mag = D.weapons.pistol.mag;
    if (c.eddies) earn(c.eddies, c.x, c.y + 4);
    C.sfx('inject');
    addFloat(c.x, c.y - 10, 'LE CORPS DE ' + c.nom, '#f2d43a');
    addFloat(c.x, c.y - 3, got ? '+' + got + ' INJECTEUR' + (got > 1 ? 'S' : '') + ' · CHARGEUR' : 'UN CHARGEUR PLEIN', '#f2d43a');
  }

  // Un épargné qui revient en allié : il reconnaît le nouveau leader et l'aide une fois.
  function friendGift(e) {
    const p = G.player;
    e.memory.used = true;
    e.gifted = true;
    L().save();
    if (p.inj < p.maxInj) p.inj++;
    G.revealPending = true;   // les positions seront révélées à l'entrée du prochain bâtiment
    C.sfx('spare');
    addFloat(e.x, e.y - 18, e.memory.by + " M'A LAISSÉ VIVRE.", '#5dff9a');
    addFloat(e.x, e.y - 11, "TIENS. ET JE T'INDIQUERAI OÙ ILS SONT.", '#5dff9a');
  }

  // ---------- voitures ----------
  // Les personnages ne traversent pas les voitures : on les repousse hors du cercle touché.
  function pushOutOfCars(e) {
    if (!G.cars || !G.cars.length) return false;
    for (const car of G.cars) for (const [a, b, s] of C.cars.circles(car)) {
      const dx = e.x - a, dy = e.y - b, d = Math.hypot(dx, dy) || 0.01, min = s + e.r;
      if (d < min) { M.move(e, dx / d * (min - d), dy / d * (min - d)); return car; }
    }
    return false;
  }
  function enterCar(car) {
    G.drive = car;
    car.speed = 0;
    if (G.comp) G.comp.inCar = true;   // le compagnon monte aussi
    C.sfx('reload');
  }
  // Sortir : à gauche de la voiture, sinon à droite, sinon derrière.
  function exitCar() {
    const car = G.drive, p = G.player, m = C.cars.MODELS[car.model];
    const ca = Math.cos(car.ang), sa = Math.sin(car.ang), side = m.wid / 2 + 6;
    const spots = [[sa * side, -ca * side], [-sa * side, ca * side], [-ca * (m.len / 2 + 6), -sa * (m.len / 2 + 6)], [ca * (m.len / 2 + 6), sa * (m.len / 2 + 6)]];
    for (const [ox, oy] of spots) {
      const x = car.x + ox, y = car.y + oy;
      if (M.solidAt(x, y) || C.cars.hitCircle(x, y, p.r, G.cars)) continue;
      p.x = x; p.y = y; p.vx = p.vy = 0;
      G.drive = null;
      car.speed = 0;
      if (G.comp) { G.comp.inCar = false; G.comp.x = x; G.comp.y = y; pushOutOfCars(G.comp); }
      C.engine(0);
      C.sfx('reload');
      return;
    }
    addFloat(car.x, car.y - 14, 'PAS DE PLACE POUR SORTIR', '#ff8a5a');
  }
  function updateDriving(dt) {
    const car = G.drive, p = G.player;
    const keys = {
      up: C.key('KeyW') || C.key('ArrowUp'), down: C.key('KeyS') || C.key('ArrowDown'),
      left: C.key('KeyA') || C.key('ArrowLeft'), right: C.key('KeyD') || C.key('ArrowRight'),
    };
    if (C.cars.drive(car, dt, keys, G.cars)) { G.shake = Math.max(G.shake, 3); C.sfx('hit'); }
    p.x = car.x; p.y = car.y; p.vx = p.vy = 0; p.moving = false;
    if (G.comp) { G.comp.x = car.x; G.comp.y = car.y; }
    C.engine(Math.min(1, Math.abs(car.speed) / C.cars.MODELS[car.model].speed));
    G.near = null; G.nearCorpse = null;
    G.prompt = Math.abs(car.speed) < 30 ? 'SORTIR DE LA VOITURE' : null;
    if (C.keyHit('KeyE') && Math.abs(car.speed) < 30) exitCar();
    if (C.keyHit('KeyR')) C.music.nextStation();   // radio suivante
    // les passants s'écartent en criant
    for (const q of G.peds) {
      if (Math.abs(car.speed) < 25) break;
      if (q.dead) continue;
      if (Math.abs(car.speed) > D.civilian.runOver && C.cars.hitCircle(q.x, q.y, q.r + 6, [car])) {
        // trop vite pour s'écarter
        C.ncpd.hitPed(q, 999, car.ang + C.rr(-0.5, 0.5));
        M.move(q, Math.cos(car.ang) * 10, Math.sin(car.ang) * 10);
        car.speed *= 0.8; G.shake = Math.max(G.shake, 3);
        continue;
      }
      if (!C.cars.hitCircle(q.x, q.y, q.r + 7, [car])) continue;
      const a = Math.atan2(q.y - car.y, q.x - car.x);
      M.move(q, Math.cos(a) * 14, Math.sin(a) * 14);
      q.tx = null; q.wait = 0.6;
      if (!q.yellT || G.time - q.yellT > 2) { q.yellT = G.time; addFloat(q.x, q.y - 10, 'HÉ !', '#ffffff'); }
    }
  }

  // Concessionnaire : même principe que la boutique du ripperdoc.
  G.dealerItems = () => Object.keys(C.cars.MODELS);
  function openDealer() {
    G.dealerMenu = { sel: 0, msg: "QU'EST-CE QUI TE FERAIT PLAISIR ?", msgCol: '#c7d5e0', msgT: 99, lmx: C.input.mx, lmy: C.input.my };
    C.sfx('spare');
  }
  function buyCar(id) {
    const m = C.cars.MODELS[id], L0 = G.leader, s = G.dealerMenu;
    const set = (t, c) => { s.msg = t; s.msgCol = c; s.msgT = 3; };
    if (L0.car && L0.car.model === id) return set("T'AS DÉJÀ CELLE-LÀ.", '#8f98a0');
    if (L0.eddies < m.prix) return set("REVIENS AVEC DES EDDIES.", '#ff5a7a');
    const lot = M.def.lot;
    // on libère la place : l'ancienne voiture du leader est reprise
    if (L0.car) G.cars = G.cars.filter(c => c !== L0.car);
    const car = { x: lot.x, y: lot.y, ang: lot.ang, speed: 0, model: id, color: C.cars.COLORS[(Math.random() * C.cars.COLORS.length) | 0], own: true, map: M.id };
    L0.eddies -= m.prix;
    L0.car = car;
    G.cars.push(car);
    C.sfx('clear');
    set(m.nom + ' À TOI. ELLE T\'ATTEND SUR LE PARKING.', '#5dff9a');
  }
  function updateDealer() {
    const s = G.dealerMenu, items = G.dealerItems(), I = C.input, n = items.length;
    s.msgT -= C.STEP;
    if (C.keyHit('ArrowUp') || C.keyHit('KeyW')) s.sel = (s.sel + n - 1) % n;
    if (C.keyHit('ArrowDown') || C.keyHit('KeyS')) s.sel = (s.sel + 1) % n;
    const row = C.render ? C.render.dealerRowUnderMouse() : -1;
    if (row >= 0 && (I.mx !== s.lmx || I.my !== s.lmy)) s.sel = row;
    s.lmx = I.mx; s.lmy = I.my;
    if (C.keyHit('KeyE') || C.keyHit('Enter') || (I.mhit[0] && row >= 0)) buyCar(items[s.sel]);
    else if (C.keyHit('Escape') || I.mhit[2]) G.dealerMenu = null;
  }

  // ---------- métro ----------
  // La bouche de métro ouvre le plan de la ligne ; choisir une station lance le trajet (G.ride),
  // puis on ressort par la bouche de métro du quartier d'arrivée. Le compagnon suit, la voiture reste garée.
  function openMetro() {
    G.metroMenu = { sel: C.LINE.indexOf(G.goalDistrict() !== M.id ? G.goalDistrict() : M.id), lmx: C.input.mx, lmy: C.input.my };
    C.sfx('spare');
  }
  function updateMetro() {
    const s = G.metroMenu, I = C.input, n = C.LINE.length;
    if (C.keyHit('ArrowUp') || C.keyHit('KeyW')) s.sel = (s.sel + n - 1) % n;
    if (C.keyHit('ArrowDown') || C.keyHit('KeyS')) s.sel = (s.sel + 1) % n;
    const row = C.render ? C.render.metroRowUnderMouse() : -1;
    if (row >= 0 && (I.mx !== s.lmx || I.my !== s.lmy)) s.sel = row;
    s.lmx = I.mx; s.lmy = I.my;
    if (C.keyHit('KeyE') || C.keyHit('Enter') || (I.mhit[0] && row >= 0)) {
      const to = C.LINE[s.sel];
      G.metroMenu = null;
      if (to === M.id) return;
      G.ride = { from: M.id, to, t: 0, dur: 2.2 + 1.1 * Math.abs(C.LINE.indexOf(to) - C.LINE.indexOf(M.id)) };
      C.siren(0);
      C.sfx('dash');
    } else if (C.keyHit('Escape') || I.mhit[2]) G.metroMenu = null;
  }
  function updateRide(dt) {
    const r = G.ride;
    r.t += dt;
    const k = r.t / r.dur;
    C.engine(0.15 + 0.35 * Math.sin(Math.min(1, k) * Math.PI));   // grondement de la rame
    if (r.t >= r.dur || (r.t > 0.5 && (C.keyHit('KeyE') || C.keyHit('Space')))) {
      G.ride = null;
      C.engine(0);
      G.enterMap(r.to, 'metro');
      const p = G.player;
      addFloat(p.x, p.y - 12, C.MAPS[r.to].quartier, '#ffb000');
      addFloat(p.x, p.y - 5, C.STATIONS[r.to].sub, '#8f98a0');
    }
  }
  // Où aller : le bâtiment du contrat en cours, sinon la planque. Dans un autre quartier, c'est le métro.
  G.goalDistrict = () => {
    const k = G.contract;
    return C.districtOf(k && !k.done && !k.failed ? k.site : 'planque');
  };
  // Renvoie {x, y, label, color} ou null.
  G.goal = function () {
    const obj = C.contracts.goal();   // colis, otage, générateur, voiture, dépôt
    if (obj) return Object.assign({ color: '#ffd23e' }, obj);
    if (!M.def.outdoor) return null;
    const k = G.contract, site = k && !k.done && !k.failed ? k.site : 'planque';
    const D0 = d => ({ x: d.x * 8 + 4, y: d.y * 8 + 4, color: d.color });
    if (C.districtOf(site) === M.id) {
      const d = M.door(site);
      return d ? Object.assign(D0(d), { label: d.label }) : null;
    }
    const m = M.door('metro');
    return m ? Object.assign(D0(m), { label: 'MÉTRO > ' + C.MAPS[C.districtOf(site)].quartier }) : null;
  };
  // Pour les tests : prendre le métro sans passer par le plan.
  G.debugRide = to => { G.ride = { from: M.id, to, t: 0, dur: 2 }; };

  // ---------- contrats ----------
  const pick = a => a[(Math.random() * a.length) | 0];
  G.gigOver = () => !!(G.contract && (G.contract.done || G.contract.failed));
  G.canLeave = G.gigOver;
  const SITES = () => Object.keys(C.MAPS).filter(id => C.MAPS[id].site);
  function doorLabel(d) {
    if (d.metro) return 'PRENDRE LE MÉTRO';
    const to = C.MAPS[d.to], k = G.contract;
    if (to.outdoor) return 'SORTIR DANS LA RUE';
    if (d.to === 'planque') return G.gigOver() ? 'RENTRER À LA PLANQUE (GIG SUIVANT)' : 'ENTRER : PLANQUE';
    return k && k.site === d.to && !k.done && !k.failed ? 'ENTRER : ' + to.nom : to.nom + ' (FERMÉ)';
  }
  G.payMul = () => (1 + D.fixerBonus * (G.fixer ? G.fixer.stars : 0)) * (G.leader.burned ? D.burnedPay : 1);

  // Trois offres par gig. Un arc arrivé au bout propose son grand contrat à la place de la première.
  function makeOffers() {
    const offers = [];
    for (let i = 0; i < 3; i++) {
      const faction = pick(Object.keys(D.factions)), type = pick(Object.keys(D.contracts));
      offers.push({ faction, type, site: C.contracts.isStreet(type) ? pick(C.LINE) : pick(SITES()), grand: false, pay: Math.round(D.contracts[type].pay * D.factions[faction].pay * G.payMul()) });
    }
    for (const f of Object.keys(G.leader.arcs)) {
      if (G.leader.arcs[f] >= D.arcLength && !G.leader.burned) { offers[0] = { faction: f, type: 'elim', site: pick(SITES()), grand: true, pay: Math.round(D.grand.pay * G.payMul()) }; break; }
    }
    return offers;
  }
  function openBoard() {
    if (G.contract) { addFloat(G.fixer.x, G.fixer.y - 12, "T'AS DÉJÀ UN CONTRAT.", '#c7d5e0'); return; }
    // la souris ne choisit une ligne que si elle bouge après l'ouverture
    G.board = { sel: 0, offers: G.offers || (G.offers = makeOffers()), lmx: C.input.mx, lmy: C.input.my };
    C.sfx('spare');
  }
  G.boardRowUnderMouse = () => (C.render ? C.render.boardRowUnderMouse() : -1);
  function updateBoard() {
    const b = G.board, I = C.input, n = b.offers.length;
    if (C.keyHit('ArrowUp') || C.keyHit('KeyW')) b.sel = (b.sel + n - 1) % n;
    if (C.keyHit('ArrowDown') || C.keyHit('KeyS')) b.sel = (b.sel + 1) % n;
    const row = G.boardRowUnderMouse();
    if (row >= 0 && (I.mx !== b.lmx || I.my !== b.lmy)) b.sel = row;
    b.lmx = I.mx; b.lmy = I.my;
    if (C.keyHit('KeyE') || C.keyHit('Enter') || (I.mhit[0] && row >= 0)) { acceptContract(b.offers[b.sel]); G.board = null; }
    else if (C.keyHit('Escape') || I.mhit[2]) G.board = null;
  }

  // Accepter un contrat : il désigne un bâtiment. Ennemis, cible et terminal y sont placés à la première entrée (spawnSite).
  function acceptContract(o) {
    G.contract = Object.assign({ done: false, failed: false, hack: 0, alarm: false, alerted: false, timer: D.grand.timer, target: null, term: null, enemies: null }, o);
    G.offers = null;
    C.sfx('reload');
    addFloat(G.player.x, G.player.y - 12, 'CONTRAT ' + D.factions[o.faction].nom + ' ACCEPTÉ', D.factions[o.faction].color);
    const q = C.MAPS[C.districtOf(o.site)].quartier;
    addFloat(G.player.x, G.player.y - 5, 'DIRECTION : ' + C.MAPS[o.site].nom + (q === 'WATSON' ? '' : ' · ' + q), '#c7d5e0');
  }
  // Pour les tests : prendre un contrat et entrer directement dans le bâtiment.
  G.debugGig = function (site, type, faction, grand) {
    acceptContract({ faction: faction || 'arasaka', type: type || 'clean', site, grand: !!grand, pay: 100 });
    G.enterMap(site, C.MAPS[site].outdoor ? 'metro' : 'sortie');
  };

  // Vérifié à chaque image : objectif atteint, ou grand contrat qui tourne mal.
  function updateContract(dt) {
    const k = G.contract;
    if (!k || k.done || k.failed) return;
    const targetDown = k.target && !G.ALIVE(k.target) && k.target.state !== 'gone';
    const ok = C.contracts.is(k) ? !!k.objDone : k.type === 'clean' ? !!k.enemies && !k.enemies.some(ALIVE) : k.type === 'data' ? k.hack >= D.contracts.data.hack : targetDown;
    if (k.grand && k.alerted && !ok) {
      k.timer -= dt;
      if (k.timer <= 0) {
        // la cible s'enfuit : le leader survit, mais il est grillé
        k.failed = true;
        k.target.state = 'gone';
        G.leader.burned = true;
        G.leader.arcs[k.faction] = 0;
        addFloat(G.player.x, G.player.y - 16, 'CONTRAT RATÉ : LE CADRE A FILÉ', '#ff2040');
        C.music.event('fail');
        addFloat(G.player.x, G.player.y - 9, 'TU ES GRILLÉ. LA PAIE SERA MAIGRE.', '#ff8a5a');
        C.sfx('over');
        return;
      }
    }
    if (!ok) return;
    k.done = true;
    C.music.event('contract');
    earn(k.pay, G.player.x, G.player.y - 16);
    C.skills.gain(k.grand ? 400 : 100);
    C.sfx('clear');
    if (k.grand) {
      G.leader.grandFaction = k.faction;
      addFloat(G.player.x, G.player.y - 23, 'GRAND CONTRAT REMPLI', '#ffd23e');
      G.endT = 2;
      return;
    }
    if (D.factions[k.faction].arc) G.leader.arcs[k.faction]++;
    addFloat(G.player.x, G.player.y - 23, 'CONTRAT REMPLI', D.factions[k.faction].color);
    addFloat(G.player.x, G.player.y - 30, 'RETOURNE À LA PLANQUE', '#c7d5e0');
  }

  // Fin « fixer » : réputation selon ce qu'il reste de l'équipe.
  function retireAsFixer() {
    const c = G.comp;
    G.fixerStars = 1 + (c && c.state === 'up' ? 1 : 0) + (c && c.state === 'up' && c.loyalty >= 60 ? 1 : 0);
    gameOver('fixer');
  }

  // ---------- chrome et eddies ----------
  // Les modificateurs de combat viennent des implants posés ; recalculés quand on en pose ou en retire un.
  function refreshMods() {
    const m = { blade: 1, knock: 1, bladeRange: 0, bladeArc: 0, spreadMul: 1, dmgTaken: 1, speed: 1, dashCd: 1, dashSpeed: 1, sandyDur: 1, sandySlow: null, bio: false, scan: false, mantis: false,
      ramMax: D.net.ramMax, ramRegen: D.net.ramRegen, upload: D.net.upload, buffer: D.net.buffer, tier: 1,
      reloadMul: 1, gunDmg: 1, rateMul: 1, meleeCd: 1, bladeHeal: 0, killHeal: 0, secondWind: false, contagion: false };
    for (const id of Object.values(G.leader.implants)) D.implants[id].mods(m);
    C.skills.apply(m);   // compétences du leader
    G.mods = m;
  }
  function sandyDur() { return D.sandy.duration * G.mods.sandyDur; }
  G.sandyDur = sandyDur;
  function earn(n, x, y) {
    G.leader.eddies += n;
    addFloat(x, y, '+' + n + ' €$', '#ffd23e');
  }

  // Boutique du ripperdoc : liste fixe des implants (sauf le Mk.1 de base) puis les immunosuppresseurs.
  G.shopItems = () => Object.keys(D.implants).filter(id => !D.implants[id].base).concat(['immuno']);
  function shopMsg(t, col) { G.shop.msg = t; G.shop.msgCol = col; G.shop.msgT = 2.5; }
  function shopBuy(id) {
    const L0 = G.leader;
    if (id === 'immuno') {
      const it = D.immuno;
      if (L0.eddies < it.prix) return shopMsg("PAS ASSEZ D'EDDIES.", '#ff5a7a');
      L0.eddies -= it.prix;
      G.humanity = Math.min(100, G.humanity + it.hum);
      C.sfx('inject');
      return shopMsg('+' + it.hum + ' HUMANITÉ. ÇA NE DURERA PAS.', '#5dff9a');
    }
    const imp = D.implants[id], cur = L0.implants[imp.slot];
    if (cur === id) return shopMsg('DÉJÀ POSÉ.', '#8f98a0');
    if (L0.eddies < imp.prix) return shopMsg("PAS ASSEZ D'EDDIES.", '#ff5a7a');
    const refund = cur ? Math.round(D.implants[cur].hum * D.removeRefund) : 0;
    const after = G.humanity + refund - imp.hum;
    if (after < D.docMinHumanity) return shopMsg('LE DOC REFUSE : TROP DE CHROME.', '#ff3ec8');
    L0.eddies -= imp.prix;
    L0.implants[imp.slot] = id;
    G.humanity = after;
    refreshMods();
    if (G.sandy.charge > sandyDur()) G.sandy.charge = sandyDur();
    G.ram = Math.min(G.ram, G.mods.ramMax);
    C.sfx('reload');
    const net = imp.hum - refund;
    shopMsg(imp.nom + ' POSÉ. ' + (net >= 0 ? '-' + net : '+' + -net) + ' HUMANITÉ.', '#3ef0ff');
  }
  function shopRemove(id) {
    if (id === 'immuno') return;
    const imp = D.implants[id], L0 = G.leader;
    if (L0.implants[imp.slot] !== id) return shopMsg("CET IMPLANT N'EST PAS POSÉ.", '#8f98a0');
    const refund = Math.round(imp.hum * D.removeRefund);
    // le Sandevistan retiré est remplacé par le Mk.1 : on ne joue pas sans
    if (imp.slot === 'SYSTÈME') { L0.implants[imp.slot] = 'sandy1'; G.humanity += refund - D.implants.sandy1.hum; }
    else if (imp.slot === 'DECK') { L0.implants[imp.slot] = 'deck1'; G.humanity += refund; }   // pareil pour le cyberdeck
    else { delete L0.implants[imp.slot]; G.humanity += refund; }
    G.humanity = Math.min(100, G.humanity);
    refreshMods();
    if (G.sandy.charge > sandyDur()) G.sandy.charge = sandyDur();
    G.ram = Math.min(G.ram, G.mods.ramMax);
    C.sfx('empty');
    shopMsg(imp.nom + ' RETIRÉ.', '#c7d5e0');
  }
  function updateShop(dt) {
    const s = G.shop, items = G.shopItems(), I = C.input;
    s.msgT -= dt;
    if (C.keyHit('ArrowUp') || C.keyHit('KeyW')) s.sel = (s.sel + items.length - 1) % items.length;
    if (C.keyHit('ArrowDown') || C.keyHit('KeyS')) s.sel = (s.sel + 1) % items.length;
    const row = C.render ? C.render.shopRowUnderMouse() : -1;
    if (row >= 0 && (I.mx !== s.lmx || I.my !== s.lmy)) s.sel = row;   // la souris choisit la ligne survolée
    s.lmx = I.mx; s.lmy = I.my;
    if (C.keyHit('KeyE') || C.keyHit('Enter') || (I.mhit[0] && row >= 0)) shopBuy(items[s.sel]);
    else if (C.keyHit('KeyX')) shopRemove(items[s.sel]);
    else if (C.keyHit('Escape') || I.mhit[2]) G.shop = null;
  }

  // ---------- compagnon ----------
  function makeComp(r) {
    const CD = D.companion;
    return {
      nom: r.nom, origine: r.origine, loyalty: r.loyalty == null ? CD.loyalty.start : r.loyalty,
      x: r.x, y: r.y, r: CD.radius, vx: 0, vy: 0, aim: 0, walk: 0,
      hp: CD.hp, maxHp: CD.hp, state: 'up', order: 'suivre', target: null, react: 0, fireCd: 0, muzzle: 0, hurtT: 0,
    };
  }
  function recruit(r) {
    G.comp = G.leader.comp = makeComp(r);
    if (r.record) L().useCompanion(r.nom);
    G.recruit = null;
    C.sfx('spare');
    addFloat(G.comp.x, G.comp.y - 12, G.comp.nom + ' RECRUTÉ', '#3ec8ff');
  }
  // un allié revenu de l'héritage peut rejoindre l'équipe, avec une loyauté de départ plus haute
  function recruitFriend(e) {
    e.state = 'gone';
    recruit({ nom: e.nom, origine: 'rue', loyalty: 70, x: e.x, y: e.y });
  }
  function loyalty(delta, why) {
    const c = G.comp;
    if (!c || c.state !== 'up') return;
    c.loyalty = C.clamp(c.loyalty + delta, 0, 100);
    if (why) addFloat(c.x, c.y - 12, why, delta > 0 ? '#3ec8ff' : '#ff8a5a');
    if (c.loyalty <= 0) {
      // il quitte l'équipe pour de bon
      addFloat(c.x, c.y - 19, "J'EN AI ASSEZ. SALUT.", '#ff8a5a');
      G.comp = G.leader.comp = null;
    }
  }
  function hurtComp(dmg, ang) {
    const c = G.comp;
    c.hp -= dmg; c.hurtT = 0.15;
    c.vx += Math.cos(ang) * 60; c.vy += Math.sin(ang) * 60;
    blood(c.x, c.y, ang, 5);
    if (c.hp <= 0) {
      c.hp = 0; c.state = 'down'; c.downAng = ang;
      addFloat(c.x, c.y - 10, c.nom + ' EST À TERRE', '#ff8a5a');
      C.sfx('down');
    } else C.sfx('hit');
  }
  function reviveComp() {
    const c = G.comp;
    c.state = 'up';
    c.hp = Math.round(c.maxHp * D.companion.reviveHp);
    C.sfx('inject');
    loyalty(D.companion.loyalty.revive, 'MERCI.');
  }
  function compFire(c) {
    const w = D.companion.weapon;
    c.fireCd = w.rate * C.rr(0.85, 1.2);
    const a = c.aim + C.rr(-w.spread, w.spread);
    let sx = c.x + Math.cos(c.aim) * 5, sy = c.y + Math.sin(c.aim) * 5;
    if (M.solidAt(sx, sy)) { sx = c.x; sy = c.y; }
    G.bullets.push({ x: sx, y: sy, vx: Math.cos(a) * w.speed, vy: Math.sin(a) * w.speed, dmg: w.dmg, team: 0, life: 0.7 });
    c.muzzle = 0.06;
    C.sfx('eshot');
    for (const e of G.enemies) if (e.state === 'idle' && C.dist(e.x, e.y, c.x, c.y) < 120) alertEnemy(e);
  }
  function updateComp(dt) {
    const c = G.comp;
    if (!c || c.inCar) return;
    c.hurtT -= dt; c.fireCd -= dt; c.muzzle -= dt;
    const decay = Math.pow(0.001, dt);
    c.vx *= decay; c.vy *= decay;
    if (c.state !== 'up') { M.move(c, c.vx * dt, c.vy * dt); return; }
    const p = G.player, CD = D.companion;
    // il couvre : il ne tire que sur un ennemi déjà en alerte, le plus proche qu'il voit
    let best = null, bd = CD.sight;
    for (const e of G.enemies) {
      if (e.state !== 'alert') continue;
      const d = C.dist(c.x, c.y, e.x, e.y);
      if (d < bd && M.los(c.x, c.y, e.x, e.y)) { bd = d; best = e; }
    }
    if (best !== c.target) { c.target = best; c.react = CD.reaction; }
    c.react -= dt;
    if (best) {
      const a = Math.atan2(best.y - c.y, best.x - c.x);
      c.aim = C.turn(c.aim, a, dt * 8);
      if (c.react <= 0 && c.fireCd <= 0 && Math.abs(C.angDiff(c.aim, a)) < 0.2) compFire(c);
    }
    // il suit le leader (par la carte de distances quand il ne le voit pas), ou tient sa position
    let mx = 0, my = 0;
    const dP = C.dist(c.x, c.y, p.x, p.y);
    if (c.order === 'suivre' && dP > CD.followDist) {
      let a;
      if (M.los(c.x, c.y, p.x, p.y)) a = Math.atan2(p.y - c.y, p.x - c.x);
      else { const t = M.flowStep(c.x, c.y); if (t) a = Math.atan2(t[1] - c.y, t[0] - c.x); }
      if (a !== undefined) { mx = Math.cos(a); my = Math.sin(a); }
    }
    if (!best && (mx || my)) c.aim = C.turn(c.aim, Math.atan2(my, mx), dt * 6);
    const sp = CD.speed * (dP > 60 ? 1.3 : 1);
    c.moving = !!(mx || my);
    if (mx || my) c.walk += dt * 9;
    M.move(c, (mx * sp + c.vx) * dt, (my * sp + c.vy) * dt);
    pushOutOfCars(c);
  }

  function hurtPlayer(dmg, ang) {
    const p = G.player;
    if (G.cheats.god) return;   // triche : godmode
    p.hp -= Math.round(dmg * G.mods.dmgTaken);
    p.hurtT = 0.2;
    p.invT = 0.08;
    p.vx += Math.cos(ang) * 80;
    p.vy += Math.sin(ang) * 80;
    G.shake = Math.max(G.shake, 4);
    G.redFlash = 0.25;
    blood(p.x, p.y, ang, 6);
    C.gore.hit(p.x, p.y, ang, dmg >= 20);
    C.sfx('hurt');
    if (p.hp <= 0 && G.mods.secondWind && !G.secondUsed) {
      // second souffle : une fois par gig, le coup mortel te laisse debout
      G.secondUsed = true; p.hp = 1; p.invT = 2; G.flash = 0.3;
      addFloat(p.x, p.y - 12, 'SECOND SOUFFLE', '#5dff9a'); C.sfx('inject');
      return;
    }
    if (p.hp <= 0) { p.hp = 0; gameOver('mort'); return; }
    // biomoniteur : injection automatique sous 30 % de PV, une fois par gig
    if (G.mods.bio && !G.bioUsed && p.hp < p.maxHp * 0.3 && p.inj > 0) {
      G.bioUsed = true;
      p.inj--;
      p.hp = Math.min(p.maxHp, p.hp + D.player.injectHeal);
      addFloat(p.x, p.y - 10, 'BIOMONITEUR +' + D.player.injectHeal, '#5dff9a');
      C.sfx('inject');
    }
  }

  // ---------- ennemis ----------
  function hitEnemy(e, dmg, ang, gibForce) {
    if (G.cheats.oneshot) dmg = Math.max(dmg, e.hp);   // triche : one shot
    const hpBefore = e.hp;
    e.hp -= dmg;
    C.gore.hit(e.x, e.y, ang, dmg >= 40);
    e.hurtT = 0.12;
    e.vx += Math.cos(ang) * 60;
    e.vy += Math.sin(ang) * 60;
    blood(e.x, e.y, ang, 6);
    alertEnemy(e);
    if (e.cop) C.ncpd.crime(e.hp <= 0 ? 'copDown' : 'copHurt', e.x, e.y);
    if (e.gang) { e.neutral = false; C.gangs.onHurt(e, e.hp <= 0); }
    if (e.hp <= 0) {
      // À 0 PV, l'ennemi n'est pas mort : il est à terre, et c'est au joueur de décider.
      e.hp = 0;
      e.state = 'down';
      e.downAng = ang;
      e.windT = 0;
      G.hitstop = 0.05;
      G.shake = Math.max(G.shake, 3);
      blood(e.x, e.y, ang, 14);
      // coup énorme : le corps éclate (pas de décision à prendre)
      C.arsenal.enemyDrop(e);   // son arme tombe par terre
      C.home.note('kills');
      C.skills.gain(gibForce || dmg >= 60 ? 15 : 10, e.x, e.y);
      if (G.mods.killHeal) G.player.hp = Math.min(G.player.maxHp, G.player.hp + G.mods.killHeal);   // adrénaline
      if ((dmg >= 60 && dmg - hpBefore >= e.maxHp * 0.5) || G.cheats.gore || gibForce) {
        e.gibbed = true; e.state = 'dead';
        C.gore.burst(e.x, e.y, ang, !!(e.d.chrome || e.type === 'brute' || e.psycho));
        if (e.cop) C.ncpd.crime('copKill', e.x, e.y);
      } else {
        C.gore.down(e.x, e.y, ang);
        addFloat(e.x, e.y - 8, 'À TERRE', '#ff8a5a');
      }
      if (e.rival || e.psycho) resolveMemory(e);
      // la prime : des eddies pour chaque ennemi mis à terre
      const gain = (D.eddies[e.type] || 0) + (e.rival ? D.eddies.rival : 0);
      if (gain) earn(gain, e.x, e.y - 1);
      C.sfx('down');
      if (!alive() && !G.cleared && M.def.site) { G.cleared = G.sites[M.id].cleared = true; C.sfx('clear'); earn(D.eddies.clear, G.player.x, G.player.y - 16); loyalty(D.companion.loyalty.clear, 'BIEN JOUÉ, ' + G.leader.nom + '.'); }
    } else C.sfx('hit');
  }

  function fireEnemy(e) {
    const w = e.wpn ? D.enemyArms[e.wpn] : e.d.weapon;
    e.fireCd = w.rate * C.rr(0.8, 1.3);
    let sx = e.x + Math.cos(e.aim) * 5, sy = e.y + Math.sin(e.aim) * 5;
    if (M.solidAt(sx, sy)) { sx = e.x; sy = e.y; }
    for (let i = 0; i < (w.pellets || 1); i++) {
      const a = e.aim + C.rr(-w.spread, w.spread);
      G.bullets.push({ x: sx, y: sy, vx: Math.cos(a) * w.speed, vy: Math.sin(a) * w.speed, dmg: w.dmg, team: 1, life: w.pellets ? 0.6 : 1.2, homing: w.homing || 0 });
    }
    e.muzzle = 0.06;
    C.sfx('eshot');
  }

  // Cible d'un ennemi : la plus proche entre le leader et le compagnon debout, en priorité celle qu'il voit.
  function targetFor(e) {
    const p = G.player, c = G.comp, h = C.contracts.hostage();
    // l'otage en fuite est une cible aussi, s'il est plus près et en vue
    if (h && M.los(e.x, e.y, h.x, h.y) && C.dist(e.x, e.y, h.x, h.y) < C.dist(e.x, e.y, p.x, p.y) * 0.8) return h;
    if (!c || c.state !== 'up') return p;
    const dp = C.dist(e.x, e.y, p.x, p.y), dc = C.dist(e.x, e.y, c.x, c.y);
    const sp = M.los(e.x, e.y, p.x, p.y), sc = M.los(e.x, e.y, c.x, c.y);
    if (sc && (!sp || dc < dp)) return c;
    return p;
  }

  function bruteStrike(e) {
    const p = e.target || G.player, m = e.d.melee;
    for (let i = 0; i < 6; i++) part(e.x + Math.cos(e.aim + (i - 2.5) * 0.25) * 9, e.y + Math.sin(e.aim + (i - 2.5) * 0.25) * 9, 0, 0, 0.12, '#ffd9a0', 'spark');
    if (C.dist(e.x, e.y, p.x, p.y) > m.range + p.r + 4) return;
    if (Math.abs(C.angDiff(e.aim, Math.atan2(p.y - e.y, p.x - e.x))) > 1.2) return;
    if (p === G.comp) { hurtComp(m.dmg, e.aim); return; }
    if (p.invT > 0) return;
    hurtPlayer(m.dmg, e.aim);
  }

  function chaseStep(e) {
    const t = M.flowStep(e.x, e.y);
    if (!t) return [0, 0, null];
    const a = Math.atan2(t[1] - e.y, t[0] - e.x);
    return [Math.cos(a), Math.sin(a), a];
  }

  function updateEnemy(e, dt) {
    if (e.state === 'dead') { e.downT = (e.downT || 0) + dt; return; }   // finit sa chute et la flaque s'étale
    if (e.state === 'spared') return;
    if (e.state === 'friend') {
      // allié : il attend, se tourne vers toi, et te parle quand tu t'approches
      const p = G.player, d = C.dist(e.x, e.y, p.x, p.y);
      if (d < 70) e.aim = C.turn(e.aim, Math.atan2(p.y - e.y, p.x - e.x), dt * 6);
      if (!e.gifted && d < 18) friendGift(e);
      return;
    }
    const decay = Math.pow(0.001, dt);
    if (e.state === 'down') {
      e.downT = (e.downT || 0) + dt;   // la flaque de sang s'étale
      e.vx *= decay; e.vy *= decay;
      M.move(e, e.vx * dt, e.vy * dt);
      if (C.rand() < dt * 1.2) part(e.x + C.rr(-2, 2), e.y + C.rr(-2, 2), 0, 0, 0.05, '#7a0d1d', 'blood');
      return;
    }
    const d = e.d;
    const p = (e.target = targetFor(e));   // le joueur ou le compagnon : le plus proche qu'il voit
    e.hurtT -= dt; e.fireCd -= dt; e.muzzle -= dt;
    if (e.stun > 0) e.stun -= dt;
    e.vx *= decay; e.vy *= decay;
    // optique brouillée (quickhack) : il ne voit plus rien, titube et tourne la tête
    if (e.blindT > 0) {
      e.blindT -= dt;
      e.aim += dt * 2.2; e.windT = 0; e.dashT = 0; e.moving = false;
      M.move(e, e.vx * dt, e.vy * dt);
      return;
    }

    const dist = C.dist(e.x, e.y, p.x, p.y);
    const toP = Math.atan2(p.y - e.y, p.x - e.x);
    const los = dist < d.sight + 40 && M.los(e.x, e.y, p.x, p.y) && !(G.cheats.invis && p === G.player);   // triche : camo optique

    // vision : cône de ~125° devant lui, ou tout près
    if (e.state === 'idle' && !e.neutral && los && dist < d.sight && (Math.abs(C.angDiff(e.aim, toP)) < 1.1 || dist < 36)) alertEnemy(e);

    let mx = 0, my = 0, speed = d.speed;
    if (e.distractT > 0) e.distractT -= dt;
    if (e.state === 'idle' && e.distractT > 0 && e.distract) {
      // distraction (quickhack) : il va voir ce qui se passe là-bas
      const [tx, ty] = e.distract, dd = C.dist(e.x, e.y, tx, ty);
      if (dd > 3) { mx = (tx - e.x) / dd; my = (ty - e.y) / dd; speed *= 0.55; e.aim = C.turn(e.aim, Math.atan2(my, mx), dt * 5); }
      else { e.look += dt; e.aim += Math.sin(e.look * 2) * dt * 1.5; }
    } else if (e.state === 'idle') {
      if (e.patrol) {
        const [tx, ty] = e.patrol[e.pi];
        const dd = C.dist(e.x, e.y, tx, ty);
        if (dd < 3) e.pi = (e.pi + 1) % e.patrol.length;
        else { mx = (tx - e.x) / dd; my = (ty - e.y) / dd; speed *= 0.45; e.aim = C.turn(e.aim, Math.atan2(my, mx), dt * 4); }
      } else {
        e.look += dt;
        e.aim += Math.sin(e.look * 0.7) * dt * 0.6;   // il regarde autour de lui
      }
    } else {
      e.react -= dt;
      if (los) e.aim = C.turn(e.aim, toP, dt * 7);
      if (e.d.weapon || e.wpn) {
        if (los && dist < 170) {
          // garde ses distances et se décale sur le côté
          e.strafeT -= dt;
          if (e.strafeT <= 0) { e.strafe *= -1; e.strafeT = C.rr(0.7, 1.6); }
          const [kmin, kmax] = d.keep || [55, 95], sf = d.strafe == null ? 0.7 : d.strafe;   // style de combat du gang
          const want = dist > kmax ? 1 : dist < kmin ? -1 : 0;
          const side = toP + Math.PI / 2;
          mx = Math.cos(toP) * want + Math.cos(side) * e.strafe * sf;
          my = Math.sin(toP) * want + Math.sin(side) * e.strafe * sf;
          speed *= 0.8;
          if (e.react <= 0 && e.fireCd <= 0 && e.stun <= 0 && Math.abs(C.angDiff(e.aim, toP)) < 0.25) fireEnemy(e);
        } else {
          const [cx, cy, a] = chaseStep(e);
          mx = cx; my = cy;
          if (a !== null && !los) e.aim = C.turn(e.aim, a, dt * 6);
        }
      } else {
        // corps à corps (brute, cyberpsycho) : fonce au contact, prend son élan (clignote) puis frappe
        e.dashCd -= dt;
        if (e.dashT > 0) {
          e.dashT -= dt;
          speed = 0;
          M.move(e, e.dashX * e.d.dash.speed * dt, e.dashY * e.d.dash.speed * dt);
          G.trail.push({ x: e.x, y: e.y, aim: e.aim, t: 0.3, max: 0.3, kind: 'psycho' });
        } else if (e.d.dash && los && dist > 28 && dist < 120 && e.dashCd <= 0 && e.react <= 0) {
          // dash façon Sandevistan vers le joueur
          e.dashT = e.d.dash.time; e.dashCd = e.d.dash.cd * C.rr(0.8, 1.2);
          e.dashX = Math.cos(toP); e.dashY = Math.sin(toP);
          C.sfx('dash');
        } else if (e.windT > 0) {
          e.windT -= dt;
          speed = 0;
          if (e.windT <= 0) bruteStrike(e);
        } else if (los && dist < 70) {
          mx = Math.cos(toP); my = Math.sin(toP);
          speed *= 1.25;
          if (dist < d.melee.range + p.r + 2 && e.fireCd <= 0 && e.react <= 0) { e.windT = d.melee.windup; e.fireCd = d.melee.rate; }
        } else {
          const [cx, cy, a] = chaseStep(e);
          mx = cx; my = cy;
          if (a !== null) e.aim = C.turn(e.aim, a, dt * 6);
        }
      }
    }
    if (e.stun > 0) speed *= 0.2;
    const ml = Math.hypot(mx, my);
    e.moving = ml > 0;
    if (ml > 0) { mx /= ml; my /= ml; e.walk += dt * 8; }
    M.move(e, (mx * speed + e.vx) * dt, (my * speed + e.vy) * dt);
  }

  // Les ennemis debout ne se marchent pas dessus, ni sur le joueur (sauf pendant son dash).
  function separate() {
    const list = G.enemies.filter(ALIVE);
    const p = G.player;
    const c = G.comp;
    if (c && c.state === 'up' && !c.inCar) {
      const dx = c.x - p.x, dy = c.y - p.y, d = Math.hypot(dx, dy) || 0.01, min = c.r + p.r;
      if (d < min) M.move(c, (dx / d) * (min - d), (dy / d) * (min - d));
      list.push(c);   // les ennemis le contournent aussi
    }
    if (p.dashT <= 0) {
      for (const e of list) {
        const dx = e.x - p.x, dy = e.y - p.y, d = Math.hypot(dx, dy) || 0.01, min = e.r + p.r;
        if (d < min) M.move(e, (dx / d) * (min - d), (dy / d) * (min - d));
      }
    }
    for (let i = 0; i < list.length; i++) {
      for (let j = i + 1; j < list.length; j++) {
        const a = list[i], b = list[j];
        const dx = b.x - a.x, dy = b.y - a.y, d = Math.hypot(dx, dy), min = a.r + b.r;
        if (d > 0 && d < min) {
          const push = (min - d) / 2, nx = dx / d, ny = dy / d;
          M.move(a, -nx * push, -ny * push);
          M.move(b, nx * push, ny * push);
        }
      }
    }
  }

  // ---------- balles ----------
  function updateBullets(dt) {
    const p = G.player;
    C.arsenal.parry();   // katana : renvoie les balles
    for (const b of G.bullets) {
      b.life -= dt;
      C.arsenal.steer(b, dt);   // balles guidées (arme smart)
      const steps = Math.max(1, Math.ceil(Math.hypot(b.vx, b.vy) * dt / 2));
      for (let i = 0; i < steps && !b.dead; i++) {
        b.x += b.vx * dt / steps;
        b.y += b.vy * dt / steps;
        if (M.solidAt(b.x, b.y)) {
          b.dead = true;
          sparks(b.x - b.vx * 0.004, b.y - b.vy * 0.004, b.team === 0 ? '#fff2a0' : '#ff8aa0', 5);
          break;
        }
        // les voitures arrêtent les balles ; au volant, tu prends la moitié des dégâts
        const hitCar = G.cars && G.cars.length && !(b.team === 0 && G.drive) ? C.cars.hitCircle(b.x, b.y, 0.5, G.cars) : null;
        if (hitCar) {
          b.dead = true;
          sparks(b.x, b.y, '#fff2a0', 4);
          if (hitCar === G.drive && b.team === 1) hurtPlayer(b.dmg * 0.5, Math.atan2(b.vy, b.vx));
          else if (b.own) C.traffic.shot(hitCar);
          break;
        }
        if (G.net && C.net.bulletHit(b)) { b.dead = true; break; }   // caméras et tourelles
        if (b.team === 0) {
          for (const e of G.enemies) {
            if (!ALIVE(e) || C.dist(b.x, b.y, e.x, e.y) >= e.r + 1 || (b.hits && b.hits.includes(e))) continue;
            if (!b.turret) G.reg.touches++;
            // à bout portant, le fusil à pompe fait éclater le corps
            const contact = b.gibContact && C.dist(b.ox, b.oy, e.x, e.y) < b.gibContact;
            hitEnemy(e, b.dmg, Math.atan2(b.vy, b.vx), contact && e.hp <= b.dmg * 3);
            if (b.pierce > 0) { b.pierce--; b.hits.push(e); continue; }   // le fusil de précision traverse
            b.dead = true;
            break;
          }
          // les balles du leader touchent aussi les passants
          if (!b.dead && b.own) for (const q of G.peds) {
            if (q.dead || C.dist(b.x, b.y, q.x, q.y) >= q.r + 1) continue;
            C.ncpd.hitPed(q, b.dmg, Math.atan2(b.vy, b.vx));
            b.dead = true;
            break;
          }
        } else if (b.team === 1 && C.dist(b.x, b.y, p.x, p.y) < p.r + 1 && p.invT <= 0) {
          hurtPlayer(b.dmg, Math.atan2(b.vy, b.vx));
          b.dead = true;
        } else if (b.team === 1 && C.contracts.hostage() && C.dist(b.x, b.y, C.contracts.hostage().x, C.contracts.hostage().y) < 4.5) {
          C.contracts.hurtHostage(C.contracts.hostage(), b.dmg, Math.atan2(b.vy, b.vx));
          b.dead = true;
        } else if (b.team === 1 && G.comp && G.comp.state === 'up' && C.dist(b.x, b.y, G.comp.x, G.comp.y) < G.comp.r + 1) {
          hurtComp(b.dmg, Math.atan2(b.vy, b.vx));
          b.dead = true;
        } else if (b.team === 2 && C.dist(b.x, b.y, p.x, p.y) < p.r + 2) {
          b.dead = true;   // balle hallucinée : elle disparaît en touchant
        }
      }
      if (b.life <= 0) b.dead = true;
    }
    G.bullets = G.bullets.filter(b => !b.dead);
  }

  // ---------- effets ----------
  function updateParts(dt) {
    for (const q of G.parts) {
      q.life -= dt;
      if (C.gore.updatePart(q, dt)) continue;   // sang et morceaux (gore.js)
      if (q.kind === 'blood' || q.kind === 'shell') {
        const f = Math.pow(0.0005, dt);
        q.vx *= f; q.vy *= f;
        const nx = q.x + q.vx * dt, ny = q.y + q.vy * dt;
        if (M.solidAt(nx, ny)) { q.vx = 0; q.vy = 0; } else { q.x = nx; q.y = ny; }
        // le sang retombe et reste au sol
        if (q.life <= 0 && q.kind === 'blood' && C.render) C.render.decal(q.x, q.y, q.color);
        if (q.life <= 0 && q.kind === 'shell' && C.render) C.render.decal(q.x, q.y, '#6b5a2e', 1, false);
      } else {
        q.x += q.vx * dt; q.y += q.vy * dt;
      }
    }
    G.parts = G.parts.filter(q => q.life > 0);
  }

  // Hallucinations : sous 50 d'humanité, de faux ennemis apparaissent et tirent des balles qui ne blessent pas.
  function hallucinate(dt) {
    for (const h of G.ghosts) {
      h.t -= dt;
      h.aim = Math.atan2(G.player.y - h.y, G.player.x - h.x);
      if (!h.shot && h.t < h.max * 0.5) {
        h.shot = true;
        const a = h.aim;
        G.bullets.push({ x: h.x, y: h.y, vx: Math.cos(a) * 200, vy: Math.sin(a) * 200, dmg: 0, team: 2, life: 1 });
      }
    }
    G.ghosts = G.ghosts.filter(h => h.t > 0);
    if (G.humanity >= D.humanity.hallucinate || M.def.outdoor) return;
    G.hallT -= dt;
    if (G.hallT <= 0) {
      const spot = M.randomFloorNear(G.player.x, G.player.y, 45, 90);
      if (spot) G.ghosts.push({ x: spot[0], y: spot[1], aim: 0, t: 1.3, max: 1.3, shot: false });
      G.hallT = C.rr(2.5, 6) * (0.4 + G.humanity / D.humanity.hallucinate);
    }
    if (G.humanity < D.humanity.glitch && C.rand() < dt * 1.5) G.glitchT = 0.12;
  }

  function updateCamera(dt) {
    const p = G.player, I = C.input;
    // la caméra suit le joueur en regardant un peu vers la souris, comme dans Hotline Miami
    // en voiture, elle regarde devant, d'autant plus loin qu'on roule vite
    const car = G.drive, look = car ? car.speed * 0.45 : 0;
    const tx = car ? car.x - C.W / 2 + Math.cos(car.ang) * look : p.x - C.W / 2 + (I.mx - C.W / 2) * 0.35;
    const ty = car ? car.y - C.H / 2 + Math.sin(car.ang) * look : p.y - C.H / 2 + (I.my - C.H / 2) * 0.35;
    const k = Math.min(1, dt * 8);
    // bornes de la caméra ; si la carte est plus petite que l'écran (480x270), on la centre
    const fit = (v, size, view) => (size + 48 <= view ? (size - view) / 2 : C.clamp(v, -24, size - view + 24));
    G.cam.x = fit(C.lerp(G.cam.x, tx, k), M.MW * 8, C.W);
    G.cam.y = fit(C.lerp(G.cam.y, ty, k), M.MH * 8, C.H);
    G.shake = Math.max(0, G.shake - dt * 20);
  }

  // ---------- boucle ----------
  G.update = function (dt) {
    const I = C.input;
    C.music.update(dt);   // musique et radio (music.js), dans tous les écrans
    if (G.mode === 'title') {
      if (C.keyHit('KeyV')) C.nextResolution();   // option de résolution, gardée d'une partie à l'autre
      else if (C.keyHit('Delete')) {
        // effacer la ville (et la partie en cours) : deux appuis à moins de 2 s
        if (G.wipeT > 0) { L().wipe(); C.run.clear(); G.wipeT = 0; C.sfx('over'); } else G.wipeT = 2;
      } else if (C.keyHit('KeyN') && C.run.info()) {
        // nouveau leader alors qu'une partie est sauvegardée : deux appuis, l'ancien disparaît
        if (G.abandonT > 0) { C.run.abandon(); G.abandonT = 0; C.audioInit(); openCreate(); } else G.abandonT = 2;
      } else if (I.mhit[0] && C.render && C.render.overQuit()) { if (window.NOVA) window.NOVA.quit(); else window.close(); }
      else if (I.mhit[0] || C.keyHit('Space') || C.keyHit('Enter')) { C.audioInit(); if (!G.resume()) openCreate(); }
      if (G.wipeT > 0) G.wipeT -= dt;
      if (G.abandonT > 0) G.abandonT -= dt;
      C.consumeInput();
      return;
    }
    if (G.mode === 'create') {
      // choix du nouveau leader : touches 1 à 3, clic sur une carte, ou flèches / manette puis Entrée (✕)
      let choice = -1;
      for (let i = 0; i < 3; i++) if (C.keyHit('Digit' + (i + 1)) || C.keyHit('Numpad' + (i + 1))) choice = i;
      const n = G.profiles.length;
      if (C.keyHit('ArrowLeft') || C.keyHit('KeyA')) G.createSel = G.createSel < 0 ? 0 : (G.createSel + n - 1) % n;
      if (C.keyHit('ArrowRight') || C.keyHit('KeyD')) G.createSel = G.createSel < 0 ? 0 : (G.createSel + 1) % n;
      if (C.keyHit('Enter') || C.keyHit('KeyE')) choice = G.createSel >= 0 ? G.createSel : 0;
      if (I.mhit[0] && C.render) choice = C.render.cardUnderMouse();
      if (choice >= 0 && G.profiles[choice]) G.start(G.profiles[choice]);
      else if (C.keyHit('Escape')) G.mode = 'title';
      C.consumeInput();
      return;
    }
    if (G.mode === 'over') {
      G.overT += dt;
      updateParts(dt * 0.4);
      if (G.overT > 0.8 && (C.keyHit('Enter') || C.keyHit('KeyR') || I.mhit[0])) openCreate();
      C.consumeInput();
      return;
    }

    // play
    G.fade = Math.max(0, (G.fade || 0) - dt);
    // micro-gel à l'impact : on ne vide pas les touches, elles seront traitées juste après
    if (G.hitstop > 0) { G.hitstop -= dt; return; }
    // boutique ouverte : le jeu est en pause
    if (G.shop) { updateShop(dt); C.consumeInput(); return; }
    if (G.board) { updateBoard(dt); C.consumeInput(); return; }
    if (G.dealerMenu) { updateDealer(); C.consumeInput(); return; }
    if (G.metroMenu) { updateMetro(); C.consumeInput(); return; }
    if (G.gunMenu) { C.arsenal.updateShop(); C.consumeInput(); return; }
    if (G.barMenu) { C.home.updateBar(); C.consumeInput(); return; }
    if (G.cheatMenu) { C.cheat.updateMenu(dt); C.consumeInput(); return; }
    if (G.skillMenu) { C.skills.update(dt); C.consumeInput(); return; }
    if (C.keyHit('KeyK') && !G.shop && !G.board && !G.dealerMenu && !G.breach && !G.ride && !G.gunMenu) { C.skills.open(); C.consumeInput(); return; }
    if ((C.keyHit('Backquote') || C.keyHit('F2')) && !G.shop && !G.board && !G.dealerMenu && !G.breach && !G.ride) { C.cheat.open(); C.consumeInput(); return; }
    if (G.ride) { updateRide(dt); C.consumeInput(); return; }
    if (G.breach) { C.net.updateBreach(dt); C.consumeInput(); return; }
    // grand contrat réussi : courte pause, puis le leader raccroche
    if (G.endT > 0) { G.endT -= dt; if (G.endT <= 0) retireAsFixer(); }
    G.time += dt;
    G.reg.temps += dt;

    // Sandevistan
    const S = G.sandy, SD = D.sandy;
    if ((C.keyHit('ShiftLeft') || C.keyHit('ShiftRight')) && M.id !== 'planque' && !G.drive) {
      if (S.on) { S.on = false; C.sfx('sandyOff'); }
      else if (S.charge >= sandyDur() * SD.minCharge) {
        S.on = true;
        G.humanity = Math.max(0, G.humanity - SD.humanityCost);
        G.flash = 0.2;
        addFloat(G.player.x, G.player.y - 10, '-' + SD.humanityCost + ' HUMANITÉ', '#ff3ec8');
        if (G.humanity < D.humanity.hallucinate) loyalty(D.companion.loyalty.scared, 'TU LUI FAIS PEUR');
        C.sfx('sandyOn');
      } else C.sfx('empty');
    }
    if (S.on) {
      S.charge -= dt;
      S.trailT -= dt;
      if (S.trailT <= 0) { S.trailT = 0.035; G.trail.push({ x: G.player.x, y: G.player.y, aim: G.player.aim, t: 0.4, max: 0.4, kind: 'sandy' }); }
      if (S.charge <= 0) { S.charge = 0; S.on = false; C.sfx('sandyOff'); }
    } else {
      S.charge = Math.min(sandyDur(), S.charge + dt * sandyDur() / SD.recharge);
    }
    // scan du netrunner (TAB maintenu, dans un bâtiment) : le monde ralentit aussi
    G.scanOn = C.key('Tab') && M.id !== 'planque' && !G.drive;
    const wdt = dt * Math.min(S.on ? (G.mods.sandySlow || SD.slow) : 1, G.scanOn ? D.net.scanSlow : 1) * (G.cheats.slowmo ? 0.5 : 1);   // le monde ralentit, le joueur non

    updatePlayer(dt);
    C.net.scan();
    M.updateFlow(G.player.x, G.player.y);
    for (const e of G.enemies) updateEnemy(e, wdt);
    if (M.def.outdoor) for (const e of G.enemies) if (ALIVE(e)) pushOutOfCars(e);   // les flics contournent les voitures
    C.traffic.update(wdt);
    C.ncpd.update(dt);
    C.amb.sound();
    C.gore.update(dt);
    C.gangs.update(dt);
    C.contracts.update(dt);
    C.home.update(dt);
    G.xpFlash = (G.xpFlash || 0) - dt;
    C.cheat.update();
    updateComp(wdt);
    updatePeds(wdt);
    separate();
    C.net.update(dt, wdt);
    updateContract(dt);
    updateBullets(wdt);
    updateParts(wdt);
    hallucinate(dt);
    for (const t of G.trail) t.t -= dt;
    G.trail = G.trail.filter(t => t.t > 0);
    for (const f of G.floats) { f.t -= dt; f.y -= dt * 10; }
    G.floats = G.floats.filter(f => f.t > 0);
    G.flash -= dt; G.redFlash -= dt; G.muzzle -= dt; G.glitchT -= dt; G.revealT -= dt;
    updateCamera(dt);
    if (G.mode === 'play' && G.humanity <= 0) gameOver('psycho');
    C.consumeInput();
  };

  function openCreate() {
    G.profiles = L().profiles();
    G.mode = 'create';
    G.createSel = -1;   // carte choisie aux flèches / à la manette (-1 : c'est la souris qui désigne)
  }
  G.openCreate = openCreate;
  // outils internes dont se sert le netrunning (netrun.js)
  G.fx = { hitEnemy, alertEnemy, addFloat, earn, sparks, part, blood, makeEnemy, pushOutOfCars, recruit, hurtPlayer, enterCar };
  G.refreshMods = refreshMods;
  G.alive = alive;
  G.ALIVE = ALIVE;
})();
