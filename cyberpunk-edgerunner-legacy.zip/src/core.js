'use strict';
// Socle : constantes, maths, canvas pixel net en 320x180, entrées clavier/souris, police pixel 3x5, sons synthétisés.
(function () {
  const CEL = (window.CEL = {});
  CEL.VERSION = '0.21.0';
  CEL.W = 320;          // résolution interne
  CEL.H = 180;
  CEL.T = 8;            // taille d'une tuile en pixels
  CEL.STEP = 1 / 60;    // pas de simulation fixe

  // ---------- maths ----------
  CEL.clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  CEL.lerp = (a, b, t) => a + (b - a) * t;
  CEL.dist = (ax, ay, bx, by) => Math.hypot(bx - ax, by - ay);
  CEL.angDiff = (a, b) => {
    let d = (b - a) % (Math.PI * 2);
    if (d > Math.PI) d -= Math.PI * 2;
    if (d < -Math.PI) d += Math.PI * 2;
    return d;
  };
  CEL.turn = (a, target, max) => a + CEL.clamp(CEL.angDiff(a, target), -max, max);

  // Générateur pseudo-aléatoire à graine (mulberry32) : une partie rejouée donne la même salle.
  let seed = 1;
  CEL.reseed = s => { seed = s | 0; };
  CEL.rand = () => {
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  CEL.rr = (a, b) => a + (b - a) * CEL.rand();

  // ---------- canvas ----------
  // On dessine tout dans un petit canvas 320x180, puis on l'agrandit d'un facteur ENTIER
  // sans lissage : les pixels restent nets quelle que soit la taille de la fenêtre.
  CEL.initCanvas = function () {
    const view = document.getElementById('view');
    const low = document.createElement('canvas');
    low.width = CEL.W;
    low.height = CEL.H;
    CEL.view = view;
    CEL.vctx = view.getContext('2d');
    CEL.low = low;
    CEL.g = low.getContext('2d');
    CEL.g.imageSmoothingEnabled = false;
    const resize = (CEL.resize = () => {
      const dpr = window.devicePixelRatio || 1;
      const w = Math.max(1, Math.floor(innerWidth * dpr));
      const h = Math.max(1, Math.floor(innerHeight * dpr));
      view.width = w;
      view.height = h;
      CEL.dpr = dpr;
      CEL.scale = Math.max(1, Math.floor(Math.min(w / CEL.W, h / CEL.H)));
      CEL.ox = Math.floor((w - CEL.W * CEL.scale) / 2);
      CEL.oy = Math.floor((h - CEL.H * CEL.scale) / 2);
    });
    addEventListener('resize', resize);
    let saved = 0;
    try { saved = Number(localStorage.getItem('cel-resolution')) || 0; } catch (e) { saved = 0; }
    CEL.setResolution(saved);
  };

  // Résolutions internes proposées : 320x180 (x6 en 1080p) ou 480x270 (x4 en 1080p, on voit plus loin).
  CEL.RESOLUTIONS = [[320, 180], [480, 270]];
  CEL.resIndex = 0;
  CEL.setResolution = function (i) {
    i = CEL.clamp(i | 0, 0, CEL.RESOLUTIONS.length - 1);
    CEL.resIndex = i;
    [CEL.W, CEL.H] = CEL.RESOLUTIONS[i];
    CEL.low.width = CEL.W;              // redimensionner un canvas remet son contexte à zéro :
    CEL.low.height = CEL.H;
    CEL.g.imageSmoothingEnabled = false; // on recoupe donc le lissage
    CEL.input.mx = CEL.W / 2;
    CEL.input.my = CEL.H / 2;
    CEL.resize();
    try { localStorage.setItem('cel-resolution', String(i)); } catch (e) { /* pas de stockage */ }
  };
  CEL.nextResolution = () => CEL.setResolution((CEL.resIndex + 1) % CEL.RESOLUTIONS.length);

  CEL.present = function () {
    const v = CEL.vctx;
    v.imageSmoothingEnabled = false;
    v.fillStyle = '#000';
    v.fillRect(0, 0, CEL.view.width, CEL.view.height);
    v.drawImage(CEL.low, CEL.ox, CEL.oy, CEL.W * CEL.scale, CEL.H * CEL.scale);
  };

  // ---------- entrées ----------
  // On lit e.code (position physique de la touche) : ZQSD en AZERTY et WASD en QWERTY tombent sur les mêmes codes.
  const I = (CEL.input = {
    down: new Set(), hit: new Set(),
    mx: CEL.W / 2, my: CEL.H / 2,
    mb: [false, false, false], mhit: [false, false, false],
  });
  const BLOCK = new Set(['Space', 'Tab', 'F2', 'Backquote', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'ShiftLeft', 'ShiftRight']);
  addEventListener('keydown', e => {
    if (BLOCK.has(e.code)) e.preventDefault();
    if (!e.repeat) I.hit.add(e.code);
    I.down.add(e.code);
  });
  addEventListener('keyup', e => I.down.delete(e.code));
  addEventListener('blur', () => { I.down.clear(); I.mb = [false, false, false]; });
  const toLow = e => {
    const d = CEL.dpr || 1;
    I.mx = CEL.clamp((e.clientX * d - CEL.ox) / CEL.scale, 0, CEL.W - 1);
    I.my = CEL.clamp((e.clientY * d - CEL.oy) / CEL.scale, 0, CEL.H - 1);
  };
  addEventListener('mousemove', toLow);
  addEventListener('mousedown', e => {
    toLow(e);
    if (e.button < 3) { I.mb[e.button] = true; I.mhit[e.button] = true; }
  });
  addEventListener('mouseup', e => { if (e.button < 3) I.mb[e.button] = false; });
  addEventListener('contextmenu', e => e.preventDefault());

  CEL.key = c => I.down.has(c);
  CEL.keyHit = c => I.hit.has(c);
  CEL.consumeInput = () => { I.hit.clear(); I.mhit = [false, false, false]; };

  // Noms des touches à afficher : la vraie lettre du clavier du joueur quand le navigateur la donne (Z en AZERTY).
  const LABELS = { KeyW: 'W', KeyA: 'A', KeyS: 'S', KeyD: 'D', KeyE: 'E', KeyR: 'R', KeyF: 'F', KeyC: 'C', KeyV: 'V', KeyG: 'G', KeyK: 'K', KeyM: 'M', Space: 'ESPACE', ShiftLeft: 'MAJ', Enter: 'ENTRÉE', Tab: 'TAB' };
  CEL.keyLabel = c => LABELS[c] || c;
  try {
    if (navigator.keyboard && navigator.keyboard.getLayoutMap) {
      navigator.keyboard.getLayoutMap().then(m => {
        for (const c of ['KeyW', 'KeyA', 'KeyS', 'KeyD', 'KeyE', 'KeyR', 'KeyF', 'KeyC', 'KeyV', 'KeyG', 'KeyK', 'KeyM']) {
          const k = m.get(c);
          if (k) LABELS[c] = k.toUpperCase();
        }
      }).catch(() => {});
    }
  } catch (e) { /* pas de carte du clavier : on garde les noms par défaut */ }

  // ---------- police pixel 3x5 ----------
  // Chaque glyphe = 15 bits, ligne par ligne (3 colonnes x 5 lignes).
  const GLYPHS = {
    A: '010101111101101', B: '110101110101110', C: '011100100100011', D: '110101101101110',
    E: '111100110100111', F: '111100110100100', G: '011100101101011', H: '101101111101101',
    I: '111010010010111', J: '001001001101010', K: '101101110101101', L: '100100100100111',
    M: '101111111101101', N: '110101101101101', O: '010101101101010', P: '110101110100100',
    Q: '010101101111011', R: '110101110101101', S: '011100010001110', T: '111010010010010',
    U: '101101101101111', V: '101101101101010', W: '101101111111101', X: '101101010101101',
    Y: '101101010010010', Z: '111001010100111',
    0: '111101101101111', 1: '010110010010111', 2: '110001010100111', 3: '110001010001110',
    4: '101101111001001', 5: '111100110001110', 6: '011100110101010', 7: '111001010010010',
    8: '111101111101111', 9: '010101011001110',
    '.': '000000000000010', ',': '000000000010100', ':': '000010000010000', '!': '010010010000010',
    '?': '110001010000010', '-': '000000111000000', '/': '001001010100100', '+': '000010111010000',
    '%': '101001010100101', "'": '010010000000000', '(': '010100100100010', ')': '010001001001010',
    '>': '100010001010100', '<': '001010100010001', '·': '000000010000000', '[': '110100100100110',
    ']': '011001001001011', '€': '011100110100011', '*': '010111010101000', '$': '011110010011110', '_': '000000000000111', '=': '000111000111000', '×': '000101010101000',
  };
  const ALIAS = { 'É': 'E', 'È': 'E', 'Ê': 'E', 'Ë': 'E', 'À': 'A', 'Â': 'A', 'Ç': 'C', 'Ô': 'O', 'Î': 'I', 'Ï': 'I', 'Ù': 'U', 'Û': 'U', '’': "'" };
  CEL.textWidth = (s, k = 1) => Math.max(0, String(s).length * 4 * k - k);
  function drawText(g, s, x, y, color, k) {
    g.fillStyle = color;
    for (let i = 0; i < s.length; i++) {
      const gl = GLYPHS[ALIAS[s[i]] || s[i]];
      if (!gl) continue;
      for (let p = 0; p < 15; p++) {
        if (gl.charCodeAt(p) === 49) g.fillRect(x + i * 4 * k + (p % 3) * k, y + ((p / 3) | 0) * k, k, k);
      }
    }
  }
  // text(g, "texte", x, y, couleur, {scale, align: 'center'|'right', shadow: couleur})
  CEL.text = function (g, s, x, y, color, opt = {}) {
    const k = opt.scale || 1;
    s = String(s).toUpperCase();
    const w = CEL.textWidth(s, k);
    if (opt.align === 'center') x -= Math.floor(w / 2);
    else if (opt.align === 'right') x -= w;
    x = Math.round(x);
    y = Math.round(y);
    if (opt.shadow) drawText(g, s, x + k, y + k, opt.shadow, k);
    drawText(g, s, x, y, color, k);
    return w;
  };

  // ---------- sons synthétisés (aucun fichier audio) ----------
  let ac = null, master = null, noise = null;
  CEL.audioInit = () => {
    if (ac) return;
    try {
      ac = new (window.AudioContext || window.webkitAudioContext)();
      master = ac.createGain();
      master.gain.value = 0.3;
      master.connect(ac.destination);
      noise = ac.createBuffer(1, ac.sampleRate, ac.sampleRate);
      const d = noise.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    } catch (e) { ac = null; }
  };
  // Pour la musique (music.js) : le contexte audio, la sortie générale et le buffer de bruit.
  CEL.audio = () => (ac ? { ac, master, noise } : null);
  function tone(f0, f1, dur, type, vol) {
    const t = ac.currentTime, o = ac.createOscillator(), g = ac.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f0, t);
    o.frequency.exponentialRampToValueAtTime(Math.max(1, f1), t + dur);
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(master);
    o.start(t); o.stop(t + dur + 0.02);
  }
  function hiss(dur, vol, freq, q = 0.8) {
    const t = ac.currentTime, s = ac.createBufferSource(), f = ac.createBiquadFilter(), g = ac.createGain();
    s.buffer = noise;
    f.type = 'bandpass'; f.frequency.value = freq; f.Q.value = q;
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f); f.connect(g); g.connect(master);
    s.start(t, Math.random() * 0.5); s.stop(t + dur + 0.02);
  }
  // Moteur de voiture : un grondement continu dont la hauteur suit la vitesse (0 = coupé).
  let eng = null;
  CEL.engine = function (level) {
    if (!ac) return;
    try {
      if (!eng && level > 0) {
        const o = ac.createOscillator(), o2 = ac.createOscillator(), f = ac.createBiquadFilter(), g = ac.createGain();
        o.type = 'sawtooth'; o2.type = 'square'; f.type = 'lowpass'; f.frequency.value = 500; g.gain.value = 0;
        o.connect(f); o2.connect(f); f.connect(g); g.connect(master); o.start(); o2.start();
        eng = { o, o2, g };
      }
      if (!eng) return;
      const t = ac.currentTime;
      eng.o.frequency.setTargetAtTime(38 + level * 110, t, 0.08);
      eng.o2.frequency.setTargetAtTime(19 + level * 55, t, 0.08);
      eng.g.gain.setTargetAtTime(level > 0 ? 0.06 + level * 0.08 : 0, t, 0.1);
    } catch (e) { /* son ignoré */ }
  };

  // Sirène du NCPD : un son continu dont la hauteur monte et descend (un oscillateur lent module la fréquence).
  let sir = null;
  CEL.siren = function (level) {
    if (!ac) return;
    try {
      if (!sir && level > 0) {
        const o = ac.createOscillator(), lfo = ac.createOscillator(), lg = ac.createGain(), f = ac.createBiquadFilter(), g = ac.createGain();
        o.type = 'square'; o.frequency.value = 760;
        lfo.type = 'triangle'; lfo.frequency.value = 0.55; lg.gain.value = 260;
        lfo.connect(lg); lg.connect(o.frequency);
        f.type = 'lowpass'; f.frequency.value = 1400; g.gain.value = 0;
        o.connect(f); f.connect(g); g.connect(master); o.start(); lfo.start();
        sir = { g };
      }
      if (sir) sir.g.gain.setTargetAtTime(level > 0 ? 0.025 : 0, ac.currentTime, 0.3);
    } catch (e) { /* son ignoré */ }
  };

  // Pluie : bruit blanc filtré en boucle (level 0 = coupé, 1 = dehors, entre les deux = étouffé).
  let rn = null;
  CEL.rainSound = function (level) {
    if (!ac) return;
    try {
      if (!rn && level > 0) {
        const s = ac.createBufferSource(), f = ac.createBiquadFilter(), g = ac.createGain();
        s.buffer = noise; s.loop = true;
        f.type = 'lowpass'; f.frequency.value = 1600; g.gain.value = 0;
        s.connect(f); f.connect(g); g.connect(master); s.start();
        rn = { f, g };
      }
      if (!rn) return;
      rn.g.gain.setTargetAtTime(level * 0.09, ac.currentTime, 0.4);
      rn.f.frequency.setTargetAtTime(level >= 1 ? 1600 : 500, ac.currentTime, 0.3);
    } catch (e) { /* son ignoré */ }
  };

  CEL.sfx = function (kind) {
    if (!ac) return;
    try {
      switch (kind) {
        case 'shot': hiss(0.12, 0.9, 1800, 0.6); tone(180, 60, 0.08, 'square', 0.25); break;
        case 'eshot': hiss(0.1, 0.5, 1100, 0.6); tone(140, 50, 0.07, 'square', 0.15); break;
        case 'hit': tone(220, 90, 0.07, 'square', 0.25); break;
        case 'hurt': tone(160, 40, 0.18, 'sawtooth', 0.35); hiss(0.1, 0.4, 600); break;
        case 'down': tone(300, 50, 0.25, 'sawtooth', 0.3); break;
        case 'slash': hiss(0.12, 0.6, 3500, 1.5); break;
        case 'dash': hiss(0.18, 0.4, 900, 0.5); break;
        case 'empty': tone(900, 700, 0.03, 'square', 0.15); break;
        case 'reload': tone(500, 520, 0.04, 'square', 0.15); setTimeout(() => ac && tone(700, 720, 0.04, 'square', 0.15), 90); break;
        case 'injectStart': tone(600, 900, 0.08, 'sine', 0.2); break;
        case 'inject': tone(700, 1400, 0.2, 'sine', 0.25); break;
        case 'sandyOn': tone(900, 90, 0.5, 'sawtooth', 0.25); hiss(0.4, 0.3, 300); break;
        case 'sandyOff': tone(90, 700, 0.25, 'sawtooth', 0.18); break;
        case 'execute': tone(120, 40, 0.3, 'sawtooth', 0.35); hiss(0.2, 0.5, 400); break;
        case 'spare': tone(440, 660, 0.15, 'sine', 0.2); break;
        case 'clear': tone(330, 660, 0.3, 'triangle', 0.25); setTimeout(() => ac && tone(495, 990, 0.4, 'triangle', 0.25), 180); break;
        case 'over': tone(220, 30, 1.2, 'sawtooth', 0.35); break;
        case 'alarm': for (let i = 0; i < 3; i++) setTimeout(() => ac && (tone(880, 880, 0.12, 'square', 0.16), setTimeout(() => ac && tone(660, 660, 0.12, 'square', 0.16), 130)), i * 280); break;
        case 'upload': tone(1200, 1600, 0.05, 'square', 0.08); setTimeout(() => ac && tone(1600, 2000, 0.05, 'square', 0.08), 60); break;
        case 'hack': tone(400, 1800, 0.12, 'sawtooth', 0.12); hiss(0.1, 0.3, 4000, 2); break;
        case 'breach': tone(1500, 1500, 0.03, 'square', 0.1); break;
        case 'gib': hiss(0.25, 0.8, 250, 0.7); tone(110, 30, 0.25, 'sawtooth', 0.3); setTimeout(() => ac && hiss(0.15, 0.4, 600, 1), 90); break;
        case 'honk': tone(420, 410, 0.18, 'square', 0.1); tone(330, 325, 0.18, 'square', 0.08); break;
        case 'radio': hiss(0.25, 0.35, 2500, 0.4); tone(880, 1320, 0.08, 'sine', 0.05); break;
        case 'wanted': tone(500, 1000, 0.15, 'square', 0.12); setTimeout(() => ac && tone(1000, 500, 0.15, 'square', 0.12), 160); break;
      }
    } catch (e) { /* son ignoré */ }
  };
})();
