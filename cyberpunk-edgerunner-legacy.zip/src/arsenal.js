'use strict';
// Arsenal : armes au sol (lâchées par les ennemis, à ramasser façon Hotline Miami), l'armurier de la planque,
// les balles guidées de l'arme smart, la parade au katana, et les icônes des armes.
//
// Le joueur porte une arme à feu (p.weapon, avec son chargeur p.mag) et une arme de corps à corps (p.melee).
// Ramasser une arme échange : celle qu'on tenait tombe au sol avec ce qu'il restait dans son chargeur.
(function () {
  const C = CEL, D = C.DEF, M = C.map;
  const AR = (C.arsenal = {});
  const G = () => C.game;
  const W = D.weapons;
  const MAX_DROPS = 40;

  // ---------- armes au sol ----------
  // Les armes au sol sont gardées par carte pendant le gig (on peut revenir chercher un fusil laissé là).
  AR.dropsFor = id => { const g = G(); g.dropsByMap = g.dropsByMap || {}; return (g.dropsByMap[id] = g.dropsByMap[id] || []); };
  AR.drop = function (id, x, y, mag) {
    const list = AR.dropsFor(M.id);
    if (!W[id]) return;
    // l'arme glisse un peu en tombant
    for (let i = 0; i < 6; i++) {
      const a = Math.random() * 6.28, r = 3 + Math.random() * 5, nx = x + Math.cos(a) * r, ny = y + Math.sin(a) * r;
      if (!M.solidAt(nx, ny)) { x = nx; y = ny; break; }
    }
    list.push({ id, x, y, mag: mag == null ? W[id].mag : mag, ang: Math.random() * 6.28 - 3.14, t: 0 });
    if (list.length > MAX_DROPS) list.shift();
  };
  // Ce qu'un ennemi lâche en tombant.
  AR.enemyDrop = function (e) {
    if (e.dropped) return;
    e.dropped = true;
    const id = e.d.drop || e.wpn || (e.d.weapon ? (e.type === 'swat' || e.type === 'cadre' ? 'smg' : 'pistol') : null);
    if (!id) return;   // les brutes se battent à mains nues
    AR.drop(id, e.x, e.y, W[id].kind === 'gun' ? Math.max(1, Math.round(W[id].mag * (0.3 + Math.random() * 0.6))) : null);
  };
  AR.nearest = function (x, y, r = 12) {
    let best = null, bd = r;
    for (const d of AR.dropsFor(M.id)) { const dd = C.dist(x, y, d.x, d.y); if (dd < bd) { bd = dd; best = d; } }
    return best;
  };
  AR.pickup = function (d) {
    const g = G(), p = g.player, list = AR.dropsFor(M.id), w = W[d.id];
    list.splice(list.indexOf(d), 1);
    if (w.kind === 'melee') {
      if (p.melee !== 'blade') AR.drop(p.melee, p.x, p.y, null);   // la lame de base ne se jette pas : elle est implantée
      p.melee = d.id;
    } else {
      AR.drop(p.weapon, p.x, p.y, p.mag);
      p.weapon = d.id; p.mag = d.mag; p.reloadT = 0; p.fireCd = 0.15;
    }
    g.fx.addFloat(p.x, p.y - 12, w.name, '#ffd23e');
    C.sfx('reload');
  };
  AR.label = d => 'RAMASSER : ' + W[d.id].name + (W[d.id].kind === 'gun' ? ' (' + d.mag + ')' : '');

  // ---------- balles guidées et parade ----------
  // L'arme smart : la balle tourne vers la cible la plus proche devant elle (ennemis pour toi, toi pour eux).
  AR.steer = function (b, dt) {
    if (!b.homing) return;
    const g = G();
    const sp = Math.hypot(b.vx, b.vy), dir = Math.atan2(b.vy, b.vx);
    let best = null, bd = 130;
    const cands = b.team === 0 ? g.enemies.filter(g.ALIVE) : [g.player];
    for (const o of cands) {
      const d = C.dist(b.x, b.y, o.x, o.y);
      if (d < bd && Math.abs(C.angDiff(dir, Math.atan2(o.y - b.y, o.x - b.x))) < 1.1) { bd = d; best = o; }
    }
    if (!best) return;
    const a = C.turn(dir, Math.atan2(best.y - b.y, best.x - b.x), b.homing * dt);
    b.vx = Math.cos(a) * sp; b.vy = Math.sin(a) * sp;
  };
  // Katana : pendant le coup, les balles ennemies qui arrivent devant toi sont renvoyées.
  AR.parry = function () {
    const g = G(), p = g.player;
    if (!W[p.melee].parry || p.slashT <= 0) return;
    for (const b of g.bullets) {
      if (b.team !== 1 || C.dist(b.x, b.y, p.x, p.y) > 18) continue;
      if (Math.abs(C.angDiff(p.slashA, Math.atan2(b.y - p.y, b.x - p.x))) > 1.2) continue;
      const sp = Math.hypot(b.vx, b.vy) * 1.2, a = p.slashA + (Math.random() - 0.5) * 0.3;
      b.vx = Math.cos(a) * sp; b.vy = Math.sin(a) * sp; b.team = 0; b.own = true; b.dmg *= 2; b.life = 0.8;
      g.fx.sparks(b.x, b.y, '#e8f6ff', 6);
      if (!g.parryT || g.time - g.parryT > 0.6) { g.parryT = g.time; g.fx.addFloat(p.x, p.y - 12, 'PARADE', '#e8f6ff'); }
      C.sfx('hit');
    }
  };

  // ---------- armurier (planque) ----------
  AR.shopItems = () => ['pistol', 'smg', 'shotgun', 'smart', 'sniper', 'katana'];
  AR.openShop = function () { G().gunMenu = { sel: 0, msg: 'CHOISIS TON JOUET.', msgCol: '#c7d5e0', msgT: 99, lmx: C.input.mx, lmy: C.input.my }; C.sfx('spare'); };
  function buy(id) {
    const g = G(), s = g.gunMenu, p = g.player, L0 = g.leader, w = W[id];
    const set = (t, c) => { s.msg = t; s.msgCol = c; s.msgT = 3; };
    const owned = w.kind === 'melee' ? p.melee === id : p.weapon === id;
    if (owned) {
      // déjà en main : on remplit le chargeur gratuitement
      if (w.kind === 'gun') { p.mag = w.mag; p.reloadT = 0; return set('CHARGEUR PLEIN. CADEAU.', '#5dff9a'); }
      return set("TU L'AS DÉJÀ.", '#8f98a0');
    }
    if (L0.eddies < w.prix) return set("REVIENS AVEC DES EDDIES.", '#ff5a7a');
    L0.eddies -= w.prix;
    if (w.kind === 'melee') { if (p.melee !== 'blade') AR.drop(p.melee, p.x, p.y, null); p.melee = id; }
    else { AR.drop(p.weapon, p.x, p.y, p.mag); p.weapon = id; p.mag = w.mag; p.reloadT = 0; }
    C.sfx('clear');
    set(w.name + ' À TOI. ' + (w.kind === 'gun' ? "L'ANCIENNE EST PAR TERRE." : ''), '#5dff9a');
  }
  AR.updateShop = function () {
    const g = G(), s = g.gunMenu, items = AR.shopItems(), I = C.input, n = items.length;
    s.msgT -= C.STEP;
    if (C.keyHit('ArrowUp') || C.keyHit('KeyW')) s.sel = (s.sel + n - 1) % n;
    if (C.keyHit('ArrowDown') || C.keyHit('KeyS')) s.sel = (s.sel + 1) % n;
    const row = AR.rowUnderMouse();
    if (row >= 0 && (I.mx !== s.lmx || I.my !== s.lmy)) s.sel = row;
    s.lmx = I.mx; s.lmy = I.my;
    if (C.keyHit('KeyE') || C.keyHit('Enter') || (I.mhit[0] && row >= 0)) buy(items[s.sel]);
    else if (C.keyHit('Escape') || I.mhit[2]) g.gunMenu = null;
  };

  // ---------- dessin ----------
  const R = (g, c, x, y, w, h) => { g.fillStyle = c; g.fillRect(Math.round(x), Math.round(y), w, h); };
  // Icône d'une arme, horizontale, canon vers la droite, centrée en (x, y). k : échelle (1 au sol, 2 en boutique).
  AR.icon = function (g, id, x, y, k = 1) {
    const o = (a, b, w, h, c) => R(g, c, x + a * k, y + b * k, w * k, h * k);
    const dark = '#14141b', steel = '#5a5e6a', hi = '#9aa0ae';
    switch (id) {
      case 'pistol': o(-3, -1, 6, 2, dark); o(-3, 1, 2, 2, dark); o(-2, -1, 4, 1, steel); break;
      case 'smg': o(-4, -1, 8, 2, dark); o(-2, 1, 2, 3, dark); o(1, 1, 1, 2, dark); o(-4, -1, 5, 1, steel); o(3, -1, 2, 1, hi); break;
      case 'shotgun': o(-6, -1, 12, 2, dark); o(-6, 1, 3, 2, '#5a3a20'); o(0, 1, 4, 1, '#5a3a20'); o(-1, -1, 7, 1, steel); break;
      case 'sniper': o(-7, 0, 14, 1, dark); o(-7, 1, 4, 2, dark); o(-2, -2, 5, 2, steel); o(-1, -2, 1, 1, '#3ef0ff'); o(5, 0, 2, 1, hi); break;
      case 'smart': o(-3, -1, 7, 2, '#1a2a30'); o(-3, 1, 2, 2, '#1a2a30'); o(-2, -1, 5, 1, '#3ef0ff'); o(3, -1, 1, 1, '#ffffff'); break;
      case 'katana': o(-7, 0, 3, 1, '#2a1a1a'); o(-4, -1, 1, 3, '#c9a227'); o(-3, 0, 10, 1, '#e8f6ff'); o(-3, 0, 10, 0.5, '#ffffff'); break;
    }
  };
  // Armes au sol (sous l'éclairage, comme le décor) ; celle qu'on peut ramasser clignote.
  AR.drawDrops = function (g, time) {
    const g0 = G(), near = g0.player ? AR.nearest(g0.player.x, g0.player.y) : null;
    for (const d of AR.dropsFor(M.id)) {
      g.fillStyle = 'rgba(0,0,0,0.35)'; g.fillRect(Math.round(d.x) - 5, Math.round(d.y) + 2, 11, 2);
      AR.icon(g, d.id, d.x, d.y, 1);
      if (d === near && Math.sin(time * 8) > 0) { g.fillStyle = '#ffd23e'; g.fillRect(Math.round(d.x), Math.round(d.y) - 6, 1, 2); }
    }
  };
  let rows = [];
  AR.rowUnderMouse = () => {
    const { mx, my } = C.input;
    return rows.findIndex(([x, y, w, h]) => mx >= x && mx < x + w && my >= y && my < y + h);
  };
  const T = (g, s, x, y, c, o = {}) => C.text(g, s, x, y, c, Object.assign({ shadow: '#05050a' }, o));
  AR.drawShop = function (g) {
    const gm = G(), s = gm.gunMenu, items = AR.shopItems(), p = gm.player;
    g.fillStyle = 'rgba(4,3,10,0.7)'; g.fillRect(0, 0, C.W, C.H);
    const w = 280, h = 160, x = Math.round((C.W - w) / 2), y = Math.round((C.H - h) / 2);
    g.fillStyle = '#0b0a16'; g.fillRect(x, y, w, h);
    g.fillStyle = '#ff7a1a'; g.fillRect(x, y, w, 1);
    g.fillStyle = '#2d3150'; g.fillRect(x, y + h - 1, w, 1); g.fillRect(x, y, 1, h); g.fillRect(x + w - 1, y, 1, h);
    T(g, gm.gunsmith.nom + ' · ARMURIER', x + 6, y + 6, '#d8dde6');
    T(g, gm.leader.eddies + ' €$', x + w - 6, y + 6, '#ffd23e', { align: 'right' });
    T(g, 'EN MAIN : ' + W[p.weapon].name + ' · ' + W[p.melee].name, x + 6, y + 15, '#8f98a0');
    rows = [];
    items.forEach((id, i) => {
      const it = W[id], ry = y + 27 + i * 18, sel = i === s.sel, mine = it.kind === 'melee' ? p.melee === id : p.weapon === id;
      rows.push([x + 3, ry - 2, w - 6, 17]);
      g.fillStyle = sel ? 'rgba(255,122,26,0.16)' : 'rgba(255,255,255,0.03)'; g.fillRect(x + 3, ry - 2, w - 6, 17);
      AR.icon(g, id, x + 24, ry + 6, 2);
      T(g, it.name, x + 52, ry, '#ffffff');
      const stats = it.kind === 'gun' ? 'DÉGÂTS ' + it.dmg * (it.pellets || 1) + ' · CHARGEUR ' + it.mag + ' · CADENCE ' + Math.round(60 / (it.rate * 60) * 10) / 10 + '/S' : 'DÉGÂTS ' + it.dmg + ' · ALLONGE ' + it.range + ' · PARADE';
      T(g, stats, x + 52, ry + 8, '#8f98a0');
      T(g, mine ? (it.kind === 'gun' ? 'RECHARGER' : 'EN MAIN') : it.prix + ' €$', x + w - 8, ry, mine ? '#5dff9a' : gm.leader.eddies >= it.prix ? '#ffd23e' : '#6f7c8a', { align: 'right' });
    });
    if (s.msgT > 0) T(g, s.msg, C.W / 2, y + h - 20, s.msgCol, { align: 'center' });
    T(g, '[HAUT/BAS] CHOISIR   [E] ACHETER   [ÉCHAP] SORTIR', C.W / 2, y + h - 10, '#6f7c8a', { align: 'center' });
    const mx = Math.round(C.input.mx), my = Math.round(C.input.my);
    g.fillStyle = '#05050a'; g.fillRect(mx - 1, my - 1, 3, 3);
    g.fillStyle = '#ffffff'; g.fillRect(mx, my, 1, 1);
  };
})();
