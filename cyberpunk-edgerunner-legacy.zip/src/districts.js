'use strict';
// Les quartiers de Night City reliés par le métro NCART, et leurs bâtiments.
//
// Un quartier est une carte de rue (outdoor) avec :
//   quartier        nom court affiché sur le plan du métro
//   H, V            bandes de chaussée [début, fin] en tuiles (sert aussi aux passages piétons et aux voitures garées)
//   roof, road      style des toits ('watson' | 'jp' | 'glass' | 'ruin') et des chaussées ('watson' | 'clean' | 'ruin')
//   dark            opacité du voile de nuit (plus bas = plus éclairé)
//   pedTiles        tuiles où flânent les passants ; pedCols couleurs de leurs vestes
//   props           décor posé sur la carte : {k, x, y, ...} (dessin et cases occupées : decor.js)
//   une porte {id: 'metro', metro: true} : la bouche de métro
// Un bâtiment (site) indique son quartier dans district.
//
// Tuiles en plus de maps.js : 'k' pavés, 'q' dalles de place, 'g' herbe, 'z' sable, 'w' eau (bloque).
(function () {
  const C = CEL, MAPS = C.MAPS;

  // Ordre des stations sur la ligne NCART (un seul tracé, du nord au sud-ouest).
  C.LINE = ['rue', 'japantown', 'centre', 'pacifica'];
  // Position de chaque station sur le plan du métro (0..1).
  C.STATIONS = {
    rue: { x: 0.42, y: 0.16, sub: 'KABUKI' },
    japantown: { x: 0.74, y: 0.42, sub: 'WESTBROOK' },
    centre: { x: 0.44, y: 0.56, sub: 'CORPO PLAZA' },
    pacifica: { x: 0.18, y: 0.84, sub: 'COASTVIEW' },
  };
  // Quartier d'un lieu : la planque et les bâtiments de Watson sont dans 'rue'.
  C.districtOf = id => {
    const d = MAPS[id];
    if (!d || id === 'planque') return 'rue';
    return d.outdoor ? id : d.district || 'rue';
  };

  // Bruit déterministe (le même que le rendu) pour des détails stables.
  const hash = (x, y, i = 0) => { let h = (x * 374761393 + y * 668265263 + i * 2147483647) | 0; h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; };

  // Chaussées, trottoirs et marquages à partir des bandes H et V.
  function roads(carve, put, H, V, w, h) {
    for (const [a, b] of H) carve(0, a - 2, w - 1, b + 2, 's');
    for (const [a, b] of V) carve(a - 2, 0, b + 2, h - 1, 's');
    for (const [a, b] of H) carve(0, a, w - 1, b, 'r');
    for (const [a, b] of V) carve(a, 0, b, h - 1, 'r');
    const inV = x => V.some(([a, b]) => x >= a && x <= b), inH = y => H.some(([a, b]) => y >= a && y <= b);
    for (const [a, b] of H) { const y = (a + b) / 2; for (let x = 0; x < w; x++) if (!inV(x) && x % 4 < 2) put(x, y, '='); }
    for (const [a, b] of V) { const x = (a + b) / 2; for (let y = 0; y < h; y++) if (!inH(y) && y % 4 < 2) put(x, y, '='); }
  }
  // Lampadaires sur le bord extérieur des trottoirs, hors carrefours.
  function lamps(H, V, w, h, step, c, skip) {
    const L = [], nearV = x => V.some(([a, b]) => x >= a - 4 && x <= b + 4), nearH = y => H.some(([a, b]) => y >= a - 4 && y <= b + 4);
    for (const [a, b] of H) for (const y of [a - 2, b + 2]) for (let x = 4; x < w - 2; x += step) if (!nearV(x) && !(skip && skip(x, y))) L.push({ x, y, c, r: 44 });
    for (const [a, b] of V) for (const x of [a - 2, b + 2]) for (let y = 4; y < h - 2; y += step) if (!nearH(y) && !(skip && skip(x, y))) L.push({ x, y, c, r: 44 });
    return L;
  }
  const ellipse = (carve, cx, cy, rx, ry, ch) => {
    for (let y = -ry; y <= ry; y++) for (let x = -rx; x <= rx; x++) if ((x * x) / (rx * rx + 0.5) + (y * y) / (ry * ry + 0.5) <= 1) carve(cx + x, cy + y, cx + x, cy + y, ch);
  };
  const METRO = '#ffb000';

  // ---------- Watson : la rue de maps.js reçoit sa bouche de métro et un peu de mobilier urbain ----------
  Object.assign(MAPS.rue, {
    nom: 'KABUKI · WATSON', quartier: 'WATSON',
    H: [[12, 16], [34, 38]], V: [[20, 24], [50, 54], [78, 82]],
    roof: 'watson', road: 'watson', pedTiles: ['s'],
    props: [
      { k: 'vending', x: 30, y: 10 }, { k: 'vending', x: 31, y: 10 }, { k: 'vending', x: 86, y: 32 },
      { k: 'junk', x: 46, y: 32 }, { k: 'junk', x: 47, y: 32 }, { k: 'junk', x: 4, y: 40 },
      { k: 'barrel', x: 72, y: 40 }, { k: 'holo', x: 58, y: 6, c: '#ff3ec8' }, { k: 'holo', x: 32, y: 46, c: '#3ef0ff' },
    ],
  });
  MAPS.rue.doors.push({ id: 'metro', metro: true, x: 44, y: 41, sx: 44, sy: 40, label: 'MÉTRO', color: METRO });
  MAPS.rue.lights.push({ x: 44, y: 40, c: METRO, r: 50 }, { x: 72, y: 40, c: '#ff7a1a', r: 40 });
  for (const id of ['entrepot', 'club', 'labo']) MAPS[id].district = 'rue';

  // ---------- Japantown : rue commerçante piétonne, lanternes, toris, parc aux cerisiers ----------
  {
    const H = [[10, 14], [38, 42]], V = [[16, 20], [62, 66]], w = 84, h = 54;
    const stalls = [[26, 24], [30, 24], [34, 24], [44, 24], [52, 24], [56, 24], [27, 28], [31, 28], [45, 28], [49, 28], [54, 28]];
    const lanterns = [25, 31, 37, 43, 51, 57];
    MAPS.japantown = {
      nom: 'JAPANTOWN · WESTBROOK', quartier: 'JAPANTOWN', w, h, outdoor: true, H, V,
      roof: 'jp', road: 'watson', dark: 0.7, traffic: 6, signWords: ['RAMEN', 'SAKE', 'KARAOKE', 'SUSHI', 'TYGER', 'NOODLES', 'YAKITORI', 'HOTEL'], peds: 24, pedTiles: ['s', 'k', 'g'],
      pedCols: ['#c4142b', '#1a1a22', '#f2f2f2', '#ff9ad8', '#3a3a5c', '#c9a227', '#7a1a2a'],
      palette: { floor: '#262634', seam: '#1e1e2a', speck: ['#2c2c3c', '#202030'], carpet: '#262634', carpetDot: '#262634' },
      build(carve, put) {
        roads(carve, put, H, V, w, h);
        carve(38, 17, 42, 35, 'k');        // passage entre les deux avenues
        carve(23, 24, 59, 28, 'k');        // la rue commerçante
        carve(69, 18, 83, 34, 'g');        // parc
        ellipse(carve, 77, 26, 3, 2, 'w'); // étang
        carve(72, 45, 80, 51, 'k');        // cour du sanctuaire
      },
      doors: [
        { id: 'metro', metro: true, x: 30, y: 7, sx: 30, sy: 8, label: 'MÉTRO', color: METRO },
        { id: 'pachinko', x: 48, y: 23, sx: 48, sy: 24, to: 'pachinko', toDoor: 'sortie', label: 'PACHINKO', color: '#ff3e7a' },
      ],
      lights: [
        ...lamps(H, V, w, h, 12, '#ffb8c8'),
        ...lanterns.map(x => ({ x, y: 26, c: '#ff2040', r: 34 })),
        { x: 30, y: 8, c: METRO, r: 50 }, { x: 48, y: 24, c: '#ff3e7a', r: 60 }, { x: 76, y: 47, c: '#ff7a3a', r: 46 },
        { x: 74, y: 22, c: '#ff9ad8', r: 40 }, { x: 78, y: 31, c: '#ff9ad8', r: 40 },
      ],
      props: [
        ...stalls.map(([x, y], i) => ({ k: 'stall', x, y, c: ['#c4142b', '#ff9ad8', '#f2d43a', '#3fd0b0'][i % 4] })),
        ...lanterns.map(x => ({ k: 'lantern', x, y: 26 })),
        { k: 'torii', x: 23, y: 24, len: 5, dir: 'v' }, { k: 'torii', x: 59, y: 24, len: 5, dir: 'v' },
        { k: 'torii', x: 74, y: 45, len: 5, dir: 'h' },
        { k: 'shrine', x: 75, y: 49 },
        { k: 'sakura', x: 71, y: 20 }, { k: 'sakura', x: 75, y: 19 }, { k: 'sakura', x: 81, y: 20 }, { k: 'sakura', x: 71, y: 29 },
        { k: 'sakura', x: 74, y: 32 }, { k: 'sakura', x: 81, y: 31 }, { k: 'sakura', x: 82, y: 25 },
        { k: 'vending', x: 26, y: 16 }, { k: 'vending', x: 50, y: 16 }, { k: 'vending', x: 51, y: 16 },
        { k: 'holo', x: 56, y: 32, c: '#ff3e7a' }, { k: 'holo', x: 8, y: 26, c: '#3fd0b0' },
      ],
      enemies: [],
    };
    MAPS.japantown.parked = C.cars.parkAlong(H, V, w, h, 8);
  }

  // ---------- City Center : place corpo, fontaine, hologrammes, tours de verre ----------
  {
    const H = [[8, 12], [40, 44]], V = [[14, 18], [66, 70]], w = 84, h = 54;
    MAPS.centre = {
      nom: 'CORPO PLAZA · CITY CENTER', quartier: 'CITY CENTER', w, h, outdoor: true, H, V,
      roof: 'glass', road: 'clean', dark: 0.6, traffic: 12, signWords: ['KIROSHI', 'ZETATECH', 'BANK', 'NETWATCH', 'LUXE', 'BIOTECH', 'CAFE', 'MEDIA'], peds: 26, pedTiles: ['s', 'q', 'g'],
      pedCols: ['#3a3a4a', '#1a1a22', '#e8e8f0', '#4a5a7a', '#5a5a6a', '#2a3a5a', '#7a7a8a'],
      palette: { floor: '#2a2c3a', seam: '#232532', speck: ['#30324a', '#26283a'], carpet: '#2a2c3a', carpetDot: '#2a2c3a' },
      build(carve, put) {
        roads(carve, put, H, V, w, h);
        carve(21, 21, 63, 37, 'q');        // la place, au pied de la tour
        ellipse(carve, 42, 30, 3, 2, 'w'); // fontaine
        carve(22, 47, 62, 53, 'g');        // jardin suspendu
      },
      doors: [
        { id: 'metro', metro: true, x: 11, y: 30, sx: 12, sy: 30, label: 'MÉTRO', color: METRO },
        { id: 'tour', x: 42, y: 20, sx: 42, sy: 21, to: 'tour', toDoor: 'sortie', label: 'TOUR KIROSHI', color: '#3ef0ff' },
      ],
      lights: [
        ...lamps(H, V, w, h, 10, '#bfe9ff'),
        { x: 12, y: 30, c: METRO, r: 50 }, { x: 42, y: 22, c: '#3ef0ff', r: 80 }, { x: 42, y: 30, c: '#7ff6ff', r: 50 },
        { x: 30, y: 28, c: '#3ef0ff', r: 50 }, { x: 54, y: 28, c: '#ff3ec8', r: 50 }, { x: 26, y: 35, c: '#bfe9ff', r: 40 }, { x: 58, y: 35, c: '#bfe9ff', r: 40 },
        { x: 32, y: 50, c: '#5dff9a', r: 40 }, { x: 52, y: 50, c: '#5dff9a', r: 40 },
      ],
      props: [
        { k: 'fountain', x: 42, y: 30 },
        { k: 'holo', x: 30, y: 28, c: '#3ef0ff', solid: true }, { k: 'holo', x: 54, y: 28, c: '#ff3ec8', solid: true },
        { k: 'planter', x: 23, y: 23 }, { k: 'planter', x: 61, y: 23 }, { k: 'planter', x: 23, y: 35 }, { k: 'planter', x: 61, y: 35 },
        { k: 'tree', x: 27, y: 24 }, { k: 'tree', x: 57, y: 24 }, { k: 'tree', x: 27, y: 34 }, { k: 'tree', x: 57, y: 34 },
        { k: 'bench', x: 34, y: 36 }, { k: 'bench', x: 49, y: 36 }, { k: 'bench', x: 35, y: 23 }, { k: 'bench', x: 48, y: 23 },
        { k: 'tree', x: 26, y: 50 }, { k: 'tree', x: 34, y: 51 }, { k: 'tree', x: 42, y: 50 }, { k: 'tree', x: 50, y: 51 }, { k: 'tree', x: 58, y: 50 },
        { k: 'vending', x: 20, y: 22 }, { k: 'holo', x: 76, y: 24, c: '#f2d43a' }, { k: 'holo', x: 6, y: 48, c: '#3ef0ff' },
      ],
      enemies: [],
    };
    MAPS.centre.parked = C.cars.parkAlong(H, V, w, h, 7);
  }

  // ---------- Pacifica : quartier abandonné, sable, palmiers, épaves, feux de bidons, l'océan ----------
  {
    const H = [[10, 14], [30, 34]], V = [[20, 24], [56, 60]], w = 84, h = 54;
    const shore = x => 45 + Math.round(Math.sin(x * 0.35) + Math.sin(x * 0.11) * 1.5);
    const barrels = [[12, 16], [44, 16], [30, 38], [64, 40], [48, 28], [74, 36]];
    MAPS.pacifica = {
      nom: 'COASTVIEW · PACIFICA', quartier: 'PACIFICA', w, h, outdoor: true, H, V,
      roof: 'ruin', road: 'ruin', dark: 0.8, traffic: 3, signWords: ['MOTEL', 'BAR', 'VOODOO', 'LIQUOR', 'DINER', 'SURF', 'CASINO'], peds: 9, pedTiles: ['s', 'z'], wrecks: true,
      pedCols: ['#3a5a3a', '#5a3a2a', '#2a2a2a', '#6a5a3a', '#3a3a5a'],
      palette: { floor: '#2a2824', seam: '#22201c', speck: ['#302d28', '#24221e'], carpet: '#2a2824', carpetDot: '#2a2824' },
      build(carve, put, g) {
        roads(carve, put, H, V, w, h);
        // le sable gagne les trottoirs
        for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (g[y][x] === 's' && hash(x, y, 50) < 0.05) put(x, y, 'z');
        // plage puis océan, avec un rivage irrégulier
        for (let x = 0; x < w; x++) {
          const s = shore(x);
          carve(x, 37, x, s - 1, 'z');
          carve(x, s, x, h - 1, 'w');
        }
        carve(64, 17, 75, 27, 'z');   // terrain vague
      },
      doors: [
        { id: 'metro', metro: true, x: 8, y: 7, sx: 8, sy: 8, label: 'MÉTRO', color: METRO },
        { id: 'hotel', x: 40, y: 27, sx: 40, sy: 28, to: 'hotel', toDoor: 'sortie', label: 'GRAND IMPERIAL', color: '#ff7a3a' },
      ],
      lights: [
        ...lamps(H, V, w, h, 22, '#ffcf8a'),
        ...barrels.map(([x, y]) => ({ x, y, c: '#ff7a1a', r: 46 })),
        { x: 8, y: 8, c: METRO, r: 50 }, { x: 40, y: 28, c: '#ff7a3a', r: 50 },
      ],
      props: [
        ...barrels.map(([x, y]) => ({ k: 'barrel', x, y })),
        ...[4, 11, 18, 27, 35, 46, 53, 62, 70, 78].map((x, i) => ({ k: 'palm', x, y: 38 + (i % 2) * 2 })),
        { k: 'palm', x: 66, y: 19 }, { k: 'palm', x: 73, y: 25 }, { k: 'palm', x: 26, y: 8 },
        { k: 'bus', x: 34, y: 11, dir: 'h' }, { k: 'bus', x: 57, y: 20, dir: 'v' },
        { k: 'tent', x: 43, y: 40 }, { k: 'tent', x: 67, y: 41 }, { k: 'tent', x: 69, y: 22 },
        { k: 'junk', x: 50, y: 39 }, { k: 'junk', x: 16, y: 42 }, { k: 'junk', x: 70, y: 18 }, { k: 'junk', x: 33, y: 28 },
        { k: 'holo', x: 46, y: 22, c: '#7a5cff', broken: true },
      ],
      enemies: [],
    };
    MAPS.pacifica.parked = C.cars.parkAlong(H, V, w, h, 9, (x, y) => y > 33 || (x >= 32 && x <= 40 && y <= 14) || (y >= 18 && y <= 26 && x >= 55));
  }

  // ---------- les bâtiments des nouveaux quartiers ----------
  // Salle de pachinko (Japantown) : rangées de machines, karaoké, bureau du gérant, réserve.
  MAPS.pachinko = {
    nom: 'SALON PACHINKO', w: 50, h: 30, site: true, district: 'japantown', furniture: 'pachinko',
    palette: { floor: '#1c1218', seam: '#160e13', speck: ['#24161e', '#180f14'], carpet: '#3a1020', carpetDot: '#5a1a30', wall: '#3a1a2a', wallHi: '#8a3a5a', wallFace: '#24101a' },
    build(carve, put) {
      carve(1, 20, 10, 28);    // entrée
      carve(12, 2, 37, 18);    // la grande salle
      carve(12, 22, 37, 28);   // karaoké
      carve(40, 2, 48, 12);    // bureau du gérant
      carve(40, 15, 48, 28);   // réserve à jetons
      carve(11, 24, 11, 25); carve(20, 19, 21, 21); carve(30, 19, 31, 21); carve(38, 6, 39, 7); carve(38, 24, 39, 25); carve(44, 13, 45, 14);
      carve(41, 3, 47, 11, ',');
      for (const y of [4, 8, 12, 16]) for (let x = 15; x <= 34; x++) if (x < 23 || x > 26) put(x, y, 'c');
      for (const [x, y] of [[15, 24], [16, 24], [25, 27], [26, 27], [33, 24], [34, 24], [42, 5], [43, 5], [46, 19], [46, 20], [42, 26], [43, 26], [3, 22]]) put(x, y, 'c');
    },
    doors: [{ id: 'sortie', x: 5, y: 29, sx: 5, sy: 28, to: 'japantown', toDoor: 'pachinko', label: 'SORTIE', color: '#ff3e7a' }],
    lights: [
      { x: 18, y: 6, c: '#ff3e7a', r: 80 }, { x: 31, y: 6, c: '#f2d43a', r: 80 }, { x: 18, y: 14, c: '#3ef0ff', r: 80 }, { x: 31, y: 14, c: '#ff3e7a', r: 80 },
      { x: 5, y: 22, c: '#ff2040', r: 60 }, { x: 24, y: 25, c: '#7a5cff', r: 70 }, { x: 44, y: 6, c: '#f2d43a', r: 60 }, { x: 44, y: 24, c: '#ff3e7a', r: 60 },
    ],
    enemies: [
      ['thug', 24, 6, { patrol: [[24, 3], [24, 17]] }], ['thug', 18, 10], ['thug', 30, 14], ['brute', 34, 6], ['thug', 14, 17],
      ['thug', 20, 25, { patrol: [[14, 25], [36, 25]] }], ['thug', 46, 9], ['brute', 44, 22], ['thug', 41, 27], ['thug', 7, 25],
    ],
    cams: [[12, 2], [37, 2], [37, 28]], turrets: [[41, 11]],   // sécurité (netrun.js)
    term: [47, 3], cadre: [45, 8], psycho: [24, 12],
  };

  // Tour Kiroshi (City Center) : hall, open space, réunion, bureaux, bureau du PDG, serveurs, cafétéria.
  MAPS.tour = {
    nom: 'TOUR KIROSHI', w: 52, h: 32, site: true, district: 'centre', furniture: 'office',
    palette: { floor: '#20242c', seam: '#282d37', speck: ['#252a33', '#1c2027'], carpet: '#2a2040', carpetDot: '#382a54', wall: '#3a4250', wallHi: '#9aa8c0', wallFace: '#262c36' },
    build(carve, put) {
      carve(18, 24, 34, 30);   // hall
      carve(1, 14, 50, 22);    // open space
      carve(1, 1, 16, 12);     // réunion
      carve(18, 1, 34, 12);    // bureaux
      carve(36, 1, 50, 12);    // PDG
      carve(1, 24, 16, 30);    // serveurs
      carve(36, 24, 50, 30);   // cafétéria
      carve(25, 23, 27, 23); carve(8, 13, 9, 13); carve(26, 13, 27, 13); carve(43, 13, 44, 13); carve(8, 23, 9, 23); carve(43, 23, 44, 23);
      carve(17, 27, 17, 28); carve(35, 27, 35, 28);
      carve(37, 2, 49, 11, ',');
      for (const x of [4, 12, 18, 30, 36, 46]) for (const y of [16, 20]) { put(x, y, 'c'); put(x + 1, y, 'c'); }
      for (let x = 5; x <= 12; x++) for (let y = 5; y <= 7; y++) put(x, y, 'c');   // table de réunion
      for (const [x, y] of [[21, 4], [22, 4], [29, 4], [30, 4], [21, 9], [22, 9], [29, 9], [30, 9], [41, 5], [42, 5], [43, 5], [21, 26], [22, 26], [23, 26],
        [39, 26], [40, 26], [46, 26], [47, 26], [39, 29], [40, 29], [46, 29], [47, 29]]) put(x, y, 'c');
      for (const x of [4, 8, 12]) for (let y = 25; y <= 29; y++) put(x, y, 'c');   // baies
    },
    doors: [{ id: 'sortie', x: 26, y: 31, sx: 26, sy: 30, to: 'centre', toDoor: 'tour', label: 'SORTIE', color: '#3ef0ff' }],
    lights: [
      { x: 26, y: 27, c: '#bfe9ff', r: 80 }, { x: 10, y: 18, c: '#bfe9ff', r: 80 }, { x: 26, y: 18, c: '#bfe9ff', r: 80 }, { x: 42, y: 18, c: '#bfe9ff', r: 80 },
      { x: 8, y: 6, c: '#3ef0ff', r: 60 }, { x: 26, y: 6, c: '#bfe9ff', r: 60 }, { x: 43, y: 6, c: '#ffd23e', r: 70 }, { x: 8, y: 27, c: '#5dff9a', r: 50 }, { x: 43, y: 27, c: '#ff3ec8', r: 50 },
    ],
    enemies: [
      ['thug', 26, 18, { patrol: [[6, 18], [46, 18]] }], ['thug', 14, 15], ['thug', 40, 21], ['brute', 26, 6], ['thug', 10, 10],
      ['thug', 45, 9], ['brute', 10, 27], ['thug', 44, 28], ['thug', 30, 27], ['thug', 20, 15],
    ],
    cams: [[1, 14], [50, 14], [18, 24], [34, 1], [16, 30]], turrets: [[36, 11], [1, 24]],   // sécurité (netrun.js)
    term: [48, 3], cadre: [45, 9], psycho: [26, 18],
  };

  // Grand Imperial (Pacifica) : hôtel en ruine, chambres éventrées, piscine vide, cuisines.
  MAPS.hotel = {
    nom: 'GRAND IMPERIAL', w: 52, h: 32, site: true, district: 'pacifica', furniture: 'ruin',
    palette: { floor: '#221d1a', seam: '#1a1613', speck: ['#2a231f', '#1c1815'], carpet: '#16303a', carpetDot: '#1f4250', wall: '#3a332c', wallHi: '#7a6a58', wallFace: '#241f1a' },
    build(carve, put) {
      carve(1, 1, 12, 8);      // hall
      carve(1, 10, 50, 12);    // couloir
      carve(14, 1, 22, 8); carve(24, 1, 32, 8); carve(34, 1, 42, 8); carve(44, 1, 50, 8);   // chambres
      carve(1, 14, 16, 30);    // salle de bal
      carve(18, 14, 34, 30);   // piscine
      carve(36, 14, 50, 30);   // cuisines
      carve(5, 9, 6, 9); carve(18, 9, 18, 9); carve(28, 9, 28, 9); carve(38, 9, 38, 9); carve(47, 9, 47, 9);
      carve(8, 13, 9, 13); carve(25, 13, 26, 13); carve(43, 13, 44, 13);
      carve(13, 4, 13, 5); carve(33, 5, 33, 6); carve(17, 20, 17, 22); carve(35, 24, 35, 25);   // murs défoncés
      carve(21, 17, 31, 27, ',');   // le bassin vide
      for (const [x, y] of [[16, 3], [17, 3], [26, 3], [27, 3], [36, 3], [37, 3], [47, 6], [48, 6], [4, 18], [5, 18], [10, 24], [11, 25], [6, 28], [13, 16],
        [20, 28], [32, 16], [24, 22], [28, 22], [3, 6]]) put(x, y, 'c');
      for (let x = 38; x <= 42; x++) put(x, 17, 'c');
      for (let x = 44; x <= 48; x++) put(x, 22, 'c');
      for (let x = 38; x <= 41; x++) put(x, 27, 'c');
    },
    doors: [{ id: 'sortie', x: 6, y: 0, sx: 6, sy: 1, to: 'pacifica', toDoor: 'hotel', label: 'SORTIE', color: '#ff7a3a' }],
    lights: [
      { x: 6, y: 3, c: '#ff7a3a', r: 60 }, { x: 20, y: 11, c: '#ffcf8a', r: 50 }, { x: 40, y: 11, c: '#ffcf8a', r: 50 },
      { x: 8, y: 22, c: '#ff7a1a', r: 70 }, { x: 26, y: 22, c: '#3ef0ff', r: 80 }, { x: 43, y: 22, c: '#ffcf8a', r: 70 }, { x: 47, y: 4, c: '#7a5cff', r: 50 },
    ],
    enemies: [
      ['thug', 25, 11, { patrol: [[10, 11], [46, 11]] }], ['thug', 19, 5], ['thug', 30, 4], ['brute', 39, 5], ['thug', 47, 3],
      ['thug', 8, 20], ['brute', 12, 27], ['thug', 26, 20], ['thug', 40, 20], ['thug', 46, 28],
    ],
    cams: [[1, 10], [50, 14]], turrets: [[50, 30]],   // sécurité (netrun.js)
    term: [48, 28], cadre: [46, 25], psycho: [8, 22],
  };
})();
