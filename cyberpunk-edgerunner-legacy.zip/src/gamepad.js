'use strict';
// Manette (API Gamepad, disposition « standard » : DualSense, DualShock, Xbox…). Le jeu se joue sans clavier ni souris.
// La manette « appuie » sur les mêmes touches que le clavier (CEL.input) : aucune règle du jeu n'est dupliquée.
//   Stick gauche : se déplacer · stick droit : viser (game.js lit CEL.pad)
//   R2 : tirer · R1 : mêlée · L1 : dash · L2 (maintenu) : scanner · L3 : Sandevistan
//   ✕ : interagir / valider · ○ : retour · □ : recharger (au volant : radio suivante) · △ : injecteur
//   R3 : épargner un ennemi à terre / ordre au compagnon · croix : menus · pavé tactile : compétences
// (Create / Share est laissé libre : dans NOVA, il sert aux captures d'écran.)
(function () {
  const C = CEL, I = C.input;
  const PAD = (C.pad = { active: false, mx: 0, my: 0, ax: 0, ay: 0, aiming: false, aimA: undefined });

  // bouton -> touches du clavier (ou bouton de souris : 'mouse0' = clic gauche, 'mouse2' = clic droit)
  const MAP = {
    0: ['KeyE', 'Enter'],     // ✕
    1: ['Escape'],            // ○
    2: ['KeyR'],              // □
    3: ['KeyF'],              // △
    4: ['Space'],             // L1
    5: ['mouse2'],            // R1
    6: ['Tab'],               // L2
    7: ['mouse0'],            // R2
    9: ['Escape'],            // Options
    10: ['ShiftLeft'],        // L3
    11: ['KeyC', 'KeyG'],     // R3
    12: ['ArrowUp'], 13: ['ArrowDown'], 14: ['ArrowLeft'], 15: ['ArrowRight'],
    17: ['KeyK'],             // pavé tactile
  };
  const DEAD = 0.2;
  const dead = (v) => (Math.abs(v) < DEAD ? 0 : (v - Math.sign(v) * DEAD) / (1 - DEAD));
  const held = new Set();   // touches actuellement tenues par la manette

  function press(code) {
    if (code.startsWith('mouse')) { const b = +code.slice(5); I.mb[b] = true; I.mhit[b] = true; return; }
    if (!I.down.has(code)) I.hit.add(code);
    I.down.add(code);
  }
  function release(code) {
    if (code.startsWith('mouse')) { I.mb[+code.slice(5)] = false; return; }
    I.down.delete(code);
  }

  function frame() {
    requestAnimationFrame(frame);
    const pad = [...(navigator.getGamepads ? navigator.getGamepads() : [])].find((p) => p && p.connected);
    const want = new Set();
    if (pad) {
      pad.buttons.forEach((b, i) => { if (b && b.pressed && MAP[i]) MAP[i].forEach((c) => want.add(c)); });
      const lx = dead(pad.axes[0] || 0), ly = dead(pad.axes[1] || 0);
      const rx = dead(pad.axes[2] || 0), ry = dead(pad.axes[3] || 0);
      // le stick gauche fait aussi ZQSD : menus, conduite
      if (ly < -0.5) want.add('KeyW'); if (ly > 0.5) want.add('KeyS');
      if (lx < -0.5) want.add('KeyA'); if (lx > 0.5) want.add('KeyD');
      PAD.mx = lx; PAD.my = ly;
      const r = Math.hypot(rx, ry);
      PAD.aiming = r > 0.35;
      if (PAD.aiming) { PAD.ax = rx / r; PAD.ay = ry / r; }
      if (want.size || lx || ly || rx || ry) PAD.active = true;
    } else {
      PAD.mx = PAD.my = 0; PAD.aiming = false;
    }
    for (const c of want) if (!held.has(c)) { press(c); held.add(c); }
    for (const c of [...held]) if (!want.has(c)) { release(c); held.delete(c); }
  }

  // la souris reprend la main dès qu'elle bouge
  addEventListener('mousemove', () => { PAD.active = false; PAD.aimA = undefined; }, { passive: true });
  requestAnimationFrame(frame);
})();
