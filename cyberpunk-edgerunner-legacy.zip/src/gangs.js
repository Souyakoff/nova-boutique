'use strict';
// Gangs : chaque quartier a le sien, en bandes dans la rue.
//
//   Maelstrom (Watson)        chromés, lents, costauds, fusil à pompe : ils foncent au contact
//   Tyger Claws (Japantown)   rapides : SMG, ou katana avec des dashs
//   Valentinos (City Center)  pistolets et SMG, ils tournent autour de toi
//   Voodoo Boys (Pacifica)    netrunners : pistolet smart, et ils te piratent (brouillage, surchauffe, court-circuit)
//
// Réputation par gang, gardée par la ville (les gangs se souviennent des leaders précédents) : de -100 à 100.
// Au-dessus du seuil hostile, ils te laissent passer ; tirer près d'eux, les blesser ou les tuer la fait baisser.
// Abattre un gang rival fait plaisir aux autres. Elle remonte un peu à chaque gig.
(function () {
  const C = CEL, D = C.DEF, M = C.map, GR = D.gangRep, VH = D.voodooHack;
  const GA = (C.gangs = {});
  const G = () => C.game;
  const city = () => C.legacy.city;

  GA.rep = id => { const r = city().rep || (city().rep = {}); return r[id] == null ? 0 : r[id]; };
  GA.hostile = id => GA.rep(id) <= GR.hostile;
  function addRep(id, n) {
    const r = city().rep || (city().rep = {});
    const before = GA.hostile(id);
    r[id] = Math.max(-100, Math.min(100, GA.rep(id) + n));
    C.legacy.save();
    if (!before && GA.hostile(id)) {
      // ils te déclarent la guerre : toute la bande du quartier se réveille
      const g = G();
      for (const e of g.enemies) if (e.gang === id) e.neutral = false;
      g.gangMsg = { text: D.gangs[id].nom + ' : TU ES SUR LEUR LISTE', col: D.gangs[id].color, t: 3 };
      C.sfx('wanted');
      C.home.note('war', id);
      C.music.event('gang', { gang: D.gangs[id].nom });
    }
  }
  GA.addRep = addRep;
  // Entre deux gigs, la rancune s'apaise un peu.
  GA.cool = () => { for (const id of Object.keys(D.gangs)) if (GA.rep(id) < 0) city().rep[id] = Math.min(0, GA.rep(id) + GR.recover); C.legacy.save(); };

  // ---------- dans la rue ----------
  GA.gangOf = mapId => Object.keys(D.gangs).find(id => D.gangs[id].district === mapId) || null;
  const GROUND = new Set(['s', 'k', 'q', 'z', 'g']);
  GA.spawn = function () {
    const g = G(), def = M.def, id = GA.gangOf(M.id);
    if (!id || !def.outdoor) return;
    const gang = D.gangs[id], p = g.player, hostile = GA.hostile(id);
    const nearDoor = (x, y) => def.doors.some(d => Math.abs(d.sx - x) < 5 && Math.abs(d.sy - y) < 5);
    for (let k = 0; k < gang.groups; k++) {
      for (let t = 0; t < 80; t++) {
        const tx = (Math.random() * M.MW) | 0, ty = (Math.random() * M.MH) | 0;
        if (!GROUND.has(M.tile(tx, ty)) || M.blocked(tx, ty) || nearDoor(tx, ty)) continue;
        if (C.dist(tx * 8, ty * 8, p.x, p.y) < 140) continue;
        if (g.enemies.some(e => e.gang && C.dist(e.x, e.y, tx * 8, ty * 8) < 90)) continue;
        // une bande : 2 ou 3 membres serrés ; l'un d'eux fait les cent pas sur le trottoir
        const n = 2 + (Math.random() < 0.5 ? 1 : 0);
        for (let i = 0; i < n; i++) {
          const ox = tx + (i % 2) * 2 - 1, oy = ty + ((i / 2) | 0) * 2;
          if (M.solid(ox, oy)) continue;
          const type = gang.types[(Math.random() * gang.types.length) | 0];
          let patrol = null;
          if (i === 0) for (const [dx, dy] of [[8, 0], [-8, 0], [0, 8], [0, -8]]) if (GROUND.has(M.tile(ox + dx, oy + dy)) && M.los(ox * 8 + 4, oy * 8 + 4, (ox + dx) * 8 + 4, (oy + dy) * 8 + 4)) { patrol = [[ox, oy], [ox + dx, oy + dy]]; break; }
          const e = g.fx.makeEnemy(type, ox, oy, patrol ? { patrol } : {}, -1);
          e.gang = id; e.neutral = !hostile;
          e.aim = Math.random() * 6.28;
          g.enemies.push(e);
        }
        break;
      }
    }
  };
  // Un ganger blessé ou tué : sa bande riposte, son gang s'en souvient, les rivaux apprécient.
  GA.onHurt = function (e, killed) {
    if (!e.gang) return;
    const g = G();
    for (const o of g.enemies) if (o.gang === e.gang && g.ALIVE(o) && C.dist(o.x, o.y, e.x, e.y) < 160) { o.neutral = false; g.fx.alertEnemy(o, false); }
    // une seule pénalité par ganger blessé, une par mort (un tir de pompe = 7 plombs)
    if (killed && !e.repKilled) { e.repKilled = true; C.home.note('gangKill', e.gang); addRep(e.gang, GR.kill - (e.repHurt ? GR.hurt : 0)); for (const id of Object.keys(D.gangs)) if (id !== e.gang) addRep(id, GR.rival); }
    else if (!killed && !e.repHurt) { e.repHurt = true; addRep(e.gang, GR.hurt); }
  };
  // Des coups de feu à côté d'une bande neutre : elle n'aime pas ça.
  GA.shotsNear = function (x, y) {
    const g = G(), seen = new Set();
    for (const e of g.enemies) {
      if (!e.gang || !e.neutral || !g.ALIVE(e) || C.dist(e.x, e.y, x, y) > 90) continue;
      e.neutral = false; g.fx.alertEnemy(e, true);
      if (!seen.has(e.gang)) { seen.add(e.gang); addRep(e.gang, GR.shotsNear); }
    }
  };

  // ---------- piratages des Voodoo Boys ----------
  // Un Voodoo Boy qui te voit lance un piratage (barre au-dessus de toi) ; le mettre à terre, l'aveugler ou le sonner l'annule.
  GA.update = function (dt) {
    const g = G(), p = g.player;
    if (g.gangMsg) { g.gangMsg.t -= dt; if (g.gangMsg.t <= 0) g.gangMsg = null; }
    // effets en cours sur le joueur
    const ph = g.pHack || (g.pHack = { jamT: 0, burnT: 0, stunT: 0, burnAcc: 0 });
    ph.jamT -= dt; ph.stunT -= dt;
    if (ph.burnT > 0) {
      ph.burnT -= dt; ph.burnAcc += dt;
      if (Math.random() < dt * 30) g.fx.part(p.x + (Math.random() - 0.5) * 6, p.y + (Math.random() - 0.5) * 4, 0, -20, 0.3, Math.random() < 0.5 ? '#ffb02a' : '#ff5a1a', 'spark');
      if (ph.burnAcc >= 0.5) { ph.burnAcc -= 0.5; g.fx.hurtPlayer(VH.burnDmg, Math.random() * 6.28); }
    }
    for (const e of g.enemies) {
      if (!e.d.hacker) continue;
      if (!g.ALIVE(e) || e.state !== 'alert' || e.neutral || e.blindT > 0 || e.stun > 0) { e.hackT = 0; continue; }
      const sees = C.dist(e.x, e.y, p.x, p.y) < VH.range && M.los(e.x, e.y, p.x, p.y);
      if (e.hackT > 0) {
        if (!sees) { e.hackT = 0; continue; }
        e.hackT += dt;
        // les decks plus solides résistent plus longtemps (ICE)
        if (e.hackT >= VH.up * (1 + 0.3 * (g.mods.tier - 1))) { e.hackT = 0; e.hackCd = VH.cd[0] + Math.random() * (VH.cd[1] - VH.cd[0]); hackPlayer(e); }
        continue;
      }
      e.hackCd = (e.hackCd == null ? 2 + Math.random() * 3 : e.hackCd) - dt;
      if (e.hackCd <= 0 && sees) { e.hackT = 0.001; g.fx.addFloat(p.x, p.y - 16, 'PIRATAGE ENTRANT', '#5dff9a'); C.sfx('upload'); }
    }
  };
  function hackPlayer(e) {
    const g = G(), p = g.player, ph = g.pHack, k = Math.random();
    if (g.cheats.god) return;
    if (k < 0.4) { ph.jamT = VH.jam; g.fx.addFloat(p.x, p.y - 12, 'OPTIQUE BROUILLÉE', '#5dff9a'); g.glitchT = 0.3; }
    else if (k < 0.7) { ph.burnT = VH.burn; g.fx.addFloat(p.x, p.y - 12, 'SURCHAUFFE', '#ff7a1a'); }
    else { ph.stunT = VH.stun; g.fx.hurtPlayer(VH.shock, Math.atan2(p.y - e.y, p.x - e.x)); g.fx.sparks(p.x, p.y, '#7ff6ff', 12); g.fx.addFloat(p.x, p.y - 12, 'COURT-CIRCUIT', '#7ff6ff'); }
    C.sfx('hack');
  }
  GA.spreadMul = () => { const ph = G().pHack; return ph && ph.jamT > 0 ? 5 : 1; };
  GA.speedMul = () => { const ph = G().pHack; return ph && ph.stunT > 0 ? 0.3 : 1; };

  // ---------- dessin ----------
  GA.drawWorld = function (g, t) {
    const gm = G(), p = gm.player;
    for (const e of gm.enemies) {
      if (!(e.hackT > 0) || !gm.ALIVE(e)) continue;
      // flux de données vert entre le Voodoo Boy et toi
      const n = Math.floor(C.dist(e.x, e.y, p.x, p.y) / 5);
      g.fillStyle = '#5dff9a';
      for (let i = 0; i < n; i++) if ((i + Math.floor(t * 20)) % 3 === 0) g.fillRect(Math.round(e.x + (p.x - e.x) * i / n), Math.round(e.y + (p.y - e.y) * i / n), 1, 1);
      const k = Math.min(1, e.hackT / (VH.up * (1 + 0.3 * (gm.mods.tier - 1))));
      g.fillStyle = '#05050a'; g.fillRect(Math.round(p.x) - 10, Math.round(p.y) - 20, 21, 4);
      g.fillStyle = '#5dff9a'; g.fillRect(Math.round(p.x) - 9, Math.round(p.y) - 19, Math.round(19 * k), 2);
    }
  };
  GA.drawHUD = function (g) {
    const gm = G(), id = GA.gangOf(M.id), T = (s, x, y, c, o = {}) => C.text(g, s, x, y, c, Object.assign({ shadow: '#05050a' }, o));
    if (gm.gangMsg) T(gm.gangMsg.text, C.W / 2, 36, gm.gangMsg.col, { align: 'center' });
    if (id && M.def.outdoor) {
      const gang = D.gangs[id], r = GA.rep(id), h = GA.hostile(id);
      T('TERRITOIRE ' + gang.nom + ' · ' + (h ? 'HOSTILES' : r > 30 ? 'AMICAUX' : 'NEUTRES'), C.W / 2, 20, h ? '#ff5a7a' : gang.color, { align: 'center' });
    }
    // brouillage : l'image grésille
    const ph = gm.pHack;
    if (ph && ph.jamT > 0) {
      for (let i = 0; i < 30; i++) { g.fillStyle = Math.random() < 0.5 ? 'rgba(93,255,154,0.5)' : 'rgba(255,62,200,0.4)'; g.fillRect((Math.random() * C.W) | 0, (Math.random() * C.H) | 0, 2 + ((Math.random() * 6) | 0), 1); }
      T('BROUILLAGE ' + ph.jamT.toFixed(1), C.W / 2, C.H - 30, '#5dff9a', { align: 'center' });
    }
  };
})();
