'use strict';
// Véhicules : voitures garées, voiture du leader, conduite, collisions, concessionnaire.
//
// Une voiture est une entité (pas une tuile) : {x, y, ang, speed, model, color, own, parked}.
// Son sprite est pixellisé comme les personnages (sprites.js) : formes dans le repère de la voiture
// (u vers l'avant, v vers la droite), rendues net dans 32 directions et gardées en cache.
// Pour les collisions, une voiture est une chaîne de 3 cercles le long de son axe.
(function () {
  const C = CEL, M = C.map;
  const V = (C.cars = {});

  // Modèles en vente (longueur et largeur en pixels ; un personnage fait ~11 px de large).
  V.MODELS = {
    makigai: { nom: 'MAKIGAI MAIMAI', prix: 2500, len: 26, wid: 14, speed: 120, accel: 130, grip: 2.8, style: 'compact', desc: 'PETITE CITADINE. LENTE MAIS SE FAUFILE PARTOUT.' },
    galena: { nom: 'THORTON GALENA', prix: 6000, len: 32, wid: 16, speed: 160, accel: 160, grip: 2.5, style: 'sedan', desc: 'BERLINE SOLIDE, LA VOITURE DES GENS DU COIN.' },
    turbo: { nom: 'QUADRA TURBO-R', prix: 15000, len: 34, wid: 16, speed: 230, accel: 240, grip: 2.3, style: 'sport', desc: 'SPORTIVE. TRÈS RAPIDE, À PRENDRE AVEC DES GANTS.' },
  };
  V.COLORS = ['#c4142b', '#2a6fdb', '#f2d43a', '#1a1a22', '#e8e8f0', '#3fd0b0', '#7a3cff', '#ff7a1a'];
  const PARKED_COLORS = ['#5a1a2a', '#1a3a5a', '#3a3a3a', '#5a4a1a', '#2a4a3a', '#4a4a5c', '#6a2a1a'];
  const WRECK_COLORS = ['#4a3020', '#3a3830', '#503a28', '#2e2a26'];   // Pacifica : carcasses rouillées

  // Voitures garées le long des chaussées d'une carte de rue, calculées depuis ses bandes de route.
  // H, V : [[début, fin], ...] en tuiles ; every : une voiture toutes les n tuiles ; skip(x, y) : place interdite.
  V.parkAlong = function (H, V2, w, h, every, skip) {
    const P = [], inV = x => V2.some(([a, b]) => x >= a - 3 && x <= b + 3), inH = y => H.some(([a, b]) => y >= a - 3 && y <= b + 3);
    let n = 0;
    for (const [a, b] of H) for (let x = 2; x < w - 3; x += every) {
      if (inV(x) || inV(x + 3)) continue;
      n++;
      const top = n % 2 === 0, y = top ? a * 8 + 9 : b * 8 - 1;
      if (skip && skip(x, top ? a : b)) continue;
      P.push({ x: x * 8 + 16, y, ang: top ? 0 : Math.PI });
    }
    for (const [a, b] of V2) for (let y = 2; y < h - 3; y += every) {
      if (inH(y) || inH(y + 3)) continue;
      n++;
      const left = n % 2 === 0, x = left ? a * 8 + 9 : b * 8 - 1;
      if (skip && skip(left ? a : b, y)) continue;
      P.push({ x, y: y * 8 + 16, ang: left ? Math.PI / 2 : -Math.PI / 2 });
    }
    return P;
  };

  // ---------- sprite ----------
  const DIRS = 32, SIZE = 44, MID = SIZE / 2, cache = new Map();
  const hex2 = h => { const n = parseInt(h.slice(1), 16); return [n >> 16, (n >> 8) & 255, n & 255]; };
  const mul = (h, k) => { const [r, g, b] = hex2(h); const f = v => Math.max(0, Math.min(255, Math.round(v * k))); return '#' + ((1 << 24) | (f(r) << 16) | (f(g) << 8) | f(b)).toString(16).slice(1); };
  // rectangle aux coins arrondis, centré sur l'origine
  const rrect = (hu, hv, rad) => (u, v) => {
    const du = Math.abs(u) - (hu - rad), dv = Math.abs(v) - (hv - rad);
    if (du <= 0 || dv <= 0) return Math.abs(u) <= hu && Math.abs(v) <= hv;
    return du * du + dv * dv <= rad * rad;
  };
  function parts(m, col) {
    const L = m.len / 2, W = m.wid / 2, glass = '#26344e', glassHi = '#4a6a96', dark = mul(col, 0.62);
    const body = rrect(L, W, m.style === 'compact' ? 4 : 3);
    const P = [];
    // phares et feux
    P.push([(u, v) => u > L - 1.6 && Math.abs(v) > W - 4.5 && Math.abs(v) < W - 1 && body(u, v), '#fff2c0']);
    P.push([(u, v) => u < -L + 1.4 && Math.abs(v) > W - 4.5 && Math.abs(v) < W - 1 && body(u, v), '#ff2040']);
    // pare-brise, lunette arrière, toit
    const ws = m.style === 'sport' ? [2, 8] : [3, 8];
    P.push([(u, v) => u > ws[0] && u < ws[1] && Math.abs(v) < W - 2 && Math.abs(v) < W - 2 - (u - ws[0]) * 0.25, (u, v) => (v < -1 && u > ws[0] + 1 ? glassHi : glass)]);
    const rw = m.style === 'compact' ? [-L + 2, -L + 5] : [-L + 4, -L + 8];
    P.push([(u, v) => u > rw[0] && u < rw[1] && Math.abs(v) < W - 2.5, glass]);
    P.push([(u, v) => u >= rw[1] && u <= ws[0] && Math.abs(v) < W - 2, mul(col, 0.85)]);   // toit
    if (m.style === 'sport') P.push([(u, v) => Math.abs(v) < 1.2 && (u > ws[1] || u < rw[0]), '#f0f0f0']);   // bande de course
    // carrosserie (bord plus sombre)
    P.push([(u, v) => body(u, v) && (Math.abs(v) > W - 1.2 || Math.abs(u) > L - 1.2), dark]);
    P.push([body, col]);
    // roues qui dépassent un peu
    const wu = L - 5.5;
    P.push([(u, v) => Math.abs(Math.abs(u) - wu) < 2.6 && Math.abs(v) <= W + 1 && Math.abs(v) > W - 1, '#0c0c10']);
    return P;
  }
  function build(m, col, dir) {
    const P = parts(m, col), a = (dir / DIRS) * Math.PI * 2, ca = Math.cos(a), sa = Math.sin(a);
    const c = document.createElement('canvas'); c.width = c.height = SIZE;
    const g = c.getContext('2d'), filled = new Uint8Array(SIZE * SIZE);
    for (let py = 0; py < SIZE; py++) for (let px = 0; px < SIZE; px++) {
      const dx = px + 0.5 - MID, dy = py + 0.5 - MID, u = dx * ca + dy * sa, v = -dx * sa + dy * ca;
      for (const [test, color] of P) {
        if (!test(u, v)) continue;
        let k = typeof color === 'function' ? color(u, v) : color;
        // lumière du haut à gauche
        if (dx + dy < -6) k = mul(k, 1.12); else if (dx + dy > 6) k = mul(k, 0.85);
        g.fillStyle = k; g.fillRect(px, py, 1, 1);
        filled[py * SIZE + px] = 1;
        break;
      }
    }
    g.fillStyle = '#07070c';
    for (let py = 0; py < SIZE; py++) for (let px = 0; px < SIZE; px++) {
      if (filled[py * SIZE + px]) continue;
      const f = (x, y) => x >= 0 && y >= 0 && x < SIZE && y < SIZE && filled[y * SIZE + x];
      if (f(px - 1, py) || f(px + 1, py) || f(px, py - 1) || f(px, py + 1)) g.fillRect(px, py, 1, 1);
    }
    return c;
  }
  V.draw = function (g, car) {
    const m = V.MODELS[car.model];
    let dir = Math.round((car.ang / (Math.PI * 2)) * DIRS) % DIRS;
    if (dir < 0) dir += DIRS;
    const key = car.model + car.color + dir;
    let img = cache.get(key);
    if (!img) { img = build(m, car.color, dir); cache.set(key, img); }
    // ombre au sol
    g.fillStyle = 'rgba(0,0,0,0.4)';
    const L = m.len / 2 - 2;
    for (let i = -L; i <= L; i += 2) g.fillRect(Math.round(car.x + Math.cos(car.ang) * i) - 5, Math.round(car.y + Math.sin(car.ang) * i) - 3, 11, 9);
    g.drawImage(img, Math.round(car.x - MID), Math.round(car.y - MID));
    if (car.police) {
      // rampe de gyrophares sur le toit (rouge d'un côté, bleu de l'autre, en alternance) et bande noire NCPD
      const ca = Math.cos(car.ang), sa = Math.sin(car.ang), red = Math.floor((C.game.time || 0) * 5) % 2 === 0;
      for (let i = -6; i <= 6; i += 2) { g.fillStyle = '#14141c'; g.fillRect(Math.round(car.x + ca * i - sa * 0), Math.round(car.y + sa * i), 1, 1); }
      g.fillStyle = red ? '#ff2040' : '#5a1020'; g.fillRect(Math.round(car.x - 1 + sa * 3), Math.round(car.y - 1 - ca * 3), 2, 2);
      g.fillStyle = red ? '#102060' : '#3c6eff'; g.fillRect(Math.round(car.x - 1 - sa * 3), Math.round(car.y - 1 + ca * 3), 2, 2);
    }
  };

  // ---------- collisions ----------
  const DRIVABLE_BLOCK = new Set(['#', 'B', 'D', 'c', 'w']);
  V.circles = car => {
    const m = V.MODELS[car.model], r = m.wid / 2 - 0.5, off = m.len / 2 - r;
    const ca = Math.cos(car.ang), sa = Math.sin(car.ang);
    return [[car.x + ca * off, car.y + sa * off, r], [car.x, car.y, r], [car.x - ca * off, car.y - sa * off, r]];
  };
  function circleBlocked(x, y, r) {
    for (let ty = Math.floor((y - r) / 8); ty <= Math.floor((y + r) / 8); ty++) {
      for (let tx = Math.floor((x - r) / 8); tx <= Math.floor((x + r) / 8); tx++) {
        if (!DRIVABLE_BLOCK.has(M.tile(tx, ty)) && !M.blocked(tx, ty)) continue;
        const cx = Math.max(tx * 8, Math.min(x, tx * 8 + 8)), cy = Math.max(ty * 8, Math.min(y, ty * 8 + 8));
        if ((x - cx) ** 2 + (y - cy) ** 2 < r * r) return true;
      }
    }
    return false;
  }
  V.blocked = function (car, cars) {
    const cs = V.circles(car);
    for (const [x, y, r] of cs) if (circleBlocked(x, y, r)) return true;
    for (const o of cars) {
      if (o === car) continue;
      for (const [x, y, r] of cs) for (const [a, b, s] of V.circles(o)) if ((x - a) ** 2 + (y - b) ** 2 < (r + s) ** 2) return true;
    }
    return false;
  };
  // Un cercle (personnage) touche-t-il une voiture ? renvoie la voiture ou null
  V.hitCircle = function (x, y, r, cars) {
    for (const o of cars) for (const [a, b, s] of V.circles(o)) if ((x - a) ** 2 + (y - b) ** 2 < (r + s) ** 2) return o;
    return null;
  };

  // ---------- conduite ----------
  // keys : {up, down, left, right}. Renvoie true si on a tapé quelque chose (pour secouer la caméra).
  V.drive = function (car, dt, keys, cars) {
    const b = car.boost || 1, M0 = V.MODELS[car.model], m = b === 1 ? M0 : Object.assign({}, M0, { speed: M0.speed * b, accel: M0.accel * b });   // boost : triche turbo
    if (keys.up) car.speed = Math.min(m.speed, car.speed + (car.speed < 0 ? m.accel * 2 : m.accel) * dt);
    else if (keys.down) car.speed = Math.max(-m.speed * 0.35, car.speed - (car.speed > 0 ? m.accel * 2.2 : m.accel * 0.6) * dt);
    else car.speed *= Math.pow(0.35, dt);
    if (Math.abs(car.speed) < 1 && !keys.up && !keys.down) car.speed = 0;
    // on ne tourne qu'en roulant ; en marche arrière, le volant est inversé
    const steer = (keys.right ? 1 : 0) - (keys.left ? 1 : 0);
    const turn = steer * m.grip * dt * Math.min(1, Math.abs(car.speed) / 45) * Math.sign(car.speed);
    const oldA = car.ang, oldX = car.x, oldY = car.y;
    car.ang += turn;
    if (V.blocked(car, cars)) car.ang = oldA;
    // déplacement en petits pas pour ne pas traverser un mur
    const dist = car.speed * dt, n = Math.max(1, Math.ceil(Math.abs(dist) / 3));
    for (let i = 0; i < n; i++) {
      const px = car.x, py = car.y;
      car.x += Math.cos(car.ang) * dist / n;
      car.y += Math.sin(car.ang) * dist / n;
      if (V.blocked(car, cars)) {
        car.x = px; car.y = py;
        const hit = Math.abs(car.speed) > 40;
        car.speed *= -0.25;   // rebond
        return hit;
      }
    }
    if (car.x === oldX && car.y === oldY) car.speed *= 0.5;
    return false;
  };

  // Voitures garées d'une carte de rue (liste de la carte), en couleurs ternes.
  V.spawnParked = function (def) {
    const list = [];
    (def.parked || []).forEach((p, i) => {
      const keys = Object.keys(V.MODELS);
      const cols = def.wrecks ? WRECK_COLORS : PARKED_COLORS;
      const car = { x: p.x, y: p.y, ang: p.ang, speed: 0, model: keys[(i * 7) % 2], color: cols[(i * 5) % cols.length], own: false, parked: true };
      // garée à moitié sur le trottoir : les deux voies restent libres pour la circulation (traffic.js)
      const ROADT = t => t === 'r' || t === '=';
      for (const side of [1, -1]) {
        const nx = -Math.sin(p.ang) * side, ny = Math.cos(p.ang) * side;
        if (ROADT(M.tile(Math.floor((p.x + nx * 20) / 8), Math.floor((p.y + ny * 20) / 8)))) continue;   // ce côté-là, c'est la chaussée
        for (const k of [13, 11, 9, 7, 5]) {
          const t = Object.assign({}, car, { x: p.x + nx * k, y: p.y + ny * k });
          if (!V.blocked(t, [])) { car.x = t.x; car.y = t.y; break; }
        }
        break;
      }
      list.push(car);
    });
    return list;
  };
})();
