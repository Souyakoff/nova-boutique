'use strict';
// Intégration avec NOVA (launcher façon console). NOVA fournit window.NOVA aux jeux qu'il lance ;
// dans un navigateur ou dans Streaz, ce fichier ne fait rien.
//
// Chargé AVANT les autres scripts : legacy.js lit sa sauvegarde dès son chargement.
//   - Sauvegardes par profil : NOVA lance le jeu sur un port qui change à chaque fois, donc le localStorage
//     repart vide. Au premier chargement, on recopie les sauvegardes du profil NOVA dans le localStorage,
//     puis on recharge la page une fois (écran noir, invisible). Ensuite, chaque écriture est aussi envoyée à NOVA.
//   - Trophées (déclarés dans game.json) d'après l'avancement, classement des gigs par leader.
//   - Pause pendant le menu rapide de NOVA (main.js lit CEL_NOVA.paused).
(function () {
  const N = window.NOVA;
  if (!N) return;
  const KEYS = ['cel-partie', 'cel-ville', 'cel-music', 'cel-resolution'];
  const NOVA = (window.CEL_NOVA = { paused: false, syncing: false });

  // ---------- 1. sauvegardes du profil -> localStorage (à chaque lancement) ----------
  // NOVA ouvre le jeu par une navigation ; le rechargement qu'on déclenche ensuite est de type « reload ».
  // (Pas de marqueur en sessionStorage : il survivrait à un changement de profil dans NOVA.)
  let firstLoad = true;
  try { firstLoad = performance.getEntriesByType('navigation')[0].type !== 'reload'; } catch (e) { /* ancienne API */ }
  if (firstLoad) {
    NOVA.syncing = true; // main.js ne démarre pas la boucle : la page va se recharger
    Promise.all(KEYS.map((k) => N.load(k).catch(() => null))).then((values) => {
      KEYS.forEach((k, i) => {
        try {
          if (values[i] == null) localStorage.removeItem(k);
          else localStorage.setItem(k, typeof values[i] === 'string' ? values[i] : JSON.stringify(values[i]));
        } catch (e) { /* stockage indisponible */ }
      });
      location.reload();
    });
    return;
  }

  // ---------- 2. localStorage -> NOVA (à chaque écriture du jeu) ----------
  const set = Storage.prototype.setItem, remove = Storage.prototype.removeItem;
  Storage.prototype.setItem = function (k, v) {
    set.call(this, k, v);
    if (this === localStorage && KEYS.includes(k)) N.save(k, String(v)).catch(() => {});
  };
  Storage.prototype.removeItem = function (k) {
    remove.call(this, k);
    if (this === localStorage && KEYS.includes(k)) N.deleteSave(k).catch(() => {});
  };

  // ---------- 3. pause pendant le menu rapide de NOVA ----------
  addEventListener('message', (e) => {
    if (!e.data) return;
    if (e.data.type === 'nova:pause') NOVA.paused = true;
    if (e.data.type === 'nova:resume') NOVA.paused = false;
  });

  // ---------- 4. trophées et classement (lus dans l'état du jeu, une fois par seconde) ----------
  const sent = new Set();
  const chrome = (ld) => Object.keys(ld.implants || {}).filter((s) => !((CEL.DEF.implants || {})[ld.implants[s]] || {}).base).length;
  const ended = (fin) => ((CEL.legacy && CEL.legacy.city && CEL.legacy.city.leaders) || []).some((l) => l.fin === fin);
  const TROPHIES = [
    ['premier-gig', (g) => g.leader && g.leader.gigs >= 1],
    ['misericorde', (g) => g.leader && (g.leader.spared || []).length >= 1],
    ['sandevistan', (g) => g.sandy && g.sandy.on],
    ['au-volant', (g) => !!g.drive],
    ['cinq-gigs', (g) => g.leader && g.leader.gigs >= 5],
    ['chrome', (g) => g.leader && chrome(g.leader) >= 3],
    ['heritage', () => CEL.legacy && CEL.legacy.city && CEL.legacy.city.gen >= 1],
    ['legende', () => ended('legende')],
    ['raccrocher', () => ended('fixer')],
  ];
  let lastGen = null;

  setInterval(() => {
    const g = window.CEL && CEL.game;
    if (!g) return;
    for (const [id, done] of TROPHIES) {
      try { if (!sent.has(id) && done(g)) { sent.add(id); N.unlockTrophy(id); } } catch (e) { /* état pas encore prêt */ }
    }
    // un leader vient de finir (mort, légende, cyberpsycho ou raccroché) : ses gigs vont au classement
    const city = CEL.legacy && CEL.legacy.city;
    if (!city) return;
    if (lastGen === null) lastGen = city.gen;
    if (city.gen > lastGen) {
      lastGen = city.gen;
      const ld = city.leaders[city.leaders.length - 1];
      if (ld && ld.gigs > 0) N.submitScore(ld.gigs).catch(() => {});
    }
  }, 1000);
})();
