'use strict';
// NCPD : crimes dans la rue, étoiles de recherche façon GTA, civils qui paniquent, patrouilles qui débarquent.
//
// Un crime ne compte que s'il a un témoin (un passant ou un flic qui te voit). Les étoiles montent :
//   coups de feu        1 étoile          civil blessé       1 étoile
//   civil tué           2, puis +1 tous les deux meurtres
//   agent blessé        2 étoiles         agents à terre     +1 tous les trois
//   agent achevé        +1 étoile
// Tant que tu es recherché, des voitures du NCPD arrivent hors de l'écran avec deux agents chacune
// (SWAT à 3 étoiles, MaxTac à 5). Pour les semer : rester hors de leur vue assez longtemps (8 s + 3 s par étoile).
// À 3 étoiles, le métro est bouclé. Rentrer à la planque (gig suivant) remet le compteur à zéro.
(function () {
  const C = CEL, D = C.DEF, M = C.map, W = D.wanted, CV = D.civilian;
  const P = (C.ncpd = {});
  const G = () => C.game;

  P.reset = () => { G().wanted = { stars: 0, lost: 0, spawnT: 0, seen: false, flashT: 0, copsDown: 0, murders: 0 }; };

  // Quelqu'un a-t-il vu ce qui s'est passé en (x, y) ?
  P.witnessed = function (x, y) {
    const g = G();
    for (const q of g.peds) if (!q.dead && C.dist(q.x, q.y, x, y) < W.witness && M.los(q.x, q.y, x, y)) return true;
    for (const e of g.enemies) if (e.cop && g.ALIVE(e) && C.dist(e.x, e.y, x, y) < e.d.sight && M.los(e.x, e.y, x, y)) return true;
    return false;
  };
  function raise(n, msg) {
    const g = G(), w = g.wanted, before = w.stars;
    w.stars = Math.min(W.max, Math.max(w.stars, n));
    if (w.stars <= before) return;
    C.home.note('stars', w.stars);
    w.lost = 0; w.spawnT = Math.min(w.spawnT, 1.2); w.flashT = 2.5;
    if (msg) { w.msg = msg; w.msgT = 2.5; }   // bandeau radio du NCPD, en haut de l'écran
    C.sfx('wanted');
    C.music.event(w.stars >= 5 ? 'maxtac' : 'stars');
  }
  P.crime = function (kind, x, y) {
    const g = G(), w = g.wanted;
    if (kind === 'murder') C.home.note('civils');
    if (kind === 'copDown') C.home.note('cops');
    if (!w || !M.def.outdoor || g.cheats.nocops) return;   // dans les bâtiments, c'est entre toi et les gangs (et la triche « fantôme »)
    switch (kind) {
      case 'shots': if (w.stars === 0 && P.witnessed(x, y)) raise(1, 'COUPS DE FEU SIGNALÉS'); break;
      case 'assault': if (P.witnessed(x, y)) raise(1, 'AGRESSION SIGNALÉE'); break;
      case 'murder': if (P.witnessed(x, y)) { w.murders++; raise(1 + Math.ceil(w.murders / 2), 'MEURTRE SIGNALÉ'); } break;
      case 'copHurt': raise(2, "AGRESSION D'UN AGENT"); break;
      case 'copDown': w.copsDown++; raise(2 + Math.floor(w.copsDown / 3), 'AGENT À TERRE'); break;
      case 'copKill': raise(w.stars + 1, 'AGENT ABATTU'); break;
      case 'carjack': if (P.witnessed(x, y)) raise(1, 'VOL DE VOITURE SIGNALÉ'); break;
    }
  };

  // ---------- civils ----------
  P.panic = function (x, y, r) {
    for (const q of G().peds) {
      if (q.dead || C.dist(q.x, q.y, x, y) > r) continue;
      if (!(q.panicT > 0) && Math.random() < 0.35) G().fx.addFloat(q.x, q.y - 10, ['AU SECOURS !', 'IL EST FOU !', 'COUREZ !', 'NCPD !'][(Math.random() * 4) | 0], '#ffffff');
      q.panicT = CV.panicTime; q.fromX = x; q.fromY = y;
    }
  };
  P.hitPed = function (q, dmg, ang) {
    if (q.dead) return;
    const g = G(), fx = g.fx;
    const hpBefore = q.hp;
    q.hp -= dmg; q.hurtT = 0.12;
    fx.blood(q.x, q.y, ang, 6);
    C.gore.hit(q.x, q.y, ang, dmg >= 40);
    M.move(q, Math.cos(ang) * 3, Math.sin(ang) * 3);
    P.panic(q.x, q.y, 110);
    if (q.hp <= 0) {
      q.dead = true; q.downAng = ang; q.downT = 0; q.panicT = 0; q.burnT = 0;
      fx.blood(q.x, q.y, ang, 14);
      if ((dmg >= 60 && dmg - hpBefore >= CV.hp * 0.5) || g.cheats.gore) { q.gibbed = true; C.gore.burst(q.x, q.y, ang, false); }
      else C.gore.down(q.x, q.y, ang);
      g.reg.civils = (g.reg.civils || 0) + 1;
      C.sfx('down');
      P.crime('murder', q.x, q.y);
    } else {
      C.sfx('hit');
      P.crime('assault', q.x, q.y);
    }
  };
  // Appelé pour chaque passant ; renvoie true si son déplacement est déjà réglé (mort, aveuglé, en fuite).
  P.updatePed = function (q, dt) {
    const g = G();
    if (q.dead) { q.downT += dt; return true; }
    q.hurtT -= dt;
    if (q.burnT > 0) {
      q.burnT -= dt;
      q.burnAcc = (q.burnAcc || 0) + dt * D.quickhacks.surchauffe.dmg / D.quickhacks.surchauffe.dur;
      if (C.rand() < dt * 30) g.fx.part(q.x + C.rr(-3, 3), q.y + C.rr(-3, 2), C.rr(-8, 8), C.rr(-30, -14), 0.35, C.rand() < 0.5 ? '#ffb02a' : '#ff5a1a', 'spark');
      if (q.burnAcc >= 6) { q.burnAcc -= 6; P.hitPed(q, 6, C.rand() * 6.28); if (q.dead) return true; }
    }
    if (q.blindT > 0) { q.blindT -= dt; q.aim += dt * 2.5; q.running = false; return true; }
    if (q.panicT > 0) {
      q.panicT -= dt;
      const a = Math.atan2(q.y - q.fromY, q.x - q.fromX) + Math.sin(q.panicT * 2.3 + q.x * 0.1) * 0.5;
      q.aim = C.turn(q.aim, a, dt * 8);
      const hit = M.move(q, Math.cos(q.aim) * CV.panicSpeed * dt, Math.sin(q.aim) * CV.panicSpeed * dt);
      if (hit || g.fx.pushOutOfCars(q)) { q.fromX = q.x - Math.cos(q.aim + C.rr(1, 2.2)) * 20; q.fromY = q.y - Math.sin(q.aim + C.rr(1, 2.2)) * 20; }
      q.walk += dt * 16; q.running = true; q.tx = null;
      return true;
    }
    q.running = false;
    return false;
  };

  // ---------- patrouilles ----------
  const onScreen = (o, m = 24) => { const g = G(); return o.x > g.cam.x - m && o.x < g.cam.x + C.W + m && o.y > g.cam.y - m && o.y < g.cam.y + C.H + m; };
  const ROAD = t => t === 'r' || t === '=';
  // Une voiture de patrouille sur la chaussée, hors de l'écran, à 200-340 px, et deux agents à côté.
  function spawnSquad() {
    const g = G(), w = g.wanted, p = g.player;
    // à partir de 2 étoiles, la plupart des patrouilles arrivent en roulant et te prennent en chasse (traffic.js)
    const type0 = w.stars >= 5 ? 'maxtac' : w.stars >= 3 ? 'swat' : 'cop';
    if (w.stars >= 2 && Math.random() < 0.65 && C.traffic.spawnPolice(type0)) return true;
    for (let k = 0; k < 80; k++) {
      const tx = (Math.random() * M.MW) | 0, ty = (Math.random() * M.MH) | 0;
      if (!ROAD(M.tile(tx, ty)) || M.blocked(tx, ty)) continue;
      const x = tx * 8 + 4, y = ty * 8 + 4, d = C.dist(x, y, p.x, p.y);
      if (d < 200 || d > 340 || onScreen({ x, y })) continue;
      if (!M.flow || M.flow[ty * M.MW + tx] < 0) continue;   // ils doivent pouvoir te rejoindre
      const horiz = ROAD(M.tile(tx - 2, ty)) && ROAD(M.tile(tx + 2, ty));
      const ang = horiz ? (Math.random() < 0.5 ? 0 : Math.PI) : (Math.random() < 0.5 ? Math.PI / 2 : -Math.PI / 2);
      const car = { x, y, ang, speed: 0, model: 'galena', color: '#e8e8f0', police: true, parked: true, own: false };
      if (C.cars.blocked(car, g.cars)) continue;
      const type = w.stars >= 5 ? 'maxtac' : w.stars >= 3 ? 'swat' : 'cop';
      const ca = Math.cos(ang), sa = Math.sin(ang), team = [];
      for (const side of [1, -1]) {
        const ex = x - sa * 14 * side, ey = y + ca * 14 * side;
        if (M.solidAt(ex, ey) || C.cars.hitCircle(ex, ey, 4, g.cars.concat([car]))) continue;
        const e = g.fx.makeEnemy(type, 0, 0, {}, -1);
        Object.assign(e, { x: ex, y: ey, cop: true, nom: D.enemies[type].name, state: 'alert', react: 0.6, aim: Math.atan2(p.y - ey, p.x - ex) });
        team.push(e);
      }
      if (!team.length) continue;
      g.cars.push(car);
      g.enemies.push(...team);
      return true;
    }
    return false;
  }
  // Recherches abandonnées : les agents hors de l'écran disparaissent, ceux qu'on voit s'en vont.
  function standDown() {
    const g = G();
    for (const e of g.enemies) if (e.cop && g.ALIVE(e)) e.leaving = true;
  }
  P.update = function (dt) {
    const g = G(), w = g.wanted, p = g.player;
    if (!w) return;
    w.flashT -= dt; w.msgT = (w.msgT || 0) - dt;
    const outdoor = !!M.def.outdoor;
    // ceux qui s'en vont : ils restent calmes et disparaissent hors de l'écran
    for (const e of g.enemies) if (e.leaving && g.ALIVE(e)) e.state = 'idle';
    g.enemies = g.enemies.filter(e => !(e.leaving && g.ALIVE(e) && !onScreen(e)));
    if (w.stars === 0) g.cars = g.cars.filter(c => !c.police || onScreen(c, 60));
    const cops = g.enemies.filter(e => e.cop && g.ALIVE(e) && !e.leaving);
    const enRoute = C.traffic.pendingCops();   // agents encore dans les voitures de patrouille
    w.seen = outdoor && cops.some(e => C.dist(e.x, e.y, p.x, p.y) < e.d.sight && M.los(e.x, e.y, p.x, p.y));
    if (w.stars > 0) {
      w.lost = w.seen ? 0 : w.lost + dt;
      if (w.lost > W.lose + W.losePerStar * w.stars) {
        w.stars = 0; w.copsDown = 0; w.murders = 0; w.lost = 0;
        w.msg = 'RECHERCHES ABANDONNÉES'; w.msgT = 3;
        standDown();
      } else if (outdoor) {
        w.spawnT -= dt;
        if (w.spawnT <= 0) { w.spawnT = W.spawnEvery; if (cops.length + enRoute < W.squads[w.stars]) spawnSquad(); }
      }
    }
    C.siren(outdoor && w.stars > 0 && cops.length + enRoute > 0 ? 1 : 0);
    // recherches abandonnées : les voitures de police en route font demi-tour
    if (w.stars === 0) for (const c of g.cars) if (c.ai && c.ai.police) { c.ai.police = false; c.ai.crew = []; c.ai.cruise = 50; }
  };
  P.metroBlocked = () => { const w = G().wanted; return !!w && w.stars >= W.metroBlock; };

  // ---------- dessin ----------
  // Gyrophares : lueur rouge et bleue autour des voitures de patrouille (par-dessus l'éclairage).
  P.drawWorld = function (g, t) {
    const gm = G();
    for (const car of gm.cars || []) {
      if (!car.police) continue;
      const red = Math.floor(t * 5) % 2 === 0, col = red ? '255,32,64' : '60,110,255';
      const gr = g.createRadialGradient(car.x, car.y, 0, car.x, car.y, 36);
      gr.addColorStop(0, `rgba(${col},0.35)`); gr.addColorStop(1, `rgba(${col},0)`);
      g.globalCompositeOperation = 'lighter';
      g.fillStyle = gr; g.fillRect(car.x - 36, car.y - 36, 72, 72);
      g.globalCompositeOperation = 'source-over';
    }
  };
  // Une étoile de 7x7.
  const STAR = ['0001000', '0001000', '1111111', '0111110', '0011100', '0110110', '1100011'];
  function star(g, x, y, fill, edge) {
    for (let j = 0; j < 7; j++) for (let i = 0; i < 7; i++) {
      if (STAR[j][i] !== '1') continue;
      g.fillStyle = fill; g.fillRect(x + i, y + j, 1, 1);
    }
    if (edge) { g.fillStyle = edge; g.fillRect(x + 3, y + 3, 1, 1); }
  }
  P.drawHUD = function (g) {
    const gm = G(), w = gm.wanted;
    if (!w) return;
    if (w.msgT > 0) C.text(g, 'NCPD · ' + w.msg, C.W / 2, 28, Math.sin(gm.time * 10) > -0.3 ? '#4d8aff' : '#c7d5e0', { align: 'center', shadow: '#05050a' });
    if (w.stars === 0 && w.flashT <= 0) return;
    const t = gm.time, rx = C.W - 4, y = 52;
    // les étoiles clignotent quand elles montent, et pâlissent quand la police t'a perdu de vue
    for (let i = 0; i < W.max; i++) {
      const x = rx - (W.max - i) * 9 + 2, on = i < w.stars;
      g.fillStyle = '#05050a';
      for (let j = 0; j < 7; j++) for (let k = 0; k < 7; k++) if (STAR[j][k] === '1') g.fillRect(x + k + 1, y + j + 1, 1, 1);
      let col = '#454a60';
      if (on) col = w.flashT > 0 ? (Math.sin(t * 16) > 0 ? '#ffffff' : '#ffd23e') : w.seen ? '#ffd23e' : (Math.sin(t * 4) > 0 ? '#ffd23e' : '#6f6a4a');
      star(g, x, y, col);
    }
    C.text(g, 'NCPD', rx - W.max * 9 - 4, y + 1, '#4d8aff', { align: 'right', shadow: '#05050a' });
    if (w.stars > 0 && !w.seen) {
      const left = 1 - w.lost / (W.lose + W.losePerStar * w.stars);
      g.fillStyle = '#05050a'; g.fillRect(rx - 45, y + 9, 46, 3);
      g.fillStyle = '#4d8aff'; g.fillRect(rx - 44, y + 10, Math.round(44 * left), 1);
      C.text(g, 'RECHERCHE', rx, y + 14, '#6f7c8a', { align: 'right', shadow: '#05050a' });
    }
    // gyrophares sur les bords de l'écran quand ils te voient
    if (w.stars > 0 && w.seen && M.def.outdoor) {
      const red = Math.floor(t * 5) % 2 === 0;
      g.fillStyle = red ? 'rgba(255,32,64,0.18)' : 'rgba(60,110,255,0.18)';
      g.fillRect(0, 0, 3, C.H); g.fillRect(C.W - 3, 0, 3, C.H);
    }
  };
})();
